#uvicorn splunk_api_updated:app --reload
#pip install python-multipart
#pip install fastapi uvicorn


import openai
import json
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from fastapi.responses import JSONResponse
from splunkLLM_openai  import context, generate_query_prompt,openai_generate
import time
from concurrent.futures import ThreadPoolExecutor

app = FastAPI()
templates = Jinja2Templates(directory="templates")

class QueryRequest(BaseModel):
    user_input: str
    
# ========== LOG ANALYSIS ==========
def summarize_logs(logs):
    if not logs:
        return "No logs found."

    # Initialize counts
    http_2xx = 0
    http_4xx = 0
    http_5xx = 0

    for log in logs:
        try:
            code = int(log.get("httpCode", 0))
            count = int(log.get("count", 0))
        except (ValueError, TypeError):
            continue  # Skip if invalid

        if 200 <= code < 300:
            http_2xx += count
        elif 400 <= code < 500:
            http_4xx += count
        elif 500 <= code < 600:
            http_5xx += count

    # If no error codes, skip LLM
    if http_4xx == 0 and http_5xx == 0:
        return (
            f"No 4xx or 5xx errors were found in the logs.\n"
            f"There were a total of {http_2xx} successful (2xx) responses.\n"
            f"System appears healthy, no further action is needed."
        )

    # Else, use LLM to summarize
    formatted_logs = "\n".join([str(log) for log in logs])
    analysis_prompt = f"""
    You are a Splunk log analyst.

    Below are sample log records from a Splunk query:
    {formatted_logs}

    Please provide a natural language summary with:
    1. The top 2 error types (httpCode 4xx or 5xx) based on highest count.
    2. A brief breakdown of how many 2xx, 4xx, and 5xx responses occurred overall.
    3. Always mention any 5xx codes, even if their count is low.
    4. Suggest what actions might be needed (e.g., investigate high 404s or recurring 5xx).

    Return only a clean English explanation. Do NOT write a Splunk query.
    """
    ai_raw = openai_generate(analysis_prompt, max_tokens=512)
    print("\n=== Inside OpenAI Log Summary ===")
    print(ai_raw)

    # Clean output - strip instruction block if it's echoed
    lines = ai_raw.strip().splitlines()
    cleaned_output = ai_raw.strip()

    # Look for the SECOND '1.' line and extract from there
    count_1dot = 0
    for i, line in enumerate(lines):
        if line.strip().startswith("1."):
            count_1dot += 1
            if count_1dot == 2:
                cleaned_output = "\n".join(lines[i:])
                break

    return cleaned_output

# ========== RUN ALL QUERIES ==========
def run_all_queries(user_input):
    print(f"\nRunning all Splunk queries for: {user_input} | Time range: {context['time_range']}\n")
    
    PROMPT_LABELS = {
        1: "Status Code Breakdown",
        2: "Error Message Frequency",
        3: "Timechart by HTTP Code",
        4: "Channel-wise Failures",
        5: "Env-wise Status",
        6: "IP to Region Mapping",
        7: "Service Segment Failures"
    }

    def process_query(qid):
        try:
            prompt = generate_query_prompt(user_input, qid)
            print(f"\n--- Prompt for Query {qid} ---\n{prompt}\n")
            start_time = time.time()
            response_text = openai_generate(prompt, max_tokens=1024).strip()
            generation_time = time.time() - start_time

            print("\n==== Open AI FULL RAW RESPONSE ====")
            print(response_text)
            print("===========================")

            query_start = response_text.lower().find("### splunk query:")
            if query_start != -1:
                query_part = response_text[query_start + len("### Splunk Query:"):].strip()
            else:
                query_part = response_text.strip()

            splunk_query = "\n".join(line.strip() for line in query_part.splitlines() if line.strip())
            if not splunk_query.lower().startswith("search"):
                splunk_query = "search " + splunk_query

            splunk_query = splunk_query \
                .replace('“', '"').replace('”', '"') \
                .replace('‘', "'").replace('’', "'") \
                .replace('–', '-') \
                .replace('`', '"')

            context["last_query"] = splunk_query

            print(f"\n[Query {qid}] Splunk Query:\n{splunk_query}")
            print(f"[Query {qid}] Fetching logs...")
            splunk_start = time.time()
            #logs = run_splunk_query(splunk_query)
            logs = [
                {"channelId": "C30", "httpCode": 200, "count": 4500},
                {"channelId": "MON", "httpCode": 200, "count": 5678},
                {"channelId": "C30", "httpCode": 404, "count": 112},
                {"channelId": "MON", "httpCode": 503, "count": 89},
            ]
            splunk_duration = time.time() - splunk_start
            print(f"[Query {qid}] Splunk query executed in {splunk_duration:.2f} seconds.")

            print(f"[Query {qid}] Retrieved {len(logs)} log records.")
            if not logs:
                summary = "No logs found."
            else:
                summary = summarize_logs(logs)
            
            return {
                "qid": qid,
                "label": PROMPT_LABELS.get(qid, f"Prompt {qid}"),
                "query": splunk_query,
                "logs": logs,
                "summary": summary,
                "gen_time": generation_time
            }

        except Exception as e:
            print(f"[Query {qid}] Failed: {str(e)}")
            return {
                "qid": qid,
                "label": PROMPT_LABELS.get(qid, f"Prompt {qid}"),
                "query": "",
                "logs": [],
                "summary": f"Error: {str(e)}",
                "gen_time": 0.0
            }

    with ThreadPoolExecutor(max_workers=7) as executor:
        #futures = [executor.submit(process_query, qid) for qid in range(1, 8)]
        futures = [executor.submit(process_query, 4)]

    all_results = [f.result() for f in futures]

    print("\nSummary of Results:")
    for r in all_results:
        print(f"Query {r['qid']}: {len(r['logs'])} rows")
    return all_results

# ========== ROUTES ==========
@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})




def handle_chitchat_response(user_input, history=[]):
    try:
        messages = [{"role": "system", "content": "You are a helpful assistant."}]
        for turn in history:
            messages.append({"role": "user", "content": turn["user"]})
            messages.append({"role": "assistant", "content": turn["bot"]})
        messages.append({"role": "user", "content": user_input})

        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=messages,
            temperature=0.7,
            max_tokens=300
        )
        return response['choices'][0]['message']['content'].strip()
    except Exception as e:
        print(f"[Chitchat Error] {e}")
        return "I'm sorry, could you please clarify?"




def is_splunk_query(user_input):
    try:
        print(f"[Intent Classifier] User said: {user_input}")
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "Classify the user input intent as one of: splunk_query, general_ai_question, small_talk, thanks."},
                {"role": "user", "content": user_input}
            ],
            temperature=0,
            max_tokens=10
        )
        raw_intent = response['choices'][0]['message']['content'].strip().lower()
        intent = raw_intent.replace("intent:", "").strip()
        print(f"[Intent Classifier] GPT raw response: {raw_intent}")
        print(f"[Intent Classifier] Cleaned intent: {intent}")
        print(f"[Intent Classifier] Final interpreted intent: {intent == 'splunk_query'}")
        return intent == "splunk_query"
    except Exception as e:
        print(f"[Classifier Error] {e}")
        return False


@app.post("/generate")
async def generate_query(request_data: QueryRequest):
    user_input = request_data.user_input

    print(f"[Intent Classifier] User said: {user_input}")
    splunk_intent = is_splunk_query(user_input)

    if splunk_intent:
        print("[Route] Proceeding with Splunk query")
        all_results = run_all_queries(user_input)
        return JSONResponse(content={"results": all_results})
    else:
        print("[Route] Responding with chatbot (not a Splunk query)")
        response = handle_chitchat_response(user_input)
        return JSONResponse(content={"chitchat": response})


# ========== ENTRY POINT ==========
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("splunk_api:app", host="127.0.0.1", port=8000, reload=True)