package com.example.demo.service;

import java.util.Arrays;
import java.util.Map;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OnnxValue;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;

public class TestTensor {
	public static void main(String[] args) {
	    try (OrtEnvironment env = OrtEnvironment.getEnvironment();
	         OrtSession session = env.createSession("C:/Users/sathy/Downloads/personal/SpringBoot/demo/demo/src/main/resources/models/sentence_transformer.onnx", new OrtSession.SessionOptions())) {

	        long[][] inputIds = {{0, 21, 14, 1, 2, 12, 5, 0, 20, 15, 0, 21, 16, 4, 1, 20, 5, 0, 16, 18, 15, 6, 9, 12, 5}};
	        long[][] attentionMask = {{1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}};

	        System.out.println("Input IDs: " + Arrays.deepToString(inputIds));
	        System.out.println("Attention Mask: " + Arrays.deepToString(attentionMask));

	        try (OnnxTensor inputIdsTensor = OnnxTensor.createTensor(env, inputIds);
	             OnnxTensor attentionMaskTensor = OnnxTensor.createTensor(env, attentionMask)) {

	        	OrtSession.Result result = session.run(Map.of(
	        		    "input_ids", inputIdsTensor,
	        		    "attention_mask", attentionMaskTensor
	        		));

	        	// Handle the 3D tensor output
	        	OnnxValue outputValue = result.get(0);
	        	if (outputValue instanceof OnnxTensor) {
	        	    OnnxTensor tensor = (OnnxTensor) outputValue;

	        	    // Log the raw output value type and shape
	        	    System.out.println("Output Shape: " + Arrays.toString(tensor.getInfo().getShape()));
	        	    System.out.println("Output Value Class: " + tensor.getValue().getClass());

	        	    // Extract the value from the tensor
	        	    Object value = tensor.getValue();
	        	    if (value instanceof float[][][]) {
	        	        float[][][] embeddings = (float[][][]) value;

	        	        // Example: Use the first token embedding (e.g., [CLS] token)
	        	        float[] clsEmbedding = embeddings[0][0]; // First batch, first token
	        	        System.out.println("First token embedding: " + Arrays.toString(clsEmbedding));

	        	        // Alternatively, aggregate embeddings (e.g., mean pooling)
	        	        float[] pooledEmbedding = meanPool(embeddings[0]); // Pool across sequence length
	        	        System.out.println("Pooled embedding: " + Arrays.toString(pooledEmbedding));
	        	    } else {
	        	        throw new IllegalStateException("Unexpected tensor type: " + value.getClass());
	        	    }
	        	} else {
	        	    throw new IllegalStateException("Unexpected output type: " + outputValue.getType());
	        	}

	            //float[][] embeddings = (float[][]) result.get(0).getValue();
	            //System.out.println("Embedding vector: " + Arrays.toString(embeddings[0]));
	        }
	    } catch (Exception e) {
	        System.err.println("Error: " + e.getMessage());
	    }
	}

	public static float[] meanPool(float[][] sequenceEmbeddings) {
	    int embeddingSize = sequenceEmbeddings[0].length;
	    float[] pooledEmbedding = new float[embeddingSize];

	    for (float[] tokenEmbedding : sequenceEmbeddings) {
	        for (int i = 0; i < embeddingSize; i++) {
	            pooledEmbedding[i] += tokenEmbedding[i];
	        }
	    }

	    for (int i = 0; i < embeddingSize; i++) {
	        pooledEmbedding[i] /= sequenceEmbeddings.length; // Divide by sequence length
	    }

	    return pooledEmbedding;
	}

}

