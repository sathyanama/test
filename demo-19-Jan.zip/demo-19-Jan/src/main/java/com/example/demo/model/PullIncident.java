package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "pull_incident")
public class PullIncident {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "incident_number", nullable = false)
    private String incidentNumber;

    @Column(name = "create_by", nullable = false)
    private String createBy;

    @Column(name = "create_datetime", nullable = false)
    private LocalDateTime createDatetime;
    
    
    @Column(name = "start_datetime")
    private LocalDateTime startDatetime;

    @Column(name = "deduct_datetime")
    private LocalDateTime deductDatetime;

    @Column(name = "diagnose_datetime")
    private LocalDateTime diagnoseDatetime;

    @Column(name = "mitigate_datetime")
    private LocalDateTime mitigateDatetime;

    @Column(name = "resolve_datetime")
    private LocalDateTime resolveDatetime;
    

    @Column(name = "customer_exp", nullable = false, length = 1000)
    private String customerExp;

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getIncidentNumber() {
        return incidentNumber;
    }

    public void setIncidentNumber(String incidentNumber) {
        this.incidentNumber = incidentNumber;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public LocalDateTime getCreateDatetime() {
        return createDatetime;
    }

    public void setCreateDatetime(LocalDateTime createDatetime) {
        this.createDatetime = createDatetime;
    }

    public String getCustomerExp() {
        return customerExp;
    }

    public void setCustomerExp(String customerExp) {
        this.customerExp = customerExp;
    }

	public LocalDateTime getStartDatetime() {
		return startDatetime;
	}

	public void setStartDatetime(LocalDateTime startDatetime) {
		this.startDatetime = startDatetime;
	}

	public LocalDateTime getDeductDatetime() {
		return deductDatetime;
	}

	public void setDeductDatetime(LocalDateTime deductDatetime) {
		this.deductDatetime = deductDatetime;
	}

	public LocalDateTime getDiagnoseDatetime() {
		return diagnoseDatetime;
	}

	public void setDiagnoseDatetime(LocalDateTime diagnoseDatetime) {
		this.diagnoseDatetime = diagnoseDatetime;
	}

	public LocalDateTime getMitigateDatetime() {
		return mitigateDatetime;
	}

	public void setMitigateDatetime(LocalDateTime mitigateDatetime) {
		this.mitigateDatetime = mitigateDatetime;
	}

	public LocalDateTime getResolveDatetime() {
		return resolveDatetime;
	}

	public void setResolveDatetime(LocalDateTime resolveDatetime) {
		this.resolveDatetime = resolveDatetime;
	}
}
