package com.example.demo.service;

import ai.onnxruntime.*;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.stereotype.Service;

import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Service
public class EmbeddingService {
    private static final String MODEL_PATH = "models/sentence_transformer.onnx"; // Update with your actual path
    private final OrtEnvironment env;
    private final OrtSession session;

    // Caffeine cache for query embeddings
    private final Cache<String, float[]> embeddingCache;

    public EmbeddingService() throws OrtException, URISyntaxException {
        System.out.println("EmbeddingService constructor called...");
        this.env = OrtEnvironment.getEnvironment();

        // Configure ONNX runtime for multi-threading
        OrtSession.SessionOptions options = new OrtSession.SessionOptions();
        options.setIntraOpNumThreads(4); // Adjust based on your system's cores

        Path modelFilePath = Paths.get(getClass().getClassLoader().getResource(MODEL_PATH).toURI());
        System.out.println("Model file path: " + modelFilePath);

        this.session = env.createSession(modelFilePath.toString(), options);

        // Initialize Caffeine cache
        this.embeddingCache = Caffeine.newBuilder()
                .maximumSize(1000) // Cache up to 1000 entries
                .expireAfterAccess(10, TimeUnit.MINUTES) // Expire entries 10 minutes after last access
                .build();
        
        System.out.println("Cache Stats: " + embeddingCache.stats());

        System.out.println("EmbeddingService initialized with Caffeine cache and ONNX model.");
    }

    public float[] computeEmbedding(String text) throws OrtException {
        // Retrieve from cache or compute embedding if not present
    	float[] embedding = embeddingCache.getIfPresent(text);
        if (embedding != null) {
            System.out.println("Cache hit for query: " + text);
            return embedding;
        }

        System.out.println("Cache miss for query: " + text + ". Computing embedding...");
        embedding = computeEmbeddingInternal(text);
        embeddingCache.put(text, embedding);
        return embedding;
    }

    private float[] computeEmbeddingInternal(String text) throws OrtException {
        try {
            System.out.println("Cache miss for query: " + text + ". Computing embedding...");
            long[] inputIdsArray = tokenize(text);
            long[][] inputIds = new long[][]{inputIdsArray};
            long[][] attentionMask = new long[][]{new long[inputIdsArray.length]};
            Arrays.fill(attentionMask[0], 1L);

            System.out.println("Input IDs: " + Arrays.deepToString(inputIds));
            System.out.println("Attention Mask: " + Arrays.deepToString(attentionMask));

            try (OnnxTensor inputIdsTensor = OnnxTensor.createTensor(env, inputIds);
                 OnnxTensor attentionMaskTensor = OnnxTensor.createTensor(env, attentionMask)) {

                OrtSession.Result result = session.run(Map.of(
                        "input_ids", inputIdsTensor,
                        "attention_mask", attentionMaskTensor
                ));

                // Handle the 3D tensor output
                OnnxValue outputValue = result.get(0);
                if (outputValue instanceof OnnxTensor) {
                    OnnxTensor tensor = (OnnxTensor) outputValue;

                    // Log the raw output value type and shape
                    System.out.println("Output Shape: " + Arrays.toString(tensor.getInfo().getShape()));
                    System.out.println("Output Value Class: " + tensor.getValue().getClass());

                    // Extract the value from the tensor
                    Object value = tensor.getValue();
                    if (value instanceof float[][][]) {
                        float[][][] embeddings = (float[][][]) value;

                        // Use secondMaxPool or meanPool as per requirement
                        float[] pooledEmbedding = secondMaxPool(embeddings[0]); // Pool across sequence length
                        System.out.println("Pooled embedding: " + Arrays.toString(pooledEmbedding));

                        return pooledEmbedding;
                    } else {
                        throw new IllegalStateException("Unexpected tensor type: " + value.getClass());
                    }
                } else {
                    throw new IllegalStateException("Unexpected output type: " + outputValue.getType());
                }
            }
        } catch (Exception e) {
            System.err.println("Error during embedding computation: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }

    private float[] meanPool(float[][] tokenEmbeddings) {
        int numTokens = tokenEmbeddings.length;
        int embeddingSize = tokenEmbeddings[0].length;
        float[] pooledEmbedding = new float[embeddingSize];

        for (float[] tokenEmbedding : tokenEmbeddings) {
            for (int i = 0; i < embeddingSize; i++) {
                pooledEmbedding[i] += tokenEmbedding[i];
            }
        }

        for (int i = 0; i < embeddingSize; i++) {
            pooledEmbedding[i] /= numTokens;
        }

        return pooledEmbedding;
    }

    private float[] secondMaxPool(float[][] tokenEmbeddings) {
        int numTokens = tokenEmbeddings.length;
        int embeddingSize = tokenEmbeddings[0].length;
        float[] secondMaxEmbedding = new float[embeddingSize];

        // Initialize arrays to track maximum and second maximum
        float[] maxEmbedding = new float[embeddingSize];
        Arrays.fill(maxEmbedding, Float.NEGATIVE_INFINITY);
        Arrays.fill(secondMaxEmbedding, Float.NEGATIVE_INFINITY);

        // Iterate over all tokens
        for (float[] tokenEmbedding : tokenEmbeddings) {
            for (int i = 0; i < embeddingSize; i++) {
                if (tokenEmbedding[i] > maxEmbedding[i]) {
                    // Update second max before max
                    secondMaxEmbedding[i] = maxEmbedding[i];
                    maxEmbedding[i] = tokenEmbedding[i];
                } else if (tokenEmbedding[i] > secondMaxEmbedding[i] && tokenEmbedding[i] != maxEmbedding[i]) {
                    // Update second max if it's between the max and the current second max
                    secondMaxEmbedding[i] = tokenEmbedding[i];
                }
            }
        }

        return secondMaxEmbedding;
    }

    // Dummy tokenizer for testing; replace with actual tokenizer logic
    private long[] tokenize(String text) {
        return text.chars()
                .mapToLong(c -> {
                    if (c >= 'a' && c <= 'z') {
                        return c - 'a' + 1; // Map 'a' to 1, 'b' to 2, etc.
                    } else {
                        return 0; // Map unsupported characters to 0
                    }
                })
                .toArray();
    }
}
