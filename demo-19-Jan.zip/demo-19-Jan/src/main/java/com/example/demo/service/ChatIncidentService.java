package com.example.demo.service;

import com.example.demo.model.ChatIncident;
import com.example.demo.repository.ChatIncidentRepository;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

@Service
public class ChatIncidentService {

    private final ChatIncidentRepository repository;
    private final EmbeddingService embeddingService;

    public ChatIncidentService(ChatIncidentRepository repository, EmbeddingService embeddingService) {
        this.repository = repository;
        this.embeddingService = embeddingService;
        System.out.println("ChatIncidentService constructor called...");
    }

    public List<ChatIncident> searchIncidents(String query, String team) throws Exception {
        System.out.println("Starting search with query: " + query + ", team: " + team);

        // Fetch candidate incidents
        List<ChatIncident> incidents = repository.fetchIncidents(query, team);

        if (incidents.isEmpty()) {
            System.out.println("No incidents found for query: " + query + " and team: " + team);
            return List.of(); // Return an empty list if no incidents are found
        } else {
            System.out.println("Found " + incidents.size() + " incidents.");
        }

        // Compute or retrieve query embedding
        float[] queryEmbedding = embeddingService.computeEmbedding(query);
        if (queryEmbedding == null || queryEmbedding.length == 0) {
            throw new IllegalStateException("Query embedding is null or empty!");
        }
        System.out.println("Query embedding: " + Arrays.toString(queryEmbedding));

        // Validate and rank candidates by similarity
        incidents.sort(Comparator.comparingDouble(incident -> {
            float[] incidentEmbedding = incident.getEmbedding();

            // Compute dynamic embedding if missing
            if (incidentEmbedding == null || incidentEmbedding.length == 0) {
                try {
                    System.err.println("Incident missing embedding. Computing dynamically: " + incident.getId());
                    String textToEmbed = determineTextForEmbedding(incident);
                    if (textToEmbed == null || textToEmbed.isEmpty()) {
                        System.err.println("No valid text found for incident: " + incident.getId());
                        return Double.NEGATIVE_INFINITY;
                    }

                    incidentEmbedding = embeddingService.computeEmbedding(textToEmbed);
                    incident.setEmbedding(incidentEmbedding); // Assuming a setter for embedding
                } catch (Exception e) {
                    System.err.println("Error computing embedding for incident: " + incident.getId());
                    return Double.NEGATIVE_INFINITY;
                }
            }

            return cosineSimilarity(queryEmbedding, incidentEmbedding);
        }));

        // Log ranked incidents
        System.out.println("Ranked incidents:");
        incidents.forEach(incident -> {
            float[] incidentEmbedding = incident.getEmbedding();
            if (incidentEmbedding != null && incidentEmbedding.length > 0) {
                double similarity = cosineSimilarity(queryEmbedding, incidentEmbedding);
                System.out.println("Incident ID: " + incident.getId() + ", Similarity: " + similarity);
            }
        });

        // Return top 5 results
        List<ChatIncident> topIncidents = incidents.stream().limit(5).toList();
        if (topIncidents.isEmpty()) {
            System.out.println("No top incidents to return.");
        } else {
            System.out.println("Returning top " + topIncidents.size() + " incidents.");
        }
        return topIncidents;
    }

    private String determineTextForEmbedding(ChatIncident incident) {
        // Prioritize customerExp, fallback to analysis, then alertName
        if (incident.getCustomerExp() != null && !incident.getCustomerExp().isEmpty()) {
            return incident.getCustomerExp();
        } else if (incident.getAnalysis() != null && !incident.getAnalysis().isEmpty()) {
            return incident.getAnalysis();
        } else if (incident.getAlertName() != null && !incident.getAlertName().isEmpty()) {
            return incident.getAlertName();
        }
        return null; // No valid text found
    }

    private double cosineSimilarity(float[] vectorA, float[] vectorB) {
        double dotProduct = 0.0, normA = 0.0, normB = 0.0;
        for (int i = 0; i < vectorA.length; i++) {
            dotProduct += vectorA[i] * vectorB[i];
            normA += Math.pow(vectorA[i], 2);
            normB += Math.pow(vectorB[i], 2);
        }
        return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
    }
}
