package com.example.demo.service;

import ai.onnxruntime.*;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.stereotype.Service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

@Service
public class EmbeddingService {
    private static final String MODEL_PATH = "models/sentence_transformer_jina.onnx"; // ✅ Updated for Jina ONNX
    private OrtEnvironment env;
    private OrtSession session;

    // Caffeine cache for query embeddings
    private final Cache<String, float[]> embeddingCache;

    public EmbeddingService() {
        System.out.println("🛠️ EmbeddingService initialized. Model will be loaded on first use.");
        
        // Initialize Caffeine cache
        this.embeddingCache = Caffeine.newBuilder()
                .maximumSize(1000) 
                .expireAfterAccess(10, TimeUnit.MINUTES)
                .build();
    }
    
    private synchronized void loadModelIfNeeded() throws OrtException {
        if (session == null) {
            try {
                System.out.println("🔄 Resolving ONNX model path...");

                Path modelFilePath = Paths.get(System.getProperty("user.dir"), MODEL_PATH);
                System.out.println("✅ Expected model file path: " + modelFilePath.toAbsolutePath());

                if (!Files.exists(modelFilePath)) {
                    throw new IllegalStateException("❌ ONNX model file not found at: " + modelFilePath.toAbsolutePath());
                }

                env = OrtEnvironment.getEnvironment();
                OrtSession.SessionOptions options = new OrtSession.SessionOptions();
                options.setIntraOpNumThreads(4); 

                session = env.createSession(modelFilePath.toString(), options);
                System.out.println("✅ ONNX model loaded successfully from: " + modelFilePath.toAbsolutePath());
            } catch (Exception e) {
                throw new RuntimeException("❌ Failed to load ONNX model: " + e.getMessage(), e);
            }
        }
    }

    public float[] computeEmbedding(String text) throws OrtException {
        loadModelIfNeeded();

        // Check cache first
        float[] embedding = embeddingCache.getIfPresent(text);
        if (embedding != null) {
            System.out.println("✅ Cache hit for query: " + text);
            return embedding;
        }

        System.out.println("⚠️ Cache miss for query: " + text + ". Computing embedding...");
        embedding = computeEmbeddingInternal(text);
        embeddingCache.put(text, embedding);
        return embedding;
    }

    private float[] computeEmbeddingInternal(String text) throws OrtException {
        try {
            System.out.println("🔄 Computing embedding for: " + text);

            // ✅ Tokenization (Convert text into input tensors)
            long[][] inputIds = tokenize(text);
            long[][] attentionMask = generateAttentionMask(inputIds);

            System.out.println("🔹 Input IDs: " + Arrays.deepToString(inputIds));
            System.out.println("🔹 Attention Mask: " + Arrays.deepToString(attentionMask));

            try (OnnxTensor inputIdsTensor = OnnxTensor.createTensor(env, inputIds);
            	     OnnxTensor attentionMaskTensor = OnnxTensor.createTensor(env, attentionMask)) {

            	    // ✅ Run ONNX inference
            	    OrtSession.Result result = session.run(Map.of(
            	            "input_ids", inputIdsTensor,
            	            "attention_mask", attentionMaskTensor
            	    ));

            	    // ✅ Fix: Handle Optional<OnnxValue>
            	    Optional<OnnxValue> outputValueOpt = result.get("encoder_hidden_states");

            	    if (outputValueOpt.isPresent()) {
            	        OnnxValue outputValue = outputValueOpt.get();

            	        if (outputValue instanceof OnnxTensor) {
            	            OnnxTensor tensor = (OnnxTensor) outputValue;

            	            // Log ONNX output shape
            	            System.out.println("🔹 ONNX Output Shape: " + Arrays.toString(tensor.getInfo().getShape()));

            	            Object value = tensor.getValue();
            	            if (value instanceof float[][][]) {
            	                float[][][] embeddings = (float[][][]) value;

            	                // ✅ Apply pooling across sequence length
            	                float[] pooledEmbedding = meanPool(embeddings[0]);
            	                System.out.println("✅ Pooled embedding: " + Arrays.toString(pooledEmbedding));

            	                return pooledEmbedding;
            	            } else {
            	                throw new IllegalStateException("❌ Unexpected tensor type: " + value.getClass());
            	            }
            	        } else {
            	            throw new IllegalStateException("❌ Unexpected output type: " + outputValue.getType());
            	        }
            	    } else {
            	        throw new IllegalStateException("❌ ONNX output is empty. Model might not be returning valid embeddings.");
            	    }
            	}

        } catch (Exception e) {
            System.err.println("❌ Error during embedding computation: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }

    private float[] meanPool(float[][] tokenEmbeddings) {
        int numTokens = tokenEmbeddings.length;
        int embeddingSize = tokenEmbeddings[0].length;
        float[] pooledEmbedding = new float[embeddingSize];

        for (float[] tokenEmbedding : tokenEmbeddings) {
            for (int i = 0; i < embeddingSize; i++) {
                pooledEmbedding[i] += tokenEmbedding[i];
            }
        }

        for (int i = 0; i < embeddingSize; i++) {
            pooledEmbedding[i] /= numTokens;
        }

        return pooledEmbedding;
    }

    private long[][] tokenize(String text) {
        // ✅ Simulated tokenizer (replace with actual tokenizer logic)
        long[][] inputIds = new long[1][text.length()];
        for (int i = 0; i < text.length(); i++) {
            inputIds[0][i] = text.charAt(i) % 128;  // Basic tokenization logic
        }
        return inputIds;
    }

    private long[][] generateAttentionMask(long[][] inputIds) {
        long[][] attentionMask = new long[inputIds.length][inputIds[0].length];
        for (int i = 0; i < attentionMask.length; i++) {
            Arrays.fill(attentionMask[i], 1L);
        }
        return attentionMask;
    }
}