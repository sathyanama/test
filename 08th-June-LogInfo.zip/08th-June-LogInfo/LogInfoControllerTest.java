package com.example.demo.controller;

import com.example.demo.service.LogInfoService;
import com.example.demo.util.CommonUtil;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(LogInfoController.class)
@AutoConfigureMockMvc(addFilters = false)
public class LogInfoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private LogInfoService logInfoService;

    @MockBean
    private CommonUtil commonUtil;

    @Test
    void testLogHitsForm() throws Exception {
        mockMvc.perform(get("/log-hits"))
                .andExpect(status().isOk())
                .andExpect(view().name("logHits"));
    }

    @Test
    void testShowHits_withDateRangeOnly() throws Exception {
        LocalDate fromDate = LocalDate.of(2025, 6, 1);
        LocalDate toDate = LocalDate.of(2025, 6, 5);
        LocalDateTime start = fromDate.atStartOfDay();
        LocalDateTime end = toDate.plusDays(1).atStartOfDay().minusNanos(1);

        // Dummy return data
        List<Map<String, Object>> summary = new ArrayList<>();
        Map<String, Object> row1 = new HashMap<>();
        row1.put("team", "DMC");
        row1.put("location", "SG");
        row1.put("date", "2025-06-01");
        row1.put("count", 10);
        summary.add(row1);

        List<Map<String, Object>> detail = new ArrayList<>();
        Map<String, Object> row2 = new HashMap<>();
        row2.put("team", "DMC");
        row2.put("location", "SG");
        row2.put("date", "2025-06-01");
        row2.put("screenId", "HOME");
        row2.put("count", 10);
        detail.add(row2);

        // Mock services
        Mockito.when(logInfoService.getHitsByTeamLocation(start, end)).thenReturn(summary);
        Mockito.when(logInfoService.getHitsByScreenId(start, end)).thenReturn(detail);

        mockMvc.perform(post("/log-hits")
                .param("fromDate", "2025-06-01")
                .param("toDate", "2025-06-05"))
                .andExpect(status().isOk())
                .andExpect(view().name("logHits"))
                .andExpect(model().attributeExists("hitsByTeamLocation"))
                .andExpect(model().attributeExists("hitsByScreenId"))
                .andExpect(model().attribute("fromDate", fromDate))
                .andExpect(model().attribute("toDate", toDate));
    }
}
