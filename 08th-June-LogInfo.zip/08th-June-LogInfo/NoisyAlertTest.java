package com.example.demo.model;

import org.junit.jupiter.api.Test;


import java.time.LocalDateTime;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class NoisyAlertTest {

    @Test
    void testBasicInfoFields() {
    	NoisyAlert alert = new NoisyAlert();

        alert.setId(1L);
        alert.setCreateDatetime(LocalDateTime.of(2025, 6, 8, 10, 0));
        alert.setUpdateUserDatetime(LocalDateTime.of(2025, 6, 9, 14, 15));
        alert.setUpdateUserName("admin");

        assertEquals(1L, alert.getId());
        assertEquals(LocalDateTime.of(2025, 6, 8, 10, 0), alert.getCreateDatetime());
        assertEquals(LocalDateTime.of(2025, 6, 9, 14, 15), alert.getUpdateUserDatetime());
        assertEquals("admin", alert.getUpdateUserName());
    }

    @Test
    void testAlertClassificationFields() {
        NoisyAlert alert = new NoisyAlert();

        alert.setAlertType("Memory Spike");
        alert.setType("Infra");
        alert.setStatus("Open");

        assertEquals("Memory Spike", alert.getAlertType());
        assertEquals("Infra", alert.getType());
        assertEquals("Open", alert.getStatus());
    }

    @Test
    void testProductAndOwnershipFields() {
        NoisyAlert alert = new NoisyAlert();

        alert.setProduct("Payments");
        alert.setTeam("DMC");
        alert.setContact("infra_support");
        alert.setDmcAssignee("sathya");

        assertEquals("Payments", alert.getProduct());
        assertEquals("DMC", alert.getTeam());
        assertEquals("infra_support", alert.getContact());
        assertEquals("sathya", alert.getDmcAssignee());
    }

    @Test
    void testSummaryDetailsFields() {
        NoisyAlert alert = new NoisyAlert();

        alert.setSummary("Alert triggered for memory threshold.");
        alert.setNotes("Recurring pattern seen.");
        alert.setBlackout("Y");
        alert.setSealId("SEAL-999");

        assertEquals("Alert triggered for memory threshold.", alert.getSummary());
        assertEquals("Recurring pattern seen.", alert.getNotes());
        assertEquals("Y", alert.getBlackout());
        assertEquals("SEAL-999", alert.getSealId());
    }

    @Test
    void testJiraAndTargetFields() {
        NoisyAlert alert = new NoisyAlert();

        alert.setRunbookReference("http://example.com/runbook");
        alert.setProductJira("JIRA-1234");
        alert.setTargetDate(LocalDate.of(2025, 6, 15));

        assertEquals("http://example.com/runbook", alert.getRunbookReference());
        assertEquals("JIRA-1234", alert.getProductJira());
        assertEquals(LocalDate.of(2025, 6, 15), alert.getTargetDate());
    }
}
