package com.example.demo.service;

import com.example.demo.model.LogInfo;
import com.example.demo.repository.LogInfoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LogInfoServiceTest {

    @Mock
    private LogInfoRepository logInfoRepository;

    @InjectMocks
    private LogInfoService logInfoService;

    @Captor
    ArgumentCaptor<LogInfo> logCaptor;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testLogActivity_withAllParams_savesLogCorrectly() {
        logInfoService.logActivity("sess123", "dashboard", "testuser", "DMC","SG","Error occurred", "500");

        verify(logInfoRepository).save(logCaptor.capture());
        LogInfo savedLog = logCaptor.getValue();

        assertEquals("sess123", savedLog.getSessionId());
        assertEquals("dashboard", savedLog.getScreenId());
        assertEquals("testuser", savedLog.getUsername());
        assertEquals("DMC", savedLog.getTeam());
        assertEquals("SG", savedLog.getLocation());
        assertEquals("Error occurred", savedLog.getException());
        assertEquals("500", savedLog.getResponseCode());
        assertNotNull(savedLog.getLogDatetime());
    }

    @Test
    void testLogActivity_withDefaults_savesSuccessLog() {
        logInfoService.logActivity("sess456", "rca", "adminuser","DMC","SG");

        verify(logInfoRepository).save(logCaptor.capture());
        LogInfo savedLog = logCaptor.getValue();

        assertEquals("sess456", savedLog.getSessionId());
        assertEquals("rca", savedLog.getScreenId());
        assertEquals("adminuser", savedLog.getUsername());
        assertEquals("Success", savedLog.getException());
        assertEquals("200", savedLog.getResponseCode());
        assertNotNull(savedLog.getLogDatetime());
    }
    
    //added on 8th June
    
    @Test
    void testGetHitsByTeamLocation() {
        LocalDateTime start = LocalDateTime.of(2025, 6, 1, 0, 0);
        LocalDateTime end = LocalDateTime.of(2025, 6, 5, 23, 59);

        List<Map<String, Object>> expected = new ArrayList<>();
        Map<String, Object> row = new HashMap<>();
        row.put("team", "DMC");
        row.put("location", "SG");
        row.put("date", "2025-06-01");
        row.put("count", 10);
        expected.add(row);

        when(logInfoRepository.countByTeamAndLocation(start, end)).thenReturn(expected);

        List<Map<String, Object>> result = logInfoService.getHitsByTeamLocation(start, end);

        assertEquals(expected, result);
        verify(logInfoRepository, times(1)).countByTeamAndLocation(start, end);
    }

    @Test
    void testGetHitsByScreenId() {
        LocalDateTime start = LocalDateTime.of(2025, 6, 1, 0, 0);
        LocalDateTime end = LocalDateTime.of(2025, 6, 5, 23, 59);

        List<Map<String, Object>> expected = new ArrayList<>();
        Map<String, Object> row = new HashMap<>();
        row.put("team", "DMC");
        row.put("location", "SG");
        row.put("date", "2025-06-01");
        row.put("screenId", "HOME");
        row.put("count", 15);
        expected.add(row);

        when(logInfoRepository.countByScreenId(start, end)).thenReturn(expected);

        List<Map<String, Object>> result = logInfoService.getHitsByScreenId(start, end);

        assertEquals(expected, result);
        verify(logInfoRepository, times(1)).countByScreenId(start, end);
    }
}
