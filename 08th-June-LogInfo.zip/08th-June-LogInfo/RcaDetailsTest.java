package com.example.demo.model;

import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

public class RcaDetailsTest {

    @Test
    void testBasicFields() {
        RcaDetails rca = new RcaDetails();

        rca.setId(101L);
        rca.setIncidentNumber("INC123456");
        rca.setPriority("P1");
        rca.setImpactedLobs("Cards, Loans");
        rca.setIncidentDescription("Root cause related to DB spike");

        assertEquals(101L, rca.getId());
        assertEquals("INC123456", rca.getIncidentNumber());
        assertEquals("P1", rca.getPriority());
        assertEquals("Cards, Loans", rca.getImpactedLobs());
        assertEquals("Root cause related to DB spike", rca.getIncidentDescription());
    }

    @Test
    void testRcaAndLinkFields() {
        RcaDetails rca = new RcaDetails();
        
        rca.setRcaSharepointFolder("https://sharepoint.com/rca/folder");
        rca.setRcaSharepointLink("https://sharepoint.com/rca/doc");
        
        assertEquals("https://sharepoint.com/rca/folder", rca.getRcaSharepointFolder());
        assertEquals("https://sharepoint.com/rca/doc", rca.getRcaSharepointLink());
    }

    @Test
    void testAuditFields() {
        RcaDetails rca = new RcaDetails();

        rca.setUpdateUser("pooja");
        LocalDateTime now = LocalDateTime.of(2025, 6, 8, 10, 0);
        rca.setUpdateDate(now);

        assertEquals("pooja", rca.getUpdateUser());
        assertEquals(now, rca.getUpdateDate());
    }
}
