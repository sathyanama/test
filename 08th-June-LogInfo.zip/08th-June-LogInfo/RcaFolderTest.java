package com.example.demo.model;

import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;


public class RcaFolderTest {

    @Test
    void testIdentifiersAndMetaFields() {
        RcaFolder folder = new RcaFolder();

        folder.setId(1L);
        folder.setFolderName("RCA-JUNE-2025");
        folder.setFolderCreatedBy("sathya");
        folder.setUpdateUser("admin");

        assertEquals(1L, folder.getId());
        assertEquals("RCA-JUNE-2025", folder.getFolderName());
        assertEquals("sathya", folder.getFolderCreatedBy());
        assertEquals("admin", folder.getUpdateUser());
    }

    @Test
    void testDateTimeFields() {
        RcaFolder folder = new RcaFolder();

        LocalDateTime created = LocalDateTime.of(2025, 6, 1, 9, 30);
        LocalDateTime updated = LocalDateTime.of(2025, 6, 8, 15, 45);

        folder.setFolderCreatedOn(created);
        folder.setUpdateDate(updated);

        assertEquals(created, folder.getFolderCreatedOn());
        assertEquals(updated, folder.getUpdateDate());
    }
}
