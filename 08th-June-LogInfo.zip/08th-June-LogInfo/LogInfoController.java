package com.example.demo.controller;

import com.example.demo.service.LogInfoService;
import com.example.demo.util.CommonUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Controller
public class LogInfoController {

    private final LogInfoService logInfoService;
    private final CommonUtil commonUtil;

    @Autowired
    public LogInfoController(LogInfoService logInfoService, CommonUtil commonUtil) {
        this.logInfoService = logInfoService;
        this.commonUtil = commonUtil;
    }

    @GetMapping("/log-hits")
    public String logHitsForm(Model model, HttpServletRequest request) {
        commonUtil.addUserDetailsToModel(model, "LOG_HITS", "logHits", request);
        return "logHits";
    }

    @PostMapping("/log-hits")
    public String showHits(@RequestParam("fromDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
                           @RequestParam("toDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
                           Model model,
                           HttpServletRequest request) {

        // Add session-based user info
        commonUtil.addUserDetailsToModel(model, "LOG_HITS", "logHits", request);

        // Convert LocalDate to LocalDateTime for full-day coverage
        LocalDateTime start = fromDate.atStartOfDay();
        LocalDateTime end = toDate.plusDays(1).atStartOfDay().minusNanos(1); // end of toDate

        // Call service methods
        List<Map<String, Object>> hitsByTeamLocation = logInfoService.getHitsByTeamLocation(start, end);
        List<Map<String, Object>> hitsByScreenId = logInfoService.getHitsByScreenId(start, end);

        // Add results to model
        model.addAttribute("hitsByTeamLocation", hitsByTeamLocation);
        model.addAttribute("hitsByScreenId", hitsByScreenId);
        model.addAttribute("fromDate", fromDate);
        model.addAttribute("toDate", toDate);

        return "logHits";
    }
}