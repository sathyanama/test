package com.example.demo.model;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

public class LogInfoTest {

    @Test
    void testIdentifiersAndMetaFields() {
        LogInfo log = new LogInfo();

        log.setId(1L);
        log.setScreenId("DASHBOARD");
        log.setSessionId("ABC123");

        assertEquals(1L, log.getId());
        assertEquals("DASHBOARD", log.getScreenId());
        assertEquals("ABC123", log.getSessionId());
    }

    @Test
    void testUserDetails() {
        LogInfo log = new LogInfo();

        log.setUsername("sathya");
        log.setTeam("DMC");
        log.setLocation("SG");

        assertEquals("sathya", log.getUsername());
        assertEquals("DMC", log.getTeam());
        assertEquals("SG", log.getLocation());
    }

    @Test
    void testLogDataFields() {
        LogInfo log = new LogInfo();

        log.setException("NullPointerException at line 42");
        log.setResponseCode("500");

        assertEquals("NullPointerException at line 42", log.getException());
        assertEquals("500", log.getResponseCode());
    }

    @Test
    void testDateTimeField() {
        LogInfo log = new LogInfo();

        LocalDateTime now = LocalDateTime.of(2025, 6, 8, 12, 30);
        log.setLogDatetime(now);

        assertEquals(now, log.getLogDatetime());
    }
}
