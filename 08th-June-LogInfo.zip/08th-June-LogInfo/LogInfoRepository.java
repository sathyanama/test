package com.example.demo.repository;

import com.example.demo.model.LogInfo;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface LogInfoRepository extends JpaRepository<LogInfo, Long> {
    // This repository will provide basic CRUD operations for LogInfo table.
	
	//added new on 8th June
	@Query(value = "SELECT l.team AS team, l.location AS location, TRUNC(l.log_datetime) AS date, COUNT(*) AS count " +
            "FROM log_info l WHERE l.log_datetime BETWEEN :start AND :end " +
            "GROUP BY l.team, l.location, TRUNC(l.log_datetime)", nativeQuery = true)
	List<Map<String, Object>> countByTeamAndLocation(@Param("start") LocalDateTime start,
                                              @Param("end") LocalDateTime end);


	@Query(value = "SELECT l.team AS team, l.location AS location, TRUNC(l.log_datetime) AS date, l.screen_id AS screenId, COUNT(*) AS count " +
            "FROM log_info l WHERE l.log_datetime BETWEEN :start AND :end " +
            "GROUP BY l.team, l.location, TRUNC(l.log_datetime), l.screen_id", nativeQuery = true)
	List<Map<String, Object>> countByScreenId(@Param("start") LocalDateTime start,
                                       @Param("end") LocalDateTime end);
	
	//end
}
