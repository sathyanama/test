package com.example.demo.controller;

import com.example.demo.model.NoisyAlert;
import com.example.demo.service.NoisyAlertService;
import com.example.demo.util.CommonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.http.MediaType;

import java.util.*;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(NoisyAlertController.class)
@AutoConfigureMockMvc(addFilters = false)
class NoisyAlertControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private NoisyAlertService noisyAlertService;

    @MockBean
    private CommonUtil commonUtil;

    private MockHttpSession session;

    @BeforeEach
    void setup() {
        session = new MockHttpSession();
        session.setAttribute("username", "tester");
        session.setAttribute("team", "DMC");
        session.setAttribute("role", "USER");
    }

    @Test
    void testViewAlerts() throws Exception {
        List<NoisyAlert> alerts = new ArrayList<>();
        when(noisyAlertService.findByTeam("DMC")).thenReturn(alerts);

        mockMvc.perform(get("/noisy/view")
                .param("message", "Success")
                .session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("noisyView"))
                .andExpect(model().attributeExists("records"))
                .andExpect(model().attribute("message", "Success"));
    }

    @Test
    void testCreateAlert() throws Exception {
        mockMvc.perform(get("/noisy/create")
                .session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("noisyForm"))
                .andExpect(model().attributeExists("noisyAlert"));
    }

    @Test
    void testEditAlertFound() throws Exception {
        NoisyAlert alert = new NoisyAlert();
        when(noisyAlertService.findById(1L)).thenReturn(Optional.of(alert));

        mockMvc.perform(get("/noisy/edit/1")
                .session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("noisyForm"))
                .andExpect(model().attributeExists("noisyAlert"));
    }

    @Test
    void testEditAlertNotFound() throws Exception {
        when(noisyAlertService.findById(99L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/noisy/edit/99")
                .session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("noisyForm"))
                .andExpect(model().attributeExists("noisyAlert"));
    }

    @Test
    void testSaveAlert() throws Exception {
        mockMvc.perform(post("/noisy/save")
                .session(session)
                .param("summary", "test summary")
                .param("alertType", "Splunk")
                .param("blackout", "Y"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/noisy/view?message=Noisy Alert saved successfully"));
    }

    @Test
    void testDeleteAlert() throws Exception {
        mockMvc.perform(get("/noisy/delete/10")
                .session(session))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/noisy/view?message=Noisy Alert deleted"));
    }
}