package com.example.demo.service;

import com.example.demo.model.IncidentTracker;
import com.example.demo.repository.IncidentTrackerRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.time.LocalDateTime;
import java.time.Year;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class IncidentTrackerServiceTest {

    @Mock
    private IncidentTrackerRepository incidentTrackerRepository;

    @InjectMocks
    private IncidentTrackerService incidentTrackerService;

    @Mock
    private HttpServletRequest request;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateIncident_successful() {
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INC1001");
        incident.setTeam("DMC");

        when(incidentTrackerRepository.findByIncidentNumberAndTeam("INC1001", "DMC"))
                .thenReturn(Optional.empty());
        when(incidentTrackerRepository.save(incident)).thenReturn(incident);

        IncidentTracker saved = incidentTrackerService.createIncident(incident);

        assertEquals("INC1001", saved.getIncidentNumber());
        verify(incidentTrackerRepository).save(incident);
    }

    @Test
    public void testCreateIncident_whenAlreadyExists_shouldThrowException() {
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INC1002");
        incident.setTeam("DMC");

        when(incidentTrackerRepository.findByIncidentNumberAndTeam("INC1002", "DMC"))
                .thenReturn(Optional.of(new IncidentTracker()));

        assertThrows(IllegalArgumentException.class, () -> {
            incidentTrackerService.createIncident(incident);
        });

        verify(incidentTrackerRepository, never()).save(any());
    }
    
    @Test
    public void testUpdateIncident_successful() {
 
        Authentication auth = mock(Authentication.class);
        when(auth.getName()).thenReturn("testuser");

        SecurityContext securityContext = mock(SecurityContext.class);
        when(securityContext.getAuthentication()).thenReturn(auth);
        SecurityContextHolder.setContext(securityContext);

        IncidentTracker existing = new IncidentTracker();
        existing.setId(1L);
        existing.setIncidentNumber("INC2001");
        existing.setAnalysis("Old analysis");

        IncidentTracker updated = new IncidentTracker();
        updated.setId(1L);
        updated.setIncidentNumber("INC2001");
        updated.setAnalysis("Updated analysis");

        when(incidentTrackerRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(incidentTrackerRepository.save(any())).thenReturn(updated);

        HttpServletRequest request = mock(HttpServletRequest.class);
        IncidentTracker result = incidentTrackerService.updateIncident(updated);
        //IncidentTracker result = incidentTrackerService.updateIncident(updated,request);

        assertEquals("Updated analysis", result.getAnalysis());
        verify(incidentTrackerRepository).save(existing);
    }
    
    @Test
    public void testFindById_whenFound_shouldReturnIncident() {
        IncidentTracker incident = new IncidentTracker();
        incident.setId(10L);
        incident.setIncidentNumber("INC1010");

        when(incidentTrackerRepository.findById(10L)).thenReturn(Optional.of(incident));

        Optional<IncidentTracker> result = incidentTrackerService.findById(10L);

        assertTrue(result.isPresent());
        assertEquals("INC1010", result.get().getIncidentNumber());
    }

    @Test
    public void testFindById_whenNotFound_shouldReturnEmpty() {
        when(incidentTrackerRepository.findById(999L)).thenReturn(Optional.empty());

        Optional<IncidentTracker> result = incidentTrackerService.findById(999L);

        assertFalse(result.isPresent());
    }

    @Test
    public void testGetIncidentByNumberAndTeam_whenFound() {
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INC3001");
        incident.setTeam("DMC");

        when(incidentTrackerRepository.findByIncidentNumberAndTeam("INC3001", "DMC"))
                .thenReturn(Optional.of(incident));

        Optional<IncidentTracker> result = incidentTrackerService.getIncidentByNumberAndTeam("INC3001", "DMC");

        assertTrue(result.isPresent());
        assertEquals("DMC", result.get().getTeam());
    }
    
    @Test
    public void testGetIncidentByNumberAndTeam_whenNotFound() {
        when(incidentTrackerRepository.findByIncidentNumberAndTeam("INC404", "DMC"))
                .thenReturn(Optional.empty());

        Optional<IncidentTracker> result = incidentTrackerService.getIncidentByNumberAndTeam("INC404", "DMC");

        assertFalse(result.isPresent());
    }
    
    @Test
    public void testSearchPaginatedWithoutTeam_withQuery() {
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INC7777");

        List<IncidentTracker> incidents = List.of(incident);
        Page<IncidentTracker> mockPage = new PageImpl<>(incidents);

        // ✅ Fix: match any Pageable, not exact one
        when(incidentTrackerRepository.searchByQueryWithoutTeam(eq("network"), any(Pageable.class)))
                .thenReturn(mockPage);

        Page<IncidentTracker> result = incidentTrackerService.searchPaginatedWithoutTeam("network", 1, 10);

        assertEquals(1, result.getTotalElements());
        assertEquals("INC7777", result.getContent().get(0).getIncidentNumber());
        verify(incidentTrackerRepository).searchByQueryWithoutTeam(eq("network"), any(Pageable.class));
    }


    @Test
    public void testFindLast50RecordsWithoutTeam() {
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INC5050");

        List<IncidentTracker> incidents = List.of(incident);
        Page<IncidentTracker> mockPage = new PageImpl<>(incidents);

        when(incidentTrackerRepository.findByCreateDatetimeWithoutTeam(any(LocalDateTime.class), any(Pageable.class)))
                .thenReturn(mockPage);

        Page<IncidentTracker> result = incidentTrackerService.findLast50RecordsWithoutTeam(1, 10);

        assertEquals(1, result.getTotalElements());
        assertEquals("INC5050", result.getContent().get(0).getIncidentNumber());

        verify(incidentTrackerRepository).findByCreateDatetimeWithoutTeam(any(LocalDateTime.class), any(Pageable.class));
    }

/// new one
    
    @Test
    public void testFindLast50RecordsPaginated() {
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INC9999");

        List<IncidentTracker> incidents = List.of(incident);
        Page<IncidentTracker> mockPage = new PageImpl<>(incidents);

        when(incidentTrackerRepository.findByCreateDatetimeAfterAndTeamOrderByCreateDatetimeDesc(any(LocalDateTime.class), eq("DMC"), any(Pageable.class)))
                .thenReturn(mockPage);

        Page<IncidentTracker> result = incidentTrackerService.findLast50RecordsPaginated("DMC", 1, 10);

        assertEquals(1, result.getTotalElements());
        assertEquals("INC9999", result.getContent().get(0).getIncidentNumber());
    }

    @Test
    public void testGetESTTime() {
        LocalDateTime estTime = incidentTrackerService.getESTTime(9, 30, 0);
        assertEquals(9, estTime.getHour());
        assertEquals(30, estTime.getMinute());
    }

    @Test
    public void testDeleteIncident_successful() {
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INC1234");

        when(incidentTrackerRepository.findByIncidentNumber("INC1234"))
                .thenReturn(Optional.of(incident));

        incidentTrackerService.deleteIncident("INC1234");
        verify(incidentTrackerRepository).deleteByIncidentNumber("INC1234");
    }

    @Test
    public void testDeleteIncident_notFound_shouldThrowException() {
        when(incidentTrackerRepository.findByIncidentNumber("INC404"))
                .thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class, () -> {
            incidentTrackerService.deleteIncident("INC404");
        });
    }

    @Test
    public void testSearchPaginated() {
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INCSEARCH");

        Page<IncidentTracker> page = new PageImpl<>(List.of(incident));
        when(incidentTrackerRepository.searchByQueryAndTeam(eq("network"), eq("DMC"), any(Pageable.class))).thenReturn(page);

        Page<IncidentTracker> result = incidentTrackerService.searchPaginated("network", "DMC", 1, 10);
        assertEquals(1, result.getTotalElements());
        assertEquals("INCSEARCH", result.getContent().get(0).getIncidentNumber());
    }

    @Test
    public void testFindLast20ByTeam() {
        IncidentTracker incident = new IncidentTracker();
        incident.setTeam("DMC");

        when(incidentTrackerRepository.findTop20ByTeam(eq("DMC"), any(Pageable.class)))
                .thenReturn(List.of(incident));

        List<IncidentTracker> results = incidentTrackerService.findLast20ByTeam("DMC");
        assertEquals(1, results.size());
        assertEquals("DMC", results.get(0).getTeam());
    }

    @Test
    public void testSaveIncident() {
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INCSAVE");

        when(incidentTrackerRepository.save(incident)).thenReturn(incident);

        IncidentTracker result = incidentTrackerService.saveIncident(incident);
        assertEquals("INCSAVE", result.getIncidentNumber());
    }

    @Test
    public void testSaveAll() {
        List<IncidentTracker> incidents = Collections.singletonList(new IncidentTracker());
        incidentTrackerService.saveAll(incidents);
        verify(incidentTrackerRepository).saveAll(incidents);
    }

    @Test
    public void testFindIncidentsBySearchCriteria() {
        when(incidentTrackerRepository.findIncidentsBySearchCriteria("query", "DMC"))
                .thenReturn(List.of(new IncidentTracker()));

        List<IncidentTracker> results = incidentTrackerService.findIncidentsBySearchCriteria("query", "DMC");
        assertEquals(1, results.size());
    }

    @Test
    public void testGetIncidentByNumber() {
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INCNUMBER");

        when(incidentTrackerRepository.findByIncidentNumber("INCNUMBER"))
                .thenReturn(Optional.of(incident));

        Optional<IncidentTracker> result = incidentTrackerService.getIncidentByNumber("INCNUMBER");
        assertTrue(result.isPresent());
        assertEquals("INCNUMBER", result.get().getIncidentNumber());
    }

    @Test
    public void testGetFlaggedIncidents() {
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("FLAGGED1");

        when(incidentTrackerRepository.countFlaggedIncidents(anyString(), any(), any())).thenReturn(1L);
        when(incidentTrackerRepository.findFlaggedIncidents(anyString(), any(), any())).thenReturn(List.of(incident));

        List<IncidentTracker> results = incidentTrackerService.getFlaggedIncidents("DMC", "SG");
        assertEquals(1, results.size());
        assertEquals("FLAGGED1", results.get(0).getIncidentNumber());
    }
    
    //new Test
    
    @Test
    public void testUpdateIncident_whenNotFound_shouldThrowException() {
        IncidentTracker updated = new IncidentTracker();
        updated.setId(404L);

        when(incidentTrackerRepository.findById(404L)).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class, () -> {
            incidentTrackerService.updateIncident(updated);
        });
    }

    @Test
    public void testUpdateIncident_withAllDateFieldsSet() {
        Authentication auth = mock(Authentication.class);
        when(auth.getName()).thenReturn("tester");
        SecurityContext context = mock(SecurityContext.class);
        when(context.getAuthentication()).thenReturn(auth);
        SecurityContextHolder.setContext(context);

        IncidentTracker existing = new IncidentTracker();
        existing.setId(1L);

        IncidentTracker updated = new IncidentTracker();
        updated.setId(1L);
        updated.setOpenedTimeEst(LocalDateTime.now());
        updated.setClosedTimeEst(LocalDateTime.now());
        updated.setStartDatetime(LocalDateTime.now());
        updated.setDeductDatetime(LocalDateTime.now());
        updated.setDiagnoseDatetime(LocalDateTime.now());
        updated.setMitigateDatetime(LocalDateTime.now());
        updated.setResolveDatetime(LocalDateTime.now());
        updated.setMcEngageDatetime(LocalDateTime.now());

        when(incidentTrackerRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(incidentTrackerRepository.save(existing)).thenReturn(existing);

        IncidentTracker result = incidentTrackerService.updateIncident(updated);
        assertNotNull(result);

        verify(incidentTrackerRepository).save(existing);
    }

    //not required in local
    
	   /* @Test
	    public void testFormatDuration_nullOrZero() {
	        assertEquals("0m", incidentTrackerService.formatDuration(null));
	        assertEquals("0m", incidentTrackerService.formatDuration(0L));
	        assertEquals("0m", incidentTrackerService.formatDuration(-10L));
	    }
	
	    @Test
	    public void testFormatDuration_onlyMinutes() {
	        assertEquals("5m", incidentTrackerService.formatDuration(5L));
	    }
	
	    @Test
	    public void testFormatDuration_hoursAndMinutes() {
	        assertEquals("1h 5m", incidentTrackerService.formatDuration(65L)); // 1hr 5min
	    }
	
	    @Test
	    public void testFormatDuration_daysHoursMinutes() {
	        assertEquals("1d 2h 30m", incidentTrackerService.formatDuration(1L * 24 * 60 + 2 * 60 + 30)); // 1 day, 2 hrs, 30 min
	    }
	
	    @Test
	    public void testFormatDuration_exactDay() {
	        assertEquals("1d", incidentTrackerService.formatDuration(1440L)); // exactly 1 day
	    }*/


    // More tests for updateIncident, findById, getIncidentByNumberAndTeam, searchPaginatedWithoutTeam etc. will be added
}
