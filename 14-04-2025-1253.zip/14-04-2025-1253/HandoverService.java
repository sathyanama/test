package com.example.demo.service;

import com.example.demo.model.HandoverTracker;
import com.example.demo.repository.HandoverTrackerRepository;
import com.example.demo.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Service
public class HandoverService {

    @Autowired
    private HandoverTrackerRepository handoverTrackerRepository;

    @Autowired
    private UserService userService;

    // Fetch handover details for logged-in user
    public Optional<HandoverTracker> getHandoverByUser(String username) {
        User user = userService.getUserByUsername(username);
        return handoverTrackerRepository.findByTeam(user.getTeam());
    }


    //changed this method
    
    // Determine handover heading based on location and time
    public String getHandoverHeading(String location) {
        LocalTime currentTime = LocalTime.now(ZoneId.of("America/New_York")); // EST Time
        return getHandoverHeading(location, currentTime);                     
    }
    
    
 // New method only used for testing
    public String getHandoverHeading(String location, LocalTime currentTime) {
        return (currentTime.isAfter(LocalTime.of(7, 30)) && currentTime.isBefore(LocalTime.of(19, 30)))
                ? "Handover from US to SG"
                : "Handover from SG to US";
    }

    // Insert or update handover record
    public HandoverTracker saveOrUpdateHandover(String username, LocalDateTime startDate, LocalDateTime endDate, String hoItem) {
        User user = userService.getUserByUsername(username);
        //Optional<HandoverTracker> existingHandover = handoverTrackerRepository.findByTeam(user.getTeam());
        
        Optional<HandoverTracker> existingHandover = handoverTrackerRepository.findLatestHandoverByTeam(user.getTeam());

        HandoverTracker handover = existingHandover.orElse(new HandoverTracker());
        handover.setTeam(user.getTeam());
        handover.setLocation(user.getLocation());
        handover.setStartDate(startDate);
        handover.setEndDate(endDate);
        handover.setHoItem(hoItem);
        handover.setUpdateUser(username);
        handover.setUpdateDatetime(LocalDateTime.now(ZoneId.of("America/New_York")));

        return handoverTrackerRepository.save(handover);
    }
    
    public HandoverTracker saveOrUpdateHandover(String team, LocalDateTime startDate, LocalDateTime endDate, String hoItem, String updateUser) {
        User user = userService.getUserByUsername(updateUser); // Get the user details
        String location = user.getLocation(); // Fetch user's location

        Optional<HandoverTracker> existingHandover = handoverTrackerRepository.findByTeamAndStartDateAndEndDate(team, startDate, endDate);

        System.out.println("existingHandover.isPresent(): "+ existingHandover.isPresent());
        
        if (existingHandover.isPresent()) {
            //  Update the existing record
            HandoverTracker handover = existingHandover.get();
            handover.setHoItem(hoItem);
            handover.setUpdateUser(updateUser);
            handover.setUpdateDatetime(LocalDateTime.now(ZoneId.of("America/New_York")));
            return handoverTrackerRepository.save(handover);
        } else {
            //  Create a new record with the correct `location`
            HandoverTracker newHandover = new HandoverTracker();
            newHandover.setTeam(team);
            newHandover.setStartDate(startDate);
            newHandover.setEndDate(endDate);
            newHandover.setHoItem(hoItem);
            newHandover.setLocation(location); //  Set `location` before saving
            newHandover.setUpdateUser(updateUser);
            newHandover.setUpdateDatetime(LocalDateTime.now(ZoneId.of("America/New_York")));
            return handoverTrackerRepository.save(newHandover);
        }
    }

    
    // Fetch handover based on team, startDate, and endDate
    public Optional<HandoverTracker> getHandoverByTeamAndDates(String team, LocalDateTime startDate, LocalDateTime endDate) {
        // Calculate the difference in days
        long daysBetween = ChronoUnit.DAYS.between(startDate.toLocalDate(), endDate.toLocalDate());

        // Allow same-day or next-day only
        if (daysBetween < 0 || daysBetween > 1) {
            return Optional.empty(); // Prevents lookups beyond the allowed range
        }

        return handoverTrackerRepository.findByTeamAndStartDateAndEndDate(team, startDate, endDate);
    }
    
    
    
    public Optional<HandoverTracker> getLatestHandoverByUser(String username) {
        User user = userService.getUserByUsername(username);
        Optional<HandoverTracker> handover = handoverTrackerRepository.findLatestHandoverByTeam(user.getTeam());

        if (handover.isEmpty()) {
            System.out.println("No handover data found for team: " + user.getTeam());
        } else {
            System.out.println("Latest Handover Retrieved: " + handover.get().getStartDate());
        }

        return handover;
    }
    
    public Optional<HandoverTracker> getHandoverByCurrentTime(String team, LocalDateTime now) {
    	System.out.println("Checking Handover for Team: " + team);
        System.out.println("Current Time (EST): " + now);

        Optional<HandoverTracker> handover = handoverTrackerRepository.findHandoverByTeamAndCurrentTime(team, now);

        if (handover.isPresent()) {
            System.out.println(" Found Handover: " + handover.get().getStartDate() + " - " + handover.get().getEndDate());
        } else {
            System.out.println(" No handover found!");
        }

        return handover;
    }
    
    
    public Optional<HandoverTracker> getHandoverByShift(String team, LocalDateTime shiftStart, LocalDateTime shiftEnd) {
        List<HandoverTracker> handovers = handoverTrackerRepository.findHandoverByTeamAndShiftTime(team, shiftStart, shiftEnd);

        if (handovers.isEmpty()) {
            System.out.println(" No handover found for shift: " + shiftStart + " - " + shiftEnd);
            return Optional.empty();
        }

        System.out.println(" Found " + handovers.size() + " handover(s), returning the latest one.");
        return Optional.of(handovers.get(0)); // Return the latest entry
    }

}
