import org.springframework.web.bind.annotation.*;
import javax.crypto.SecretKey;
import java.util.Base64;

@RestController
public class EncryptionController {

    private final SecretKey secretKey;

    // Load the key from file (e.g., secret.key)
    public EncryptionController() throws Exception {
        this.secretKey = KeyLoader.loadKey("secret.key");
    }

    @GetMapping("/encrypt/{text}")
    public String encryptText(@PathVariable String text) {
        try {
            String encrypted = Encryptor.encrypt(text, secretKey);
            return "Encrypted Text: " + encrypted;
        } catch (Exception e) {
            return "Error encrypting text: " + e.getMessage();
        }
    }

    @GetMapping("/decrypt/{encryptedText}")
    public String decryptText(@PathVariable String encryptedText) {
        try {
            String decrypted = Decryptor.decrypt(encryptedText, secretKey);
            return "Decrypted Text: " + decrypted;
        } catch (Exception e) {
            return "Error decrypting text: " + e.getMessage();
        }
    }
}
