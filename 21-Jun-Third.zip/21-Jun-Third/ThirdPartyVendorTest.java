package com.example.demo.model;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

public class ThirdPartyVendorTest {

    @Test
    void testBasicFields() {
        ThirdPartyVendor vendor = new ThirdPartyVendor();

        vendor.setId(1L);
        vendor.setSealId("SEAL123");
        vendor.setAligendTo("Finance");
        vendor.setVendor("VendorX");
        vendor.setLob("Retail");

        assertEquals(1L, vendor.getId());
        assertEquals("SEAL123", vendor.getSealId());
        assertEquals("Finance", vendor.getAligendTo());
        assertEquals("VendorX", vendor.getVendor());
        assertEquals("Retail", vendor.getLob());
    }

    @Test
    void testProductOwnershipFields() {
        ThirdPartyVendor vendor = new ThirdPartyVendor();

        vendor.setProductHot("HotApp");
        vendor.setCtoHot("CTO Name");
        vendor.setAppOwner("App Owner");
        vendor.setProductOwner("Prod Owner");
        vendor.setRelationshipManager("Rel Manager");

        assertEquals("HotApp", vendor.getProductHot());
        assertEquals("CTO Name", vendor.getCtoHot());
        assertEquals("App Owner", vendor.getAppOwner());
        assertEquals("Prod Owner", vendor.getProductOwner());
        assertEquals("Rel Manager", vendor.getRelationshipManager());
    }

    @Test
    void testSupportAndContactsFields() {
        ThirdPartyVendor vendor = new ThirdPartyVendor();

        vendor.setProdOperationOwner("Ops Owner");
        vendor.setEscalationPath("Path details");
        vendor.setAccountManagerContacts("Mgr Contact");
        vendor.setVendorNumber("V-0001");
        vendor.setContactEmail("contact@example.com");

        assertEquals("Ops Owner", vendor.getProdOperationOwner());
        assertEquals("Path details", vendor.getEscalationPath());
        assertEquals("Mgr Contact", vendor.getAccountManagerContacts());
        assertEquals("V-0001", vendor.getVendorNumber());
        assertEquals("contact@example.com", vendor.getContactEmail());
    }

    @Test
    void testStrategyFields() {
        ThirdPartyVendor vendor = new ThirdPartyVendor();

        vendor.setResiliencyStrategy("Geo-redundant");
        vendor.setRulesOfEngagement("Engagement rules here");
        vendor.setEngagementId("ENG-123");
        vendor.setNotes("Some important notes");

        assertEquals("Geo-redundant", vendor.getResiliencyStrategy());
        assertEquals("Engagement rules here", vendor.getRulesOfEngagement());
        assertEquals("ENG-123", vendor.getEngagementId());
        assertEquals("Some important notes", vendor.getNotes());
    }

    @Test
    void testAuditFields() {
        ThirdPartyVendor vendor = new ThirdPartyVendor();

        vendor.setTeam("DMC");
        vendor.setCreatedDate(LocalDateTime.of(2025, 6, 21, 10, 0));
        vendor.setLastUpdatedBy("sathya");
        vendor.setLastUpdateTime(LocalDateTime.of(2025, 6, 21, 12, 30));

        assertEquals("DMC", vendor.getTeam());
        assertEquals(LocalDateTime.of(2025, 6, 21, 10, 0), vendor.getCreatedDate());
        assertEquals("sathya", vendor.getLastUpdatedBy());
        assertEquals(LocalDateTime.of(2025, 6, 21, 12, 30), vendor.getLastUpdateTime());
    }
}

