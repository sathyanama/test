package com.example.demo.controller;

import com.example.demo.model.ThirdPartyVendor;
import com.example.demo.service.ThirdPartyVendorService;
import com.example.demo.util.CommonUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

@Controller
@RequestMapping("/vendor")
public class ThirdPartyVendorController {

    private final ThirdPartyVendorService vendorService;
    private final CommonUtil commonUtil;

    public ThirdPartyVendorController(ThirdPartyVendorService vendorService, CommonUtil commonUtil) {
        this.vendorService = vendorService;
        this.commonUtil = commonUtil;
    }

    
    @GetMapping("/view")
    public String viewVendors(Model model,
                              HttpServletRequest request,
                              @RequestParam(defaultValue = "0") int page,
                              @RequestParam(defaultValue = "10") int size,
                              @RequestParam(required = false) String message) {

        commonUtil.addUserDetailsToModel(model, "THIRD_PARTY_VENDOR", "vendorView", request);

        Pageable pageable = PageRequest.of(page, size, Sort.by("lastUpdateTime").descending());
        Page<ThirdPartyVendor> pagedResult = vendorService.getVendorsPaginated(pageable);

        model.addAttribute("records", pagedResult.getContent());
        model.addAttribute("totalPages", pagedResult.getTotalPages());
        model.addAttribute("currentPage", page);
        model.addAttribute("message", message);

        return "vendorView";
    }

    @GetMapping("/create")
    public String createVendor(Model model, HttpServletRequest request) {
        commonUtil.addUserDetailsToModel(model, "THIRD_PARTY_VENDOR", "vendorForm", request);
        model.addAttribute("thirdPartyVendor", new ThirdPartyVendor());
        return "vendorForm";
    }

    @GetMapping("/edit/{id}")
    public String editVendor(@PathVariable Long id, Model model, HttpServletRequest request) {
        commonUtil.addUserDetailsToModel(model, "THIRD_PARTY_VENDOR", "vendorForm", request);
        ThirdPartyVendor vendor = vendorService.getVendorById(id);
        model.addAttribute("thirdPartyVendor", vendor);
        return "vendorForm";
    }

    @PostMapping("/save")
    public String saveVendor(@ModelAttribute ThirdPartyVendor vendor, HttpServletRequest request, Model model) {
        String username = (String) request.getSession().getAttribute("username");
        String team = (String) request.getSession().getAttribute("team");

        vendorService.saveVendor(vendor, username, team);
        return "redirect:/vendor/view?message=Vendor saved successfully";
    }

    @GetMapping("/delete/{id}")
    public String deleteVendor(@PathVariable Long id, HttpServletRequest request, Model model) {
        commonUtil.addUserDetailsToModel(model, "THIRD_PARTY_VENDOR", "vendorView", request);
        vendorService.deleteVendor(id);
        return "redirect:/vendor/view?message=Vendor deleted";
    }
    
    @GetMapping("/export")
    public void exportToCsv(HttpServletRequest request, HttpServletResponse response, Model model) throws IOException {
        commonUtil.addUserDetailsToModel(model, "THIRD_PARTY_VENDOR", "vendorExport", request);
        List<ThirdPartyVendor> records = vendorService.getAllVendors();

        response.setContentType("text/csv");
        response.setHeader("Content-Disposition", "attachment; filename=third_party_vendor.csv");

        PrintWriter writer = response.getWriter();

        // Header: 19 business + 4 audit fields
        writer.println("Seal ID,Aligned To,Vendor,LOB,Product HOT,Impacted Business Process,CTO HOT,App Owner,Product Owner,Relationship Manager,Prod Operation Owner,Escalation Path,Account Manager Contacts,Vendor Number,Contact Email,Resiliency Strategy,Rules of Engagement,Engagement ID,Notes,Team,Created Date,Last Updated By,Last Update Time");

        for (ThirdPartyVendor rec : records) {
            writer.printf("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s%n",
                wrap(rec.getSealId()),
                wrap(rec.getAligendTo()),
                wrap(rec.getVendor()),
                wrap(rec.getLob()),
                wrap(rec.getProductHot()),
                wrap(rec.getImpactedBusinessProcess()),
                wrap(rec.getCtoHot()),
                wrap(rec.getAppOwner()),
                wrap(rec.getProductOwner()),
                wrap(rec.getRelationshipManager()),
                wrap(rec.getProdOperationOwner()),
                wrap(rec.getEscalationPath()),
                wrap(rec.getAccountManagerContacts()),
                wrap(rec.getVendorNumber()),
                wrap(rec.getContactEmail()),
                wrap(rec.getResiliencyStrategy()),
                wrap(rec.getRulesOfEngagement()),
                wrap(rec.getEngagementId()),
                wrap(rec.getNotes()),
                wrap(rec.getTeam()),
                formatDate(rec.getCreatedDate()),
                wrap(rec.getLastUpdatedBy()),
                formatDate(rec.getLastUpdateTime())
            );
        }

        writer.flush();
        writer.close();
    }

    // Handles nulls and wraps in quotes
    private String wrap(String value) {
        return value == null ? "" : "\"" + value.replace("\"", "\"\"") + "\"";
    }

    // Format LocalDateTime as yyyy-MM-dd HH:mm (or return "")
    private String formatDate(LocalDateTime dateTime) {
        return dateTime == null ? "" : "\"" + dateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) + "\"";
    }


}

