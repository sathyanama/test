package com.example.demo.service;

import com.example.demo.model.ThirdPartyVendor;
import com.example.demo.repository.ThirdPartyVendorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;



@Service
public class ThirdPartyVendorService {

    @Autowired
    private ThirdPartyVendorRepository vendorRepository;

    public List<ThirdPartyVendor> getAllVendors() {
        return vendorRepository.findAll();
    }

    public ThirdPartyVendor getVendorById(Long id) {
        return vendorRepository.findById(id).orElse(null);
    }

    public void saveVendor(ThirdPartyVendor vendor, String username, String team) {
        ZonedDateTime estTime = ZonedDateTime.now(ZoneId.of("America/New_York"));

        if (vendor.getId() == null) {
            vendor.setCreatedDate(estTime.toLocalDateTime());
            vendor.setTeam(team);
        }

        vendor.setLastUpdatedBy(username);
        vendor.setLastUpdateTime(estTime.toLocalDateTime());

        vendorRepository.save(vendor);
    }

    public void deleteVendor(Long id) {
        vendorRepository.deleteById(id);
    }
    
    public Page<ThirdPartyVendor> getVendorsPaginated(Pageable pageable) {
        return vendorRepository.findAll(pageable);
    }
}

