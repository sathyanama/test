package com.example.demo.service;

import com.example.demo.model.ThirdPartyVendor;
import com.example.demo.repository.ThirdPartyVendorRepository;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import org.springframework.data.domain.Page;

@ExtendWith(MockitoExtension.class)
public class ThirdPartyVendorServiceTest {

    @Mock
    private ThirdPartyVendorRepository repository;

    @InjectMocks
    private ThirdPartyVendorService service;

    @Test
    void testGetAllVendors() {
        when(repository.findAll()).thenReturn(Collections.emptyList());
        assertTrue(service.getAllVendors().isEmpty());
    }

    @Test
    void testGetVendorById() {
        ThirdPartyVendor vendor = new ThirdPartyVendor();
        vendor.setId(1L);
        when(repository.findById(1L)).thenReturn(Optional.of(vendor));

        assertNotNull(service.getVendorById(1L));
    }

    @Test
    void testSaveVendor_New() {
        ThirdPartyVendor vendor = new ThirdPartyVendor();
        assertNull(vendor.getId());
        service.saveVendor(vendor, "user", "team");
        assertEquals("user", vendor.getLastUpdatedBy());
        assertEquals("team", vendor.getTeam());
        assertNotNull(vendor.getCreatedDate());
        verify(repository).save(vendor);
    }

    @Test
    void testDeleteVendor() {
        service.deleteVendor(1L);
        verify(repository).deleteById(1L);
    }
    
    @Test
    void testGetVendorsPaginated() {
        Pageable pageable = PageRequest.of(0, 5);
        Page<ThirdPartyVendor> mockPage = new PageImpl<>(Collections.emptyList());

        when(repository.findAll(pageable)).thenReturn(mockPage);

        Page<ThirdPartyVendor> result = service.getVendorsPaginated(pageable);
        assertEquals(0, result.getTotalElements());
    }
    
    @Test
    void testSaveVendor_NewVendorPath() {
        ThirdPartyVendor vendor = new ThirdPartyVendor(); // id is null

        service.saveVendor(vendor, "testuser", "DMC");

        assertEquals("testuser", vendor.getLastUpdatedBy());
        assertEquals("DMC", vendor.getTeam());
        assertNotNull(vendor.getCreatedDate());
        assertNotNull(vendor.getLastUpdateTime());

        verify(repository).save(vendor);
    }
    
    @Test
    void testSaveVendor_ExistingVendorPath() {
        ThirdPartyVendor vendor = new ThirdPartyVendor();
        vendor.setId(10L); // simulate existing vendor

        service.saveVendor(vendor, "admin", "OPS");

        assertEquals("admin", vendor.getLastUpdatedBy());
        assertNull(vendor.getTeam()); // team should remain null for existing record
        assertNotNull(vendor.getLastUpdateTime());

        verify(repository).save(vendor);
    }




}
