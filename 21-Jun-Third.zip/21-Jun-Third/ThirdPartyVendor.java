package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "third_party_vendor")
public class ThirdPartyVendor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String sealId;
    private String aligendTo;
    private String vendor;
    private String lob;
    private String productHot;

    @Lob
    private String impactedBusinessProcess;

    private String ctoHot;
    private String appOwner;
    private String productOwner;
    private String relationshipManager;
    private String prodOperationOwner;

    @Lob
    private String escalationPath;

    @Lob
    private String accountManagerContacts;

    @Lob
    private String vendorNumber;

    @Lob
    private String contactEmail;

    private String resiliencyStrategy;

    @Lob
    private String rulesOfEngagement;

    private String engagementId;

    @Lob
    private String notes;

    private String team;

    private LocalDateTime createdDate;

    private String lastUpdatedBy;

    private LocalDateTime lastUpdateTime;

    // Getters and Setters

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getSealId() { return sealId; }
    public void setSealId(String sealId) { this.sealId = sealId; }

    public String getAligendTo() { return aligendTo; }
    public void setAligendTo(String aligendTo) { this.aligendTo = aligendTo; }

    public String getVendor() { return vendor; }
    public void setVendor(String vendor) { this.vendor = vendor; }

    public String getLob() { return lob; }
    public void setLob(String lob) { this.lob = lob; }

    public String getProductHot() { return productHot; }
    public void setProductHot(String productHot) { this.productHot = productHot; }

    public String getImpactedBusinessProcess() { return impactedBusinessProcess; }
    public void setImpactedBusinessProcess(String impactedBusinessProcess) { this.impactedBusinessProcess = impactedBusinessProcess; }

    public String getCtoHot() { return ctoHot; }
    public void setCtoHot(String ctoHot) { this.ctoHot = ctoHot; }

    public String getAppOwner() { return appOwner; }
    public void setAppOwner(String appOwner) { this.appOwner = appOwner; }

    public String getProductOwner() { return productOwner; }
    public void setProductOwner(String productOwner) { this.productOwner = productOwner; }

    public String getRelationshipManager() { return relationshipManager; }
    public void setRelationshipManager(String relationshipManager) { this.relationshipManager = relationshipManager; }

    public String getProdOperationOwner() { return prodOperationOwner; }
    public void setProdOperationOwner(String prodOperationOwner) { this.prodOperationOwner = prodOperationOwner; }

    public String getEscalationPath() { return escalationPath; }
    public void setEscalationPath(String escalationPath) { this.escalationPath = escalationPath; }

    public String getAccountManagerContacts() { return accountManagerContacts; }
    public void setAccountManagerContacts(String accountManagerContacts) { this.accountManagerContacts = accountManagerContacts; }

    public String getVendorNumber() { return vendorNumber; }
    public void setVendorNumber(String vendorNumber) { this.vendorNumber = vendorNumber; }

    public String getContactEmail() { return contactEmail; }
    public void setContactEmail(String contactEmail) { this.contactEmail = contactEmail; }

    public String getResiliencyStrategy() { return resiliencyStrategy; }
    public void setResiliencyStrategy(String resiliencyStrategy) { this.resiliencyStrategy = resiliencyStrategy; }

    public String getRulesOfEngagement() { return rulesOfEngagement; }
    public void setRulesOfEngagement(String rulesOfEngagement) { this.rulesOfEngagement = rulesOfEngagement; }

    public String getEngagementId() { return engagementId; }
    public void setEngagementId(String engagementId) { this.engagementId = engagementId; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public String getTeam() { return team; }
    public void setTeam(String team) { this.team = team; }

    public LocalDateTime getCreatedDate() { return createdDate; }
    public void setCreatedDate(LocalDateTime createdDate) { this.createdDate = createdDate; }

    public String getLastUpdatedBy() { return lastUpdatedBy; }
    public void setLastUpdatedBy(String lastUpdatedBy) { this.lastUpdatedBy = lastUpdatedBy; }

    public LocalDateTime getLastUpdateTime() { return lastUpdateTime; }
    public void setLastUpdateTime(LocalDateTime lastUpdateTime) { this.lastUpdateTime = lastUpdateTime; }
}

