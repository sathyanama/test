package com.example.demo.controller;

import com.example.demo.model.ThirdPartyVendor;
import com.example.demo.service.ThirdPartyVendorService;
import com.example.demo.util.CommonUtil;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import static org.mockito.ArgumentMatchers.any;
import org.springframework.data.domain.Page;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@WebMvcTest(ThirdPartyVendorController.class)
@AutoConfigureMockMvc(addFilters = false)
public class ThirdPartyVendorControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ThirdPartyVendorService vendorService;

    @MockBean
    private CommonUtil commonUtil;

    @Test
    void testViewVendors() throws Exception {
        Page<ThirdPartyVendor> mockPage = new PageImpl<>(Collections.emptyList());
        Mockito.when(vendorService.getVendorsPaginated(any(Pageable.class))).thenReturn(mockPage);

        mockMvc.perform(get("/vendor/view").session(createSession()))
               .andExpect(status().isOk())
               .andExpect(view().name("vendorView"));
    }

    @Test
    void testCreateVendor() throws Exception {
        mockMvc.perform(get("/vendor/create").session(createSession()))
               .andExpect(status().isOk())
               .andExpect(view().name("vendorForm"));
    }

    @Test
    void testEditVendor() throws Exception {
        ThirdPartyVendor mock = new ThirdPartyVendor();
        mock.setId(1L);
        Mockito.when(vendorService.getVendorById(1L)).thenReturn(mock);

        mockMvc.perform(get("/vendor/edit/1").session(createSession()))
               .andExpect(status().isOk())
               .andExpect(view().name("vendorForm"));
    }

    @Test
    void testDeleteVendor() throws Exception {
        mockMvc.perform(get("/vendor/delete/1").session(createSession()))
               .andExpect(status().is3xxRedirection())
               .andExpect(redirectedUrl("/vendor/view?message=Vendor deleted"));
    }

    private MockHttpSession createSession() {
        MockHttpSession session = new MockHttpSession();
        session.setAttribute("username", "testuser");
        session.setAttribute("team", "DMC");
        session.setAttribute("role", "USER");
        return session;
    }
    
    @Test
    void testSaveVendor() throws Exception {
        mockMvc.perform(post("/vendor/save")
                .param("sealId", "SEAL123")
                .param("vendor", "TestVendor")
                .param("lob", "Retail")
                .session(createSession()))
            .andExpect(status().is3xxRedirection())
            .andExpect(redirectedUrl("/vendor/view?message=Vendor saved successfully"));
    }
    
    @Test
    void testExportToCsv() throws Exception {
        ThirdPartyVendor vendor = new ThirdPartyVendor();
        vendor.setSealId("SEAL123");
        vendor.setVendor("TestVendor");
        vendor.setLastUpdatedBy("testuser");
        vendor.setLastUpdateTime(LocalDateTime.of(2025, 6, 21, 12, 30));

        when(vendorService.getAllVendors()).thenReturn(List.of(vendor));

        mockMvc.perform(get("/vendor/export").session(createSession()))
            .andExpect(status().isOk())
            .andExpect(content().contentType("text/csv"))
            .andExpect(header().string("Content-Disposition", "attachment; filename=third_party_vendor.csv"));
    }

}

