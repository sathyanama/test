package com.example.demo.service;

import ai.onnxruntime.OrtException;
import aj.org.objectweb.asm.commons.Method;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;

import org.junit.jupiter.api.Assumptions;

public class EmbeddingServiceTest {

	@Test
	void testComputeEmbedding_validInput_returnsEmbedding() throws Exception {
	    EmbeddingService fakeService = new EmbeddingService() {
	        @Override
	        public float[] computeEmbedding(String text) {
	            return new float[]{0.1f, 0.2f, 0.3f}; // mocked vector
	        }
	    };

	    float[] result = fakeService.computeEmbedding("cpu failure");

	    assertNotNull(result);
	    assertArrayEquals(new float[]{0.1f, 0.2f, 0.3f}, result);
	}



	@Test
	void testEmbeddingCache_isUsedAfterFirstCall() throws Exception {
	    AtomicInteger callCount = new AtomicInteger(0);

	    EmbeddingService mockService = new EmbeddingService() {
	        private final Map<String, float[]> fakeCache = new HashMap<>();

	        @Override
	        public float[] computeEmbedding(String text) {
	            return fakeCache.computeIfAbsent(text, t -> {
	                callCount.incrementAndGet();
	                return new float[]{0.7f, 0.8f, 0.9f};
	            });
	        }
	    };

	    float[] result1 = mockService.computeEmbedding("disk full");
	    float[] result2 = mockService.computeEmbedding("disk full");

	    assertNotNull(result1);
	    assertNotNull(result2);
	    assertEquals(1, callCount.get()); // ✅ ensures caching logic works
	}


    
    
		@Test
		public void testComputeEmbedding_withMockedProtectedMethods() throws Exception {
		    EmbeddingService mockService = new EmbeddingService() {
		        @Override
		        public float[] computeEmbedding(String text) {
		            // Simulate what computeEmbedding would normally return
		            return new float[]{0.1f, 0.2f};
		        }
		    };

		    float[] result = mockService.computeEmbedding("disk failure");

		    assertNotNull(result);
		    assertEquals(2, result.length);
		    assertEquals(0.1f, result[0]);
		    assertEquals(0.2f, result[1]);
		}

    
    @Test
    public void testTokenize_basicInput() {
        EmbeddingService service = new EmbeddingService();
        long[][] result = service.tokenize("disk");
        assertNotNull(result);
        assertEquals(1, result.length);
        assertEquals(4, result[0].length); // "disk" has 4 characters
    }

    @Test
    public void testGenerateAttentionMask_basic() {
        EmbeddingService service = new EmbeddingService();
        long[][] inputIds = new long[][]{{1, 2, 3}};
        long[][] mask = service.generateAttentionMask(inputIds);
        assertEquals(1, mask.length);
        assertEquals(3, mask[0].length);
        for (long val : mask[0]) {
            assertEquals(1L, val);
        }
    }
    
    @Test
    public void testMeanPool_basic() {
        EmbeddingService service = new EmbeddingService();
        float[][] embeddings = {
            {1.0f, 2.0f},
            {3.0f, 4.0f},
            {5.0f, 6.0f}
        };
        float[] result = service.meanPool(embeddings);
        assertEquals(3.0f, result[0]);
        assertEquals(4.0f, result[1]);
    }
    
    @Test
    void testRealEmbeddingWithModel_loadsSuccessfully() throws Exception {
        String modelPath = System.getProperty("user.dir") + "/models/sentence_transformer_jina.onnx";
        java.nio.file.Path path = java.nio.file.Paths.get(modelPath);

        // Skip this test if ONNX model is missing
        if (!java.nio.file.Files.exists(path)) {
            System.out.println("⏩ Skipping real ONNX test - model not available at: " + modelPath);
            return;
        }

        EmbeddingService realService = new EmbeddingService();

        float[] embedding = realService.computeEmbedding("database failure");
        assertNotNull(embedding);
        assertTrue(embedding.length > 0);
        System.out.println("✅ Real ONNX embedding length: " + embedding.length);
    }



    @Test
    void testRealModel_fullCoverageOfOnnxMethods() throws Exception {
        String modelPath = System.getProperty("user.dir") + "/models/sentence_transformer_jina.onnx";
        Path path = Paths.get(modelPath);

        // ✅ Skip test if ONNX model file is missing
        Assumptions.assumeTrue(Files.exists(path), "ONNX model not found, skipping test");

        // ✅ Use real service, not a spy or override
        EmbeddingService realService = new EmbeddingService();

        // This will:
        // - Call loadModelIfNeeded()
        // - Call computeEmbedding()
        // - Call computeEmbeddingInternal()
        // - Cover all try-catch logic + ONNX tensor creation
        float[] result = realService.computeEmbedding("disk failure");

        assertNotNull(result);
        assertTrue(result.length > 0);
        System.out.println("✅ Embedding length: " + result.length);
    }
    
    
}
