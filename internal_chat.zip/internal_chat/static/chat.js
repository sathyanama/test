
let ws;
let username = "";

window.onload = () => {
    const nameField = document.getElementById("username");
    nameField.addEventListener("change", () => {
        username = nameField.value;
        if (!ws && username) {
            ws = new WebSocket(`ws://${location.host}/ws`);
            ws.onmessage = (event) => {
                const chatBox = document.getElementById("chatBox");
                chatBox.value += event.data + "\n";
                chatBox.scrollTop = chatBox.scrollHeight;
            };
        }
    });
};

function sendMessage() {
    const input = document.getElementById("messageInput");
    if (ws && input.value && username) {
        ws.send(username + ": " + input.value);
        input.value = "";
    }
}
