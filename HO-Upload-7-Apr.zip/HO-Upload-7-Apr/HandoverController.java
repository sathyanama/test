package com.example.demo.controller;

import com.example.demo.model.HandoverTracker;
import com.example.demo.model.User;
import com.example.demo.service.HandoverService;
import com.example.demo.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/handover")
@CrossOrigin(origins = "*")
public class HandoverController {

    @Autowired
    private HandoverService handoverService;
    
    @Autowired
    private UserService userService;

    // Fetch handover details    
    
    @GetMapping
    public Map<String, Object> getHandover(Principal principal) {
        String username = principal.getName();
        User user = userService.getUserByUsername(username);

        LocalDateTime now = LocalDateTime.now(ZoneId.of("America/New_York"));
        LocalDateTime shiftStart, shiftEnd, prevShiftStart, prevShiftEnd;

        boolean isUSUser = "US".equalsIgnoreCase(user.getLocation());
        boolean isSGUser = "SG".equalsIgnoreCase(user.getLocation());

        if (isUSUser) {
            // US Shift: 07:30 AM - 07:30 PM (Same Day)
            shiftStart = now.withHour(7).withMinute(30).withSecond(0).withNano(0);
            shiftEnd = now.withHour(19).withMinute(30).withSecond(0).withNano(0);

            // If US logs in between 04:00 AM - 08:00 AM → show SG shift (prev night)
            if (now.getHour() >= 4 && now.getHour() < 8) {
                prevShiftStart = now.withHour(19).withMinute(30).withSecond(0).withNano(0).minusDays(1);
                prevShiftEnd = now.withHour(7).withMinute(30).withSecond(0).withNano(0);
            } else {
                prevShiftStart = shiftStart;
                prevShiftEnd = shiftEnd;
            }
        } else {
            // SG Shift: 07:30 PM - 07:30 AM (Next Day)
            if (now.getHour() >= 0 && now.getHour() < 7) {
                // SG user logged in early morning → still part of previous night shift
                shiftStart = now.minusDays(1).withHour(19).withMinute(30).withSecond(0).withNano(0);
                shiftEnd = now.withHour(7).withMinute(30).withSecond(0).withNano(0);
            } else {
                shiftStart = now.withHour(19).withMinute(30).withSecond(0).withNano(0);
                shiftEnd = now.plusDays(1).withHour(7).withMinute(30).withSecond(0).withNano(0);
            }

            //  SG views US shift (07:30 AM - 07:30 PM) before 8:00 PM
            prevShiftStart = now.withHour(7).withMinute(30).withSecond(0).withNano(0);
            prevShiftEnd = now.withHour(19).withMinute(30).withSecond(0).withNano(0);
        }

        System.out.println("Checking Handover for Team: " + user.getTeam());
        System.out.println("Current Time: " + now);
        System.out.println("Current Shift Start: " + shiftStart);
        System.out.println("Current Shift End: " + shiftEnd);
        System.out.println("Previous Shift Start: " + prevShiftStart);
        System.out.println("Previous Shift End: " + prevShiftEnd);

        Optional<HandoverTracker> handoverOptional;

        // SG: check previous shift between 18:00-20:00
        // US: check previous shift between 04:00-08:00
        if ((isUSUser && now.getHour() >= 4 && now.getHour() < 8) ||
            (isSGUser && now.getHour() >= 18 && now.getHour() < 20)) {
            handoverOptional = handoverService.getHandoverByShift(user.getTeam(), prevShiftStart, prevShiftEnd);
        } else {
            handoverOptional = handoverService.getHandoverByShift(user.getTeam(), shiftStart, shiftEnd);
        }

        HandoverTracker handover = handoverOptional.orElseGet(() -> {
            HandoverTracker newHandover = new HandoverTracker();
            newHandover.setStartDate(shiftStart);
            newHandover.setEndDate(shiftEnd);
            newHandover.setHoItem(""); // Default blank
            return newHandover;
        });

        String heading = handoverService.getHandoverHeading(user.getLocation());
        return Map.of(
                "heading", heading,
                "handover", handover
        );
    }

     // Save or update handover
    @PostMapping("/save")
    public ResponseEntity<String> saveHandover(
            @RequestParam LocalDateTime startDate,
            @RequestParam LocalDateTime endDate,
            @RequestParam String hoItem,
            Principal principal) {

        String username = principal.getName();
        User user = userService.getUserByUsername(username);

        // Call the saveOrUpdateHandover method
        handoverService.saveOrUpdateHandover(user.getTeam(), startDate, endDate, hoItem, username);

        return ResponseEntity.ok("Handover saved successfully.");
    }
    
    @GetMapping("/retrieve")
    public Map<String, Object> retrieveHandover(
            @RequestParam String team,
            @RequestParam LocalDateTime startDate,
            @RequestParam LocalDateTime endDate) {

        Optional<HandoverTracker> handover = handoverService.getHandoverByTeamAndDates(team, startDate, endDate);

        // Handle empty response by returning null safely
        if (handover.isEmpty()) {
            return Collections.emptyMap(); // Prevents NullPointerException
        }

        return Map.of("handover", handover.get());
    }
}
