package com.example.demo.service;

import com.example.demo.model.ChatIncident;
import com.example.demo.repository.ChatIncidentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import java.lang.reflect.Method;


public class ChatIncidentServiceTest {

    @Mock
    private ChatIncidentRepository repository;

    @Mock
    private EmbeddingService embeddingService;

    @InjectMocks
    private ChatIncidentService chatIncidentService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testSearchIncidentsSqlFiltering_basicQuery() throws Exception {
        ChatIncident incident = new ChatIncident();
        incident.setId(1L);
        incident.setCustomerExp("Login failed due to timeout");
        incident.setEmbedding(new float[]{1.0f, 2.0f});

        // Since 'login' is NOT a meaningful keyword, use fetchIncidentsJava
        when(repository.fetchIncidentsJava(any())).thenReturn(new java.util.ArrayList<>(List.of(incident)));
        when(embeddingService.computeEmbedding(any())).thenReturn(new float[]{1.0f, 2.0f});

        List<ChatIncident> result = chatIncidentService.searchIncidentsSqlFiltering("login", "DMC");

        assertEquals(1, result.size());
        assertEquals(1L, result.get(0).getId());
    }
    
    @Test
    public void testSearchIncidentsSqlFiltering_noMatch() throws Exception {
        when(repository.fetchIncidentsJava(any())).thenReturn(Collections.emptyList());
        List<ChatIncident> result = chatIncidentService.searchIncidentsSqlFiltering("unknownquery", "DMC");
        assertTrue(result.isEmpty());
    }
    
    @Test
    public void testSearchIncidentsSqlFiltering_keywordFiltering() throws Exception {
        ChatIncident incident = new ChatIncident();
        incident.setId(2L);
        incident.setAnalysis("unable to login and make payment");
        incident.setEmbedding(new float[]{1.0f, 2.0f});

        when(repository.fetchIncidentsSql(any(), any())).thenReturn(new java.util.ArrayList<>(List.of(incident)));
        when(embeddingService.computeEmbedding(any())).thenReturn(new float[]{1.0f, 2.0f});

        List<ChatIncident> result = chatIncidentService.searchIncidentsSqlFiltering("unable to login and make payment", "DMC");

        assertEquals(1, result.size());
        assertEquals(2L, result.get(0).getId());
    }

    @Test
    public void testSearchIncidentsSqlFiltering_nullQueryEmbedding_throwsException() throws Exception {
        when(repository.fetchIncidentsJava(any())).thenReturn(List.of(new ChatIncident()));
        when(embeddingService.computeEmbedding(any())).thenReturn(null); // Simulate null embedding

        assertThrows(IllegalStateException.class, () -> {
            chatIncidentService.searchIncidentsSqlFiltering("cpu", "DMC");
        });
    }
    
    @Test
    public void testSearchIncidentsSqlFiltering_embeddingFails_logsError() throws Exception {
        ChatIncident incident = new ChatIncident();
        incident.setId(100L);
        incident.setCustomerExp("Disk error occurred");

        // Simulate fallback by adding dummy embedding manually to avoid cosineSimilarity crash
        incident.setEmbedding(new float[]{0.5f, 0.5f}); // Fallback dummy embedding

        // Mock fetch call
        when(repository.fetchIncidentsJava(any())).thenReturn(new ArrayList<>(List.of(incident)));

        // Simulate normal embedding for query
        when(embeddingService.computeEmbedding("disk")).thenReturn(new float[]{1.0f, 2.0f});

        // Simulate incident embedding failure (service should fallback to pre-set one above)
        when(embeddingService.computeEmbedding("Disk error occurred"))
            .thenThrow(new RuntimeException("Simulated embedding failure"));

        List<ChatIncident> result = chatIncidentService.searchIncidentsSqlFiltering("disk", "DMC");

        assertEquals(1, result.size());
        assertEquals(100L, result.get(0).getId());
    }

    @Test
    public void testSearchIncidentsSqlFiltering_incidentEmbeddingNull_fallback() throws Exception {
        ChatIncident incident = new ChatIncident();
        incident.setId(200L);
        incident.setCustomerExp("Memory alert");
        incident.setEmbedding(null); // Simulate missing embedding

        when(repository.fetchIncidentsJava(any())).thenReturn(new ArrayList<>(List.of(incident)));
        when(embeddingService.computeEmbedding(any())).thenReturn(new float[]{1.0f, 2.0f});
        List<ChatIncident> result = chatIncidentService.searchIncidentsSqlFiltering("memory", "DMC");

        assertEquals(1, result.size());
        assertEquals(200L, result.get(0).getId());
    }
    
    @Test
    public void testSearchIncidentsSqlFiltering_lessThanFiveFallback() throws Exception {
        ChatIncident incident = new ChatIncident();
        incident.setId(300L);
        incident.setCustomerExp("Login failed");
        incident.setEmbedding(new float[]{1.0f, 2.0f});

        when(repository.fetchIncidentsJava(any())).thenReturn(new ArrayList<>(List.of(incident)));
        when(embeddingService.computeEmbedding(any())).thenReturn(new float[]{1.0f, 2.0f});

        List<ChatIncident> result = chatIncidentService.searchIncidentsSqlFiltering("login", "DMC");

        assertEquals(1, result.size()); // Should return at least 1 even if filtering fails
    }
    
    @Test
    public void testDetermineTextForEmbedding_allFieldsEmpty_returnsNull() throws Exception {
        ChatIncident incident = new ChatIncident(); // all fields null
        Method method = ChatIncidentService.class.getDeclaredMethod("determineTextForEmbedding", ChatIncident.class);
        method.setAccessible(true);

        String result = (String) method.invoke(chatIncidentService, incident);
        assertNull(result);
    }
    
    @Test
    public void testDetermineTextForEmbedding_analysisFallback() throws Exception {
        ChatIncident incident = new ChatIncident();
        incident.setAnalysis("Disk failure analysis");

        Method method = ChatIncidentService.class.getDeclaredMethod("determineTextForEmbedding", ChatIncident.class);
        method.setAccessible(true);

        String result = (String) method.invoke(chatIncidentService, incident);
        assertEquals("Disk failure analysis", result);
    }

    @Test
    public void testDetermineTextForEmbedding_alertNameFallback() throws Exception {
        ChatIncident incident = new ChatIncident();
        incident.setAlertName("CPU_ALERT_001");

        Method method = ChatIncidentService.class.getDeclaredMethod("determineTextForEmbedding", ChatIncident.class);
        method.setAccessible(true);

        String result = (String) method.invoke(chatIncidentService, incident);
        assertEquals("CPU_ALERT_001", result);
    }
    
    @Test
    public void testSearchIncidentsSqlFiltering_fallbackToTop5() throws Exception {
        List<ChatIncident> dummyList = new ArrayList<>();
        for (int i = 1; i <= 6; i++) {
            ChatIncident ci = new ChatIncident();
            ci.setId((long) i);
            ci.setCustomerExp("CPU usage high " + i);
            ci.setEmbedding(new float[]{1.0f + i, 2.0f + i});
            dummyList.add(ci);
        }

        when(repository.fetchIncidentsJava(any())).thenReturn(dummyList);
        when(embeddingService.computeEmbedding(any())).thenReturn(new float[]{1.0f, 2.0f});

        List<ChatIncident> result = chatIncidentService.searchIncidentsSqlFiltering("cpu", "DMC");

        assertEquals(5, result.size()); // top 5 returned
    }
    
    @Test
    public void testSearchIncidentsSqlFiltering_fallbackToOne() throws Exception {
        ChatIncident incident = new ChatIncident();
        incident.setId(99L);
        incident.setCustomerExp("High memory usage");
        incident.setEmbedding(new float[]{});

        when(repository.fetchIncidentsJava(any())).thenReturn(new ArrayList<>(List.of(incident)));
        when(embeddingService.computeEmbedding(any())).thenReturn(new float[]{1.0f, 2.0f});

        List<ChatIncident> result = chatIncidentService.searchIncidentsSqlFiltering("memory", "DMC");

        assertEquals(1, result.size()); // returns 1 even if filtering fails
        assertEquals(99L, result.get(0).getId());
    }



   
}