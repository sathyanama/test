package com.example.demo.config;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordVerificationUtil {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

        // Raw password entered by the user
        String rawPassword = "password";

        // Encrypted password from the database
        String storedHash = "$2a$10$7q0C/m0U8LmgWJQs6W7J/e9zC9L2eq/TPqCvCfsRbd9zP4wo.uyrm";

        // Verify if the raw password matches the stored hash
        boolean matches = encoder.matches(rawPassword, storedHash);

        System.out.println("Password matches: " + matches);
    }
}

