package com.example.demo.config;

import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Base64;

public class Base64PasswordEncoder implements PasswordEncoder {

    @Override
    public String encode(CharSequence rawPassword) {
        // Encode the raw password using Base64
    	 String encoded = Base64.getEncoder().encodeToString(rawPassword.toString().getBytes());
         System.out.println("[DEBUG] Raw password to encode: " + rawPassword); // Print raw password
         System.out.println("[DEBUG] Encoded password: " + encoded); // Print encoded password
        return Base64.getEncoder().encodeToString(rawPassword.toString().getBytes());
    }

    @Override
    public boolean matches(CharSequence rawPassword, String encodedPassword) {
        // Compare the encoded version of the raw password with the stored encoded password
        String encodedRawPassword = encode(rawPassword);
        
        System.out.println("[DEBUG] Raw password: " + rawPassword); // Print raw password
        System.out.println("[DEBUG] Stored password (from DB): " + encodedPassword); // Print stored password
        System.out.println("[DEBUG] Passwords match: " + encodedRawPassword.equals(encodedPassword)); // Print match result
        
        
        return encodedRawPassword.equals(encodedPassword);
    }
}