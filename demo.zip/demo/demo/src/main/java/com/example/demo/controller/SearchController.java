package com.example.demo.controller;

import com.example.demo.model.IncidentTracker;
import com.example.demo.model.User;
import com.example.demo.service.IncidentTrackerService;
import com.example.demo.service.LogInfoService;
import com.example.demo.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@RestController
public class SearchController {
	
	
	private static final Logger logger = LoggerFactory.getLogger(SearchController.class);

	@Autowired
    private UserService userService;
	
	@Autowired
    private LogInfoService logInfoService;
	
    @Autowired
    private IncidentTrackerService incidentTrackerService;

    @GetMapping("/search/last50")
    @ResponseBody
    public Page<IncidentTracker> getLast50Records(@RequestParam("page") int page,
                                                  @RequestParam("size") int size,
                                                  HttpServletRequest request) {
    	
    	String team=getTeamDetails(request,"landing_page");
    	
        if (team == null) {
        	logger.error("Team not found in session.");
            throw new RuntimeException("Team not found in session");
        }               
        logger.debug("Fetching last 50 records [{}]", team);
        
        //return incidentTrackerService.findLast50RecordsPaginated(team, page, size); // with team
        return incidentTrackerService.findLast50RecordsWithoutTeam(page, size); //without team
    }
   
	@GetMapping("/search/query")
    @ResponseBody
    public Page<IncidentTracker> searchPaginated(@RequestParam("query") String query,
                                                 @RequestParam("page") int page,
                                                 @RequestParam("size") int size,
                                                 HttpServletRequest request) {
        // Get team from session
		String team=getTeamDetails(request,"page_search");
        
        if (team == null) {
        	logger.error("Team not found in session.");
            throw new RuntimeException("Team not found in session");
        }
        logger.debug("Fetching last 50 records [{}]", team);
        //return incidentTrackerService.searchPaginated(query, team, page, size); //with team
        return incidentTrackerService.searchPaginatedWithoutTeam(query, page, size); // without team
    }
	
	
	 private String getTeamDetails(HttpServletRequest request, String screenId) {
	    	
	    	// Get team from user 
	    	HttpSession session = request.getSession();
			
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	        String username = authentication.getName();
	        
	        User user = userService.getUserByUsername(username);
	        
	        System.out.println("UserName: " + username);
	        System.out.println("Http Session Id: " + session);
	        System.out.println("Session Id: " + request.getSession().getId());        
	        System.out.println("Team Name: " + user.getTeam());
	        	        
	        String team = user.getTeam();	
	        
	        logInfoService.logActivity(session.getId(), screenId, username);  
	        
			return team;
		}
}
