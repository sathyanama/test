package com.example.demo.repository;

import com.example.demo.model.PullIncident;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PullIncidentRepository extends JpaRepository<PullIncident, Long> {
    Optional<PullIncident> findByIncidentNumber(String incidentNumber);
}
