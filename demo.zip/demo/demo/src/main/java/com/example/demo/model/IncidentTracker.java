package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(
	name = "incident_tracker",
    uniqueConstraints = {@UniqueConstraint(columnNames = {"incident_number", "team"})}
)
public class IncidentTracker {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "incident_number", nullable = false)
    private String incidentNumber;

    @Column(name = "create_by", nullable = false)
    private String createBy;

    @Column(name = "create_datetime", nullable = false)
    private LocalDateTime createDatetime;

    @Column(name = "team", nullable = false)
    private String team;

    @Column(name = "start_datetime")
    private LocalDateTime startDatetime;

    @Column(name = "deduct_datetime")
    private LocalDateTime deductDatetime;

    @Column(name = "diagnose_datetime")
    private LocalDateTime diagnoseDatetime;

    @Column(name = "mitigate_datetime")
    private LocalDateTime mitigateDatetime;

    @Column(name = "resolve_datetime")
    private LocalDateTime resolveDatetime;

    @Column(name = "mc_engage_datetime")
    private LocalDateTime mcEngageDatetime;

    @Column(name = "customer_exp", nullable = false, length = 1000)
    private String customerExp;

    @Lob
    @Column(name = "analysis")
    private String analysis;

    @Column(name = "impact_count")
    private Integer impactCount;

    @Column(name = "flow", length = 500)
    private String flow;

    @Column(name = "update_user", nullable = false)
    private String updateUser;

    @Column(name = "update_datetime", nullable = false)
    private LocalDateTime updateDatetime;
    
    // New Fields
    @Column(name = "alert_name", length = 500)
    private String alertName;

    @Column(name = "flag_item", nullable = false)
    private Boolean flagItem;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getIncidentNumber() {
        return incidentNumber;
    }

    public void setIncidentNumber(String incidentNumber) {
        this.incidentNumber = incidentNumber;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public LocalDateTime getCreateDatetime() {
        return createDatetime;
    }

    public void setCreateDatetime(LocalDateTime createDatetime) {
        this.createDatetime = createDatetime;
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(String team) {
        this.team = team;
    }

    public LocalDateTime getStartDatetime() {
        return startDatetime;
    }

    public void setStartDatetime(LocalDateTime startDatetime) {
        this.startDatetime = startDatetime;
    }

    public LocalDateTime getDeductDatetime() {
        return deductDatetime;
    }

    public void setDeductDatetime(LocalDateTime deductDatetime) {
        this.deductDatetime = deductDatetime;
    }

    public LocalDateTime getDiagnoseDatetime() {
        return diagnoseDatetime;
    }

    public void setDiagnoseDatetime(LocalDateTime diagnoseDatetime) {
        this.diagnoseDatetime = diagnoseDatetime;
    }

    public LocalDateTime getMitigateDatetime() {
        return mitigateDatetime;
    }

    public void setMitigateDatetime(LocalDateTime mitigateDatetime) {
        this.mitigateDatetime = mitigateDatetime;
    }

    public LocalDateTime getResolveDatetime() {
        return resolveDatetime;
    }

    public void setResolveDatetime(LocalDateTime resolveDatetime) {
        this.resolveDatetime = resolveDatetime;
    }

    public LocalDateTime getMcEngageDatetime() {
        return mcEngageDatetime;
    }

    public void setMcEngageDatetime(LocalDateTime mcEngageDatetime) {
        this.mcEngageDatetime = mcEngageDatetime;
    }

    public String getCustomerExp() {
        return customerExp;
    }

    public void setCustomerExp(String customerExp) {
        this.customerExp = customerExp;
    }

    public String getAnalysis() {
        return analysis;
    }

    public void setAnalysis(String analysis) {
        this.analysis = analysis;
    }

    public Integer getImpactCount() {
        return impactCount;
    }

    public void setImpactCount(Integer impactCount) {
        this.impactCount = impactCount;
    }

    public String getFlow() {
        return flow;
    }

    public void setFlow(String flow) {
        this.flow = flow;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public LocalDateTime getUpdateDatetime() {
        return updateDatetime;
    }

    public void setUpdateDatetime(LocalDateTime updateDatetime) {
        this.updateDatetime = updateDatetime;
    }
    
    public String getAlertName() {
        return alertName;
    }

    public void setAlertName(String alertName) {
        this.alertName = alertName;
    }

    public Boolean getFlagItem() {
        return flagItem;
    }

    public void setFlagItem(Boolean flagItem) {
        this.flagItem = flagItem;
    }
}

