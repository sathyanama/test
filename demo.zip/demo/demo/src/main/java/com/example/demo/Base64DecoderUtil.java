package com.example.demo;

import java.util.Base64;

public class Base64DecoderUtil {
    public static void main(String[] args) {
        String encodedPassword = "cGFzc3dvcmQ="; // Replace with your actual encoded password
        String decodedPassword = new String(Base64.getDecoder().decode(encodedPassword));
        System.out.println("Decoded Password: " + decodedPassword);
    }
}

