package com.example.demo.controller;

import com.example.demo.model.IncidentTracker;
import com.example.demo.service.IncidentTrackerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api/incidents")
public class IncidentTrackerController {
	
	private static final Logger logger = LoggerFactory.getLogger(IncidentTrackerController.class);

    @Autowired
    private IncidentTrackerService incidentTrackerService;

    @PostMapping("/create")
    public IncidentTracker createIncident(@RequestBody IncidentTracker incidentTracker) {
    	logger.debug("Create Incident successfully");
        return incidentTrackerService.createIncident(incidentTracker);
    }

    @PutMapping("/update")
    public IncidentTracker updateIncident(@RequestBody IncidentTracker incidentTracker) {
    	
    	logger.debug("Incident [{}] updated successfully");
        return incidentTrackerService.updateIncident(incidentTracker);
    }

    @GetMapping("/get")
    public IncidentTracker getIncident(@RequestParam String incidentNumber, @RequestParam String team) {
        return incidentTrackerService.getIncidentByNumberAndTeam(incidentNumber, team)
                .orElseThrow(() -> new IllegalArgumentException("Incident not found for the given number and team."));
    }
}

