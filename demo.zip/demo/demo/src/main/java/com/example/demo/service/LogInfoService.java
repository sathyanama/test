package com.example.demo.service;

import com.example.demo.model.LogInfo;
import com.example.demo.repository.LogInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

@Service
public class LogInfoService {

	@Autowired
	private LogInfoRepository logInfoRepository;

	public void logActivity(String sessionId, String screenId, String username, String exception, String responseCode) {
	    LogInfo log = new LogInfo();
	    log.setSessionId(sessionId);
	    log.setScreenId(screenId);
	    log.setUsername(username);

	    // Set the timestamp in EST
	    ZonedDateTime estTime = ZonedDateTime.now(ZoneId.of("America/New_York"));
	    log.setLogDatetime(estTime.toLocalDateTime());

	    log.setException(exception);
	    log.setResponseCode(responseCode);

	    // Save to database
	    logInfoRepository.save(log);
	}

    // Overloaded method for logs without exception or responseCode
    public void logActivity(String sessionId, String screenId, String username) {
        logActivity(sessionId, screenId, username, "Success", "200"); // Default success response
    }
}
