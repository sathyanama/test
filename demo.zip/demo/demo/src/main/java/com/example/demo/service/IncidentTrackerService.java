package com.example.demo.service;

import com.example.demo.dto.IncidentTrackerDTO;
import com.example.demo.model.IncidentTracker;
import com.example.demo.repository.IncidentTrackerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.time.LocalDateTime;
import java.time.Year;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class IncidentTrackerService {
	
    private static final Logger logger = LoggerFactory.getLogger(IncidentTrackerService.class);


    @Autowired
    private IncidentTrackerRepository incidentTrackerRepository;

    // Create an incident
    public IncidentTracker createIncident(IncidentTracker incidentTracker) {
        logger.info("Creating incident with Incident Number [{}] and Team [{}]", 
            incidentTracker.getIncidentNumber(), incidentTracker.getTeam());
        
        // Ensure the combination of `incident_number` and `team` is unique
        Optional<IncidentTracker> existingIncident = incidentTrackerRepository.findByIncidentNumberAndTeam(
                incidentTracker.getIncidentNumber(), incidentTracker.getTeam());
        if (existingIncident.isPresent()) {
            throw new IllegalArgumentException("Incident already exists for this team.");
        }
        return incidentTrackerRepository.save(incidentTracker);
    }

    // Update an incident
    public IncidentTracker updateIncident(IncidentTracker incidentTracker) {
    	
        logger.info("Updating incident with Incident Number [{}] and Team [{}]", 
            incidentTracker.getIncidentNumber(), incidentTracker.getTeam());

        // Ensure the incident exists before updating
        Optional<IncidentTracker> existingIncident = incidentTrackerRepository.findByIncidentNumberAndTeam(
                incidentTracker.getIncidentNumber(), incidentTracker.getTeam());
        if (existingIncident.isEmpty()) {
            throw new IllegalArgumentException("Incident does not exist for the given team.");
        }
        
        
        ZoneId estZoneId = ZoneId.of("America/New_York");
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        
        logger.info("Updating username with Incident Number [{}] and Team [{}] and User [{}]", 
                incidentTracker.getIncidentNumber(), incidentTracker.getTeam(), username);
        
        IncidentTracker existing = existingIncident.get();
        
        // Update values only if they are not null
        if (incidentTracker.getStartDatetime() != null) {
            existing.setStartDatetime(incidentTracker.getStartDatetime());
        }
        if (incidentTracker.getDeductDatetime() != null) {
            existing.setDeductDatetime(incidentTracker.getDeductDatetime());
        }
        if (incidentTracker.getDiagnoseDatetime() != null) {
            existing.setDiagnoseDatetime(incidentTracker.getDiagnoseDatetime());
        }
        if (incidentTracker.getMitigateDatetime() != null) {
            existing.setMitigateDatetime(incidentTracker.getMitigateDatetime());
        }
        if (incidentTracker.getResolveDatetime() != null) {
            existing.setResolveDatetime(incidentTracker.getResolveDatetime());
        }
        if (incidentTracker.getMcEngageDatetime() != null) {
            existing.setMcEngageDatetime(incidentTracker.getMcEngageDatetime());
        }
        
        existing.setCustomerExp(incidentTracker.getCustomerExp());
        existing.setAnalysis(incidentTracker.getAnalysis());
        existing.setImpactCount(incidentTracker.getImpactCount());
        existing.setFlow(incidentTracker.getFlow());
        existing.setAlertName(incidentTracker.getAlertName());
        existing.setFlagItem(incidentTracker.getFlagItem());
        existing.setUpdateUser(username);
        existing.setUpdateDatetime(convertToEST(LocalDateTime.now(), estZoneId));
        
        return incidentTrackerRepository.save(existing);
        
        //return incidentTrackerRepository.save(incidentTracker);
    }
    
    
    
 // Update an incident
    public IncidentTracker updateIncidentDTO(IncidentTracker incidentTracker, IncidentTrackerDTO incidentDTO) {
        
    	logger.info("Updating incident with Incident Number in DTO [{}] and Team [{}]", 
                incidentTracker.getIncidentNumber(), incidentTracker.getTeam());

        // Ensure the incident exists before updating
        Optional<IncidentTracker> existingIncident = incidentTrackerRepository.findByIncidentNumberAndTeam(
                incidentTracker.getIncidentNumber(), incidentTracker.getTeam());
        if (existingIncident.isEmpty()) {
            throw new IllegalArgumentException("Incident does not exist for the given team.");
        }

        IncidentTracker existing = existingIncident.get();

        // Convert LocalDateTime to EST before saving
        ZoneId estZoneId = ZoneId.of("America/New_York");

        if (incidentTracker.getStartDatetime() != null) {
            existing.setStartDatetime(convertToEST(incidentTracker.getStartDatetime(), estZoneId));
        }
        if (incidentTracker.getDeductDatetime() != null) {
            existing.setDeductDatetime(convertToEST(incidentTracker.getDeductDatetime(), estZoneId));
        }
        if (incidentTracker.getDiagnoseDatetime() != null) {
            existing.setDiagnoseDatetime(convertToEST(incidentTracker.getDiagnoseDatetime(), estZoneId));
        }
        if (incidentTracker.getMitigateDatetime() != null) {
            existing.setMitigateDatetime(convertToEST(incidentTracker.getMitigateDatetime(), estZoneId));
        }
        if (incidentTracker.getResolveDatetime() != null) {
            existing.setResolveDatetime(convertToEST(incidentTracker.getResolveDatetime(), estZoneId));
        }
        if (incidentTracker.getMcEngageDatetime() != null) {
            existing.setMcEngageDatetime(convertToEST(incidentTracker.getMcEngageDatetime(), estZoneId));
        }

        //logger.info("getCustomerExp", incidentTracker.getCustomerExp());
        //logger.info("getAnalysis", incidentTracker.getAnalysis());
        
        System.out.println("getCustomerExp" + incidentTracker.getCustomerExp());
        System.out.println("getAnalysis" + incidentTracker.getAnalysis());
        System.out.println("getAnalysis" + incidentTracker.getFlow());
                
        
        existing.setCustomerExp(incidentTracker.getCustomerExp());
        existing.setAnalysis(incidentTracker.getAnalysis());
        existing.setImpactCount(incidentTracker.getImpactCount());
        existing.setFlow(incidentTracker.getFlow());
        existing.setAlertName(incidentTracker.getAlertName());
        existing.setFlagItem(incidentTracker.getFlagItem());
        existing.setUpdateUser(incidentTracker.getUpdateUser());
        existing.setUpdateDatetime(convertToEST(LocalDateTime.now(), estZoneId));

        return incidentTrackerRepository.save(existing);
    }
    
    
    private LocalDateTime convertToEST(LocalDateTime dateTime, ZoneId estZoneId) {
        return ZonedDateTime.of(dateTime, ZoneId.systemDefault()) // From default system timezone
                .withZoneSameInstant(estZoneId)                   // Convert to EST
                .toLocalDateTime();                               // Return LocalDateTime in EST
    }
    
    // Save or update an incident
    public IncidentTracker saveIncident(IncidentTracker incidentTracker) {
        logger.debug("Saving incident: {}", incidentTracker.getIncidentNumber());
        return incidentTrackerRepository.save(incidentTracker);
    }

    // Retrieve incident by incident number
    public Optional<IncidentTracker> getIncidentByNumber(String incidentNumber) {
        return incidentTrackerRepository.findByIncidentNumber(incidentNumber);
    }

    // Delete an incident by incident number
    public void deleteIncident(String incidentNumber) {
        logger.info("Deleting incident with Incident Number [{}]", incidentNumber);
        
        Optional<IncidentTracker> existingIncident = incidentTrackerRepository.findByIncidentNumber(incidentNumber);
        if (existingIncident.isEmpty()) {
            throw new IllegalArgumentException("Incident does not exist.");
        }
        incidentTrackerRepository.deleteByIncidentNumber(incidentNumber);
    }

    // Save a list of incidents
    public void saveAll(List<IncidentTracker> incidents) {
        incidentTrackerRepository.saveAll(incidents);
    }
    
    public Optional<IncidentTracker> getIncidentByNumberAndTeam(String incidentNumber, String team) {
        return incidentTrackerRepository.findByIncidentNumberAndTeam(incidentNumber, team);
    }
    
    /**
     * Finds the last 50 records from the current year with pagination.
     *
     * @param page Current page number (1-based index).
     * @param size Number of records per page.
     * @return A Page object containing paginated results.
     */
    public Page<IncidentTracker> findLast50RecordsPaginated(String team, int page, int size) {
        Pageable pageable = Pageable.ofSize(size).withPage(page - 1);
        int currentYear = Year.now().getValue();
        currentYear=currentYear-2;
        LocalDateTime startOfYear = LocalDateTime.of(currentYear, 1, 1, 0, 0);
        logger.debug("Fetching last 50 records for team [{}]", team);

        return incidentTrackerRepository.findByCreateDatetimeAfterAndTeamOrderByCreateDatetimeDesc(
                startOfYear, team, pageable);
    }

    /**
     * Searches records by the given query with pagination.
     *
     * @param query The search query (Incident Number, Customer Exp, or Alert).
     * @param page  Current page number (1-based index).
     * @param size  Number of records per page.
     * @return A Page object containing paginated results.
     */   
    
    public Page<IncidentTracker> searchPaginated(String query, String team, int page, int size) {
        Pageable pageable = Pageable.ofSize(size).withPage(page - 1);
        
        logger.debug("searchPaginated for team [{}]", team);

        return incidentTrackerRepository.searchByQueryAndTeam(query, team, pageable);
    }
    
    
    
    /**
     * Finds the last 50 records from the current year with pagination.
     *
     * @param page Current page number (1-based index).
     * @param size Number of records per page.
     * @return A Page object containing paginated results.
     */
    public Page<IncidentTracker> findLast50RecordsWithoutTeam(int page, int size) {
        Pageable pageable = Pageable.ofSize(size).withPage(page - 1);
        int currentYear = Year.now().getValue();
        currentYear=currentYear-2;
        LocalDateTime startOfYear = LocalDateTime.of(currentYear, 1, 1, 0, 0);
        logger.debug("Fetching last 50 records for team [{}]", currentYear);

        return incidentTrackerRepository.findByCreateDatetimeWithoutTeam(
                startOfYear, pageable);
    }

    /**
     * Searches records by the given query with pagination.
     *
     * @param query The search query (Incident Number, Customer Exp, or Alert).
     * @param page  Current page number (1-based index).
     * @param size  Number of records per page.
     * @return A Page object containing paginated results.
     */   
    
    public Page<IncidentTracker> searchPaginatedWithoutTeam(String query,  int page, int size) {
        Pageable pageable = Pageable.ofSize(size).withPage(page - 1);
        
        logger.debug("searchPaginated for Query [{}]", query);

        return incidentTrackerRepository.searchByQueryWithoutTeam(query,pageable);
    }
    
    
    
    public List<IncidentTracker> findLast20ByTeam(String team) {
        Pageable pageable = PageRequest.of(0, 20, Sort.by(Sort.Direction.DESC, "createDatetime"));
        return incidentTrackerRepository.findTop20ByTeam(team, pageable);
    }
    
    public List<IncidentTracker> findIncidentsBySearchCriteria(String query, String team) {
        return incidentTrackerRepository.findIncidentsBySearchCriteria(query, team);
    }
    
    
}

