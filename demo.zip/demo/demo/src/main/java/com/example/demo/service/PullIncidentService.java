package com.example.demo.service;

import com.example.demo.model.PullIncident;
import com.example.demo.repository.PullIncidentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PullIncidentService {

    @Autowired
    private PullIncidentRepository pullIncidentRepository;

    public Optional<PullIncident> getIncidentByNumber(String incidentNumber) {
        return pullIncidentRepository.findByIncidentNumber(incidentNumber);
    }
}
