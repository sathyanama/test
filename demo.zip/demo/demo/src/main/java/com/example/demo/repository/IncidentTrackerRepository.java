package com.example.demo.repository;

import com.example.demo.model.IncidentTracker;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface IncidentTrackerRepository extends JpaRepository<IncidentTracker, Long> {

    // Find incident by incident number
    Optional<IncidentTracker> findByIncidentNumber(String incidentNumber);

    // Find incident by incident number and team
    Optional<IncidentTracker> findByIncidentNumberAndTeam(String incidentNumber, String team);

    // Delete incident by incident number
    void deleteByIncidentNumber(String incidentNumber);

    // Fetch the last 50 records from the current year with pagination
    Page<IncidentTracker> findByCreateDatetimeAfterAndTeamOrderByCreateDatetimeDesc(
        LocalDateTime createDatetime, String team, Pageable pageable);

    // Search records by query and team with pagination
    @Query(value = "SELECT * FROM incident_tracker i " +
            "WHERE i.team = :team " +
            "AND (UPPER(i.incident_number) LIKE UPPER(CONCAT('%', :query, '%')) " +
            "OR UPPER(i.customer_exp) LIKE UPPER(CONCAT('%', :query, '%')) " +
            "OR UPPER(CAST(i.analysis AS VARCHAR)) LIKE UPPER(CONCAT('%', :query, '%'))) " +
            "ORDER BY i.create_datetime DESC",
    nativeQuery = true)
    Page<IncidentTracker> searchByQueryAndTeam(@Param("query") String query, 
                                        @Param("team") String team, 
                                        Pageable pageable);

    // Fetch the top 50 incidents globally (no filtering by team)
    @Query("SELECT i FROM IncidentTracker i ORDER BY i.createDatetime DESC")
    Page<IncidentTracker> findTop50ByOrderByCreateDatetimeDesc(Pageable pageable);

    // Fetch incidents filtered by team, ordered by creation date
    Page<IncidentTracker> findByTeamOrderByCreateDatetimeDesc(String team, Pageable pageable);
    
 // Query to fetch the last 20 records by creation date for a specific team
    @Query("SELECT i FROM IncidentTracker i WHERE i.team = :team ORDER BY i.createDatetime DESC")
    List<IncidentTracker> findTop20ByTeam(@Param("team") String team, Pageable pageable);

    // Fetch the last 50 records from the current year with pagination and without Team
    @Query("SELECT i FROM IncidentTracker i WHERE i.createDatetime >= :startOfYear ORDER BY i.createDatetime DESC")
    Page<IncidentTracker> findByCreateDatetimeWithoutTeam(@Param("startOfYear") LocalDateTime startOfYear, Pageable pageable);

	// Search records by query with pagination
    @Query(value = "SELECT * FROM incident_tracker i " +
            "WHERE (UPPER(i.incident_number) LIKE UPPER(CONCAT('%', :query, '%')) " +
            "OR UPPER(i.customer_exp) LIKE UPPER(CONCAT('%', :query, '%')) " +
            "OR UPPER(CAST(i.analysis AS VARCHAR)) LIKE UPPER(CONCAT('%', :query, '%'))) " +
            "ORDER BY i.create_datetime DESC",
    nativeQuery = true)
    Page<IncidentTracker> searchByQueryWithoutTeam(@Param("query") String query,                                         
                                        Pageable pageable);
    
    // Dashboard Landing Page Search Criteria 
    @Query(value = "SELECT * FROM incident_tracker i " +
            "WHERE i.team = :team " +
            "AND (UPPER(i.incident_number) LIKE UPPER(CONCAT('%', :query, '%')) " +
            "OR UPPER(i.customer_exp) LIKE UPPER(CONCAT('%', :query, '%')) " +
            "OR UPPER(CAST(i.analysis AS VARCHAR)) LIKE UPPER(CONCAT('%', :query, '%')) " +
            "OR LOWER(i.alert_name) LIKE LOWER(CONCAT('%', :query, '%'))) " +
            "ORDER BY i.create_datetime DESC", nativeQuery = true)
    List<IncidentTracker> findIncidentsBySearchCriteria(@Param("query") String query, @Param("team") String team);
	
}
