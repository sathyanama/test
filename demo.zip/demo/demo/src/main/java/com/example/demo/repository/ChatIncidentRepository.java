package com.example.demo.repository;

import com.example.demo.model.ChatIncident;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ChatIncidentRepository extends JpaRepository<ChatIncident, Long> {


    
    @Query(value = "SELECT * FROM incident_tracker i " +
            "WHERE i.team = :team " +
            "AND (UPPER(i.incident_number) LIKE UPPER(CONCAT('%', :query, '%')) " +
            "OR UPPER(i.customer_exp) LIKE UPPER(CONCAT('%', :query, '%')) " +
            "OR UPPER(CAST(i.analysis AS VARCHAR)) LIKE UPPER(CONCAT('%', :query, '%'))) " +
            "ORDER BY i.create_datetime DESC LIMIT 5",
    nativeQuery = true)
    List<ChatIncident> searchByQueryAndTeam(@Param("query") String query, @Param("team") String team);
}
