package com.example.demo.service;

import com.example.demo.model.ChatIncident;
import com.example.demo.repository.ChatIncidentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ChatIncidentService {

    @Autowired
    private ChatIncidentRepository chatIncidentRepository;

    public List<ChatIncident> searchIncidents(String query, String team) {
        return chatIncidentRepository.searchByQueryAndTeam(query, team);
    }
}
