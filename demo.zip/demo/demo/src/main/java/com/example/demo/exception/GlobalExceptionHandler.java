package com.example.demo.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(IllegalArgumentException.class)
    public String handleIllegalArgumentException(IllegalArgumentException exception, Model model) {
        logger.error("Error occurred: Status Code [{}], Message [{}], Exception [{}]",
                HttpStatus.INTERNAL_SERVER_ERROR.value(), exception.getMessage(), exception);

        model.addAttribute("statusCode", HttpStatus.INTERNAL_SERVER_ERROR.value());
        model.addAttribute("errorMessage", exception.getMessage());
        model.addAttribute("requestUri", ""); // Optionally, include the request URI if available.

        return "error"; // Renders the error.html page
    }

    @ExceptionHandler(Exception.class)
    public String handleGenericException(Exception exception, Model model) {
        logger.error("Error occurred: Status Code [{}], Message [{}], Exception [{}]",
                HttpStatus.INTERNAL_SERVER_ERROR.value(), exception.getMessage(), exception);

        model.addAttribute("statusCode", HttpStatus.INTERNAL_SERVER_ERROR.value());
        model.addAttribute("errorMessage", "An unexpected error occurred");
        model.addAttribute("requestUri", "");

        return "error";
    }
}
