package com.example.demo.controller;

import com.example.demo.dto.IncidentTrackerDTO;
import com.example.demo.model.IncidentTracker;
import com.example.demo.model.PullIncident;
import com.example.demo.service.IncidentTrackerService;
import com.example.demo.service.PullIncidentService;
import com.example.demo.model.User;
import com.example.demo.service.LogInfoService;
import com.example.demo.service.UserService;
import com.example.demo.model.ChatIncident;
import com.example.demo.service.ChatIncidentService;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.Principal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.security.crypto.password.PasswordEncoder;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.WebAttributes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class UserController {
	
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;
    
    @Autowired
    private PasswordEncoder passwordEncoder; // Inject the PasswordEncoder bean
    
    @Autowired
    private LogInfoService logInfoService;

    @Autowired
    private IncidentTrackerService incidentTrackerService;
    
    @Autowired
    private PullIncidentService pullIncidentService;
    
    @Autowired
    private ChatIncidentService chatIncidentService;
    
    @GetMapping("/")
    public String rootRedirect(HttpServletRequest request) {
        // Check if the user is already logged in
        
        if (request.getUserPrincipal() != null) {
            return "redirect:/dashboard"; // Redirect logged-in users to the dashboard
        }
        return "redirect:/login"; // Redirect unauthenticated users to the login page
    }

    @GetMapping("/login")
    public String login(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession(false); // Get the session if it exists

        if (session != null) {
            // Check if an authentication exception exists
            AuthenticationException authException = 
                (AuthenticationException) session.getAttribute(WebAttributes.AUTHENTICATION_EXCEPTION);

            if (authException != null) {
                model.addAttribute("errorMessage", authException.getMessage()); // Add custom error message to the model
            }
        }

        return "login"; // Redirect to login.html
    }
    
    

    @GetMapping("/register")
    public String showRegisterPage() {
        return "register"; // Thymeleaf template for the register page
    }
    
    @PostMapping("/register")
    public String register(@RequestParam String uName, 
                           @RequestParam String emailid,                            
                           @RequestParam String username, 
                           @RequestParam String password
                           ) {
        // Debugging log
        System.out.println("Received Registration Data: ");
        System.out.println("Name: " + uName);
        System.out.println("Email ID: " + emailid);        
        System.out.println("Username: " + username);        
        

        // Save user to the database
        userService.registerUser(uName, emailid,  username, password);

        return "redirect:/login?success=true";
    }
    
    
    @PostMapping("/registerAdmin")
    public String registerAdmin(@RequestParam String uName, 
                           @RequestParam String emailid, 
                           @RequestParam String team, 
                           @RequestParam String username, 
                           @RequestParam String password, 
                           @RequestParam String role) {
        // Debugging log
        System.out.println("Received Registration Data: ");
        System.out.println("Name: " + uName);
        System.out.println("Email ID: " + emailid);
        System.out.println("Team: " + team);
        System.out.println("Username: " + username);        
        System.out.println("Role: " + role);

        // Save user to the database
        userService.registerUserAdminRole(uName, emailid, team, username, password, role);

        return "redirect:/login?success=true";
    }
    
    @GetMapping("/forgot-password")
    public String showForgotPasswordPage() {
        return "forgot"; // Thymeleaf will render the forgot.html template
    }
    
    @PostMapping("/forgot-password")
    public String forgotPassword(@RequestParam String username, @RequestParam String password) {
        // Check if the user exists
        Optional<User> userOptional = userService.findByUsername(username);

        if (userOptional.isPresent()) {
            // User exists, update the password
            User user = userOptional.get();
            user.setPassword(passwordEncoder.encode(password)); // Hash the password
            userService.updateUser(user); // Update the user in the database
            return "redirect:/login?successReset=true"; // Redirect to login with success message
        } else {
            // User not found
            return "redirect:/forgot-password?error=true"; // Redirect to forgot page with error message
        }
    }
    
    @GetMapping("/dashboard")
    public String dashboard(Model model, HttpServletRequest request) {
    	
    	System.out.println("Working Directory = " + System.getProperty("user.dir"));
    	
    	addUserDetailsToModel(model,"Dashboard","dashboard",request);
    	
    	 // Retrieve the team from the session or request
        String team = (String) request.getSession().getAttribute("team");
        System.out.println("Dashboard Team:" + team);
        if (team == null) {
            team = "default-team"; // Provide a default value if team is not set
        }
        
        List<IncidentTracker> incidents = incidentTrackerService.findLast20ByTeam(team);

        // Add the incidents to the model
        model.addAttribute("incidents", incidents);
        
    	return "dashboard";
    	
    }
    
        
    @GetMapping("/registerUserSetup")
    public String showApprovalPage(Model model, HttpServletRequest request) {
    	System.out.println("showApprovalPage = " + System.getProperty("user.dir"));
    	
    	List<User> users = userService.getUsersForApproval();
    	
    	model.addAttribute("users", users);
    	
    	System.out.println("Users in showApprovalPage: " + users);
       
    	addUserDetailsToModel(model,"Approval_page","registerApprove",request);    
    	
        return "registerApprove";
    }
    
    
    
    // Approve or delete logic
    @PostMapping("/approveDeleteUsers")
    public String approveOrDeleteUsers(@RequestParam List<Long> selectedIds,
                                       @RequestParam String action,
                                       @RequestParam Map<Long, String> roles,
                                       @RequestParam Map<Long, String> teams,
                                       Principal principal) {
        // Get the currently logged-in username from the Principal
        String loggedInUser = principal.getName();
        
        System.out.println("Selected IDs: " + selectedIds);
        System.out.println("Roles Map: " + roles);
        System.out.println("Teams Map: " + teams);

        if ("approve".equals(action)) {
            userService.approveUsers(selectedIds, roles, teams, loggedInUser);
        } else if ("delete".equals(action)) {
            userService.deleteUsers(selectedIds);
        }
        return "redirect:/registerUserSetup";
    }
    
    // New endpoint to serve incidents dynamically as JSON
    @GetMapping("/api/incidents")
    @ResponseBody
    public List<IncidentTracker> getIncidents(HttpServletRequest request) {
    	
    	System.out.println("Inside /api/incidents dashboard = " + System.getProperty("user.dir"));
    	
    	//addUserDetailsToModel(model,"Dashboard","dashboard",request);
    	
        String team = (String) request.getSession().getAttribute("team");
        if (team == null) {
            team = "default-team"; // Provide a default value if team is not set
        }

        // Return the last 20 incidents as JSON
        return incidentTrackerService.findLast20ByTeam(team);
    }
    
    @GetMapping("/pullRequest")
    public String pullRequestPage(Model model,HttpServletRequest request) {
        addUserDetailsToModel(model,"PULL_REQUEST","pullRequest",request);
        return "pullRequest";
    }
    
    @PostMapping("/pull-request")
    public String handlePullRequest(@RequestParam String incidentNumber, Model model, HttpServletRequest request) {
        addUserDetailsToModel(model, "PULL_REQUEST", "pullRequest", request);

        // Call the service to get the incident
        Optional<PullIncident> incident = pullIncidentService.getIncidentByNumber(incidentNumber);

        if (incident.isPresent()) {
            model.addAttribute("incident", incident.get());
        } else {
            model.addAttribute("incident", null);
            model.addAttribute("errorMessage", "Inciden to not found and create incident: ");
        }
        return "pullRequest";
    }
   
	@GetMapping("/fileUpload")
    public String fileUploadPage(Model model,HttpServletRequest request) {
        addUserDetailsToModel(model,"File Upload","fileUpload",request);
        return "fileUpload";
    }
	
	
	@PostMapping("/submitPullRequest")
	public String submitPullRequest(@RequestParam String incidentNumber, Model model,HttpServletRequest request) {
		addUserDetailsToModel(model,"Pull Request Result","pullRequestResult",request);        
		model.addAttribute("incidentNumber", incidentNumber);
	    return "pullRequestResult"; // Return a results page
	}

    @GetMapping("/search")
    public String searchPage(Model model, HttpServletRequest request) {
    	
    	addUserDetailsToModel(model,"SEARCH_PAGE","detail",request); 
    	return "search";       
    }
    
    @PostMapping("/landingSearch")
    public String handleLandingSearch(
            @RequestParam("query") String query,
            Model model,
            HttpServletRequest request) {
    	
    	addUserDetailsToModel(model,"LandingSearch","dashboard",request);
    	
        // Get the current team from the session
        HttpSession session = request.getSession();
        String team = (String) session.getAttribute("team");

        // Fetch search results from the service
        List<IncidentTracker> incidents = incidentTrackerService.findIncidentsBySearchCriteria(query, team);

        // Add attributes to the model
        model.addAttribute("incidents", incidents);
        model.addAttribute("team", team);

        return "dashboard"; // Return the dashboard view with search results
    }
    
    @GetMapping("/databaseOperation")
    public String databaseOperationPage(Model model,HttpServletRequest request) {
        addUserDetailsToModel(model,"DB Operation","dataBaseOperation",request);
        return "databaseOperation";
    }
    
    @GetMapping("/perform-logout")
    public String logout(HttpServletRequest request) {
    	 System.out.println("Logging logout for before session: ");
        try {
            HttpSession session = request.getSession(false);
            if (session != null) {
                String sessionId = session.getId();
                String username = SecurityContextHolder.getContext().getAuthentication().getName();

                System.out.println("Logging logout for session: " + sessionId + " and username: " + username);

                // Log logout action
                logInfoService.logActivity(sessionId, "LOGOUT", username);
                session.invalidate();
                // Clear security context
                SecurityContextHolder.clearContext();
            }
            return "redirect:/login?logout=true";
        } catch (Exception ex) {
            logInfoService.logActivity(request.getSession().getId(), "LOGOUT", "unknown", ex.getMessage(), "500");
            return "error";
        }
    }
    
    
    @PostMapping("/uploadFile")
    public String uploadFile(@RequestParam("file") MultipartFile file, Model model,HttpServletRequest request) {
        try {
            // Add user details to the model
            //addUserDetailsToModel(model);
        	
        	addUserDetailsToModel(model,"upload_file","fileUpload",request);

            // Read the file and parse the CSV data
        	 // Read the file and parse the CSV data
            List<IncidentTracker> incidents = new ArrayList<>();
            BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8));

            String line;
            int lineNumber = 0;
            while ((line = br.readLine()) != null) {
                lineNumber++;
                if (lineNumber == 1) continue; // Skip header row

                String[] fields = line.split(",");
                if (fields.length < 17) {
                    throw new IllegalArgumentException("Invalid CSV format. Missing columns.");
                }

                IncidentTracker incident = new IncidentTracker();
                incident.setIncidentNumber(fields[1].trim()); // Always a string
                incident.setCreateBy(fields[2].trim()); // Always a string
                incident.setCreateDatetime(parseDateTime(fields[3])); // Parse date
                incident.setTeam(fields[4].trim()); // Always a string
                incident.setStartDatetime(parseDateTime(fields[5])); // Parse date
                incident.setDeductDatetime(parseDateTime(fields[6])); // Parse date
                incident.setDiagnoseDatetime(parseDateTime(fields[7])); // Parse date
                incident.setMitigateDatetime(parseDateTime(fields[8])); // Parse date
                incident.setResolveDatetime(parseDateTime(fields[9])); // Parse date
                incident.setMcEngageDatetime(parseDateTime(fields[10])); // Parse date
                incident.setCustomerExp(fields[11].trim()); // Always a string
                incident.setAnalysis(fields[12].trim()); // Always a string (optional, could be large text)
                incident.setImpactCount(fields[13].isEmpty() ? null : Integer.parseInt(fields[13].trim())); // Parse integer
                incident.setFlow(fields[14].trim()); // Always a string
                incident.setUpdateUser(fields[15].trim()); // Always a string
                incident.setUpdateDatetime(parseDateTime(fields[16])); // Parse date

                incidents.add(incident);
            }

            // Save all incidents to the database
            incidentTrackerService.saveAll(incidents);

            // Add success message to model
            model.addAttribute("message", "Data got imported successfully");
        } catch (Exception e) {
            // Add failure message to model
            model.addAttribute("message", "Failed to import data: " + e.getMessage());
        }

        return "fileUpload";
    }
    
 // Helper method to parse date
    private LocalDateTime parseDateTime(String dateTimeString) {
        if (dateTimeString == null || dateTimeString.isEmpty()) {
            return null; // Return null for empty fields
        }
        try {
        	 // Define the custom date format for single and double-digit hours
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy H:mm");
            return LocalDateTime.parse(dateTimeString.trim(), formatter);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Invalid date format: " + dateTimeString + ". Expected format: dd/MM/yyyy HH:mm");
        }
    }
    
    
    @GetMapping("/incident/create")
    public String createIncidentPage(Model model, HttpServletRequest request) {
        addUserDetailsToModel(model, "CREATE_INCIDENT", "createIncident", request);
        model.addAttribute("incident", new IncidentTracker());
        return "createIncident"; // Thymeleaf template for creating incidents
    }

    @PostMapping("/incident/create")
    public String createIncident(@ModelAttribute IncidentTracker incident, HttpServletRequest request, Model model) {
        try {
            String username = SecurityContextHolder.getContext().getAuthentication().getName();
            incident.setCreateBy(username);
            incident.setCreateDatetime(LocalDateTime.now()); // Set the current time
            incident.setUpdateUser(username);
            incident.setUpdateDatetime(LocalDateTime.now());
            incidentTrackerService.createIncident(incident);
            model.addAttribute("message", "Incident created successfully");
            return "redirect:/search";
        } catch (Exception e) {
            model.addAttribute("errorMessage", "Failed to create incident: " + e.getMessage());
            return "createIncident";
        }
    }

    @GetMapping("/incident/edit/{incidentNumber}")
    public String editIncidentPage(@PathVariable String incidentNumber, Model model, HttpServletRequest request) {
        addUserDetailsToModel(model, "EDIT_INCIDENT", "editIncident", request);
        
        String team=getTeamDetails(request, "Edit");
        //DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(ZoneId.of("America/New_York"));
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm").withZone(ZoneId.of("America/New_York"));

       
        
        IncidentTracker incident = incidentTrackerService.getIncidentByNumberAndTeam(incidentNumber,team)
                .orElseThrow(() -> new IllegalArgumentException("Invalid Incident Number: " + incidentNumber));
        
        String formattedCreateDatetime = incident.getCreateDatetime().format(formatter);
        String formattedStartDatetime = incident.getStartDatetime().format(formatter);
        String formattedDeductDatetime = incident.getDeductDatetime().format(formatter);
        String formattedDiagnoseDatetime = incident.getDiagnoseDatetime().format(formatter);
        String formattedMitigateDatetime = incident.getMitigateDatetime().format(formatter);
        String formattedResolveDatetime = incident.getResolveDatetime().format(formatter);
        String formattedMcEngageDatetime = incident.getMcEngageDatetime().format(formatter);
        String formattedUpdateDatetime = incident.getUpdateDatetime().format(formatter);
        
        model.addAttribute("incident", incident);               
        model.addAttribute("createDatetime", formattedCreateDatetime);
        model.addAttribute("startDatetime", formattedStartDatetime);
        model.addAttribute("deductDatetime", formattedDeductDatetime);
        model.addAttribute("diagnoseDatetime", formattedDiagnoseDatetime);
        model.addAttribute("mitigateDatetime", formattedMitigateDatetime);
        model.addAttribute("resolveDatetime", formattedResolveDatetime);
        model.addAttribute("mcEngageDatetime", formattedMcEngageDatetime);
        model.addAttribute("updateDatetime", formattedUpdateDatetime);
        
        
        
        /*model.addAttribute("createDatetime", formatDateTime(incident.getCreateDatetime(), formatter));
        model.addAttribute("startDatetime", formatDateTime(incident.getStartDatetime(), formatter));
        model.addAttribute("deductDatetime", formatDateTime(incident.getDeductDatetime(), formatter));
        model.addAttribute("diagnoseDatetime", formatDateTime(incident.getDiagnoseDatetime(), formatter));
        
        model.addAttribute("mitigateDatetime", formatDateTime(incident.getMitigateDatetime(), formatter));
        model.addAttribute("resolveDatetime", formatDateTime(incident.getResolveDatetime(), formatter));
        model.addAttribute("mcEngageDatetime", formatDateTime(incident.getMcEngageDatetime(), formatter));
        model.addAttribute("updateDatetime", formatDateTime(incident.getUpdateDatetime(), formatter));*/

        
        return "editIncident"; // Thymeleaf template for editing incidents
    }
    
    
    //@GetMapping("/incident/edit/{incidentNumber}")
    public String editIncidentPage_nouse(@PathVariable String incidentNumber, Model model, HttpServletRequest request) {
        addUserDetailsToModel(model, "EDIT_INCIDENT", "editIncident", request);

        // Retrieve team details from the request
        String team = getTeamDetails(request, "Edit");

        // Fetch the existing incident from the service
        IncidentTracker incident = incidentTrackerService.getIncidentByNumberAndTeam(incidentNumber, team)
                .orElseThrow(() -> new IllegalArgumentException("Invalid Incident Number: " + incidentNumber));

        // Create a DTO for the incident with formatted dates
        IncidentTrackerDTO incidentDTO = createIncidentTrackerDTO(incident);

        // Add the DTO to the model
        model.addAttribute("incident", incidentDTO);

        return "editIncident"; // Thymeleaf template for editing incidents
    }
    
    @PostMapping("/incident/edit")
    public String editIncident(@ModelAttribute IncidentTracker incident, HttpServletRequest request, Model model) {
        try {
        	
            String username = SecurityContextHolder.getContext().getAuthentication().getName();
            incident.setUpdateUser(username);
            incident.setUpdateDatetime(LocalDateTime.now());
            
            logger.info("Received customer experience from form: {}", incident.getCustomerExp());
            logger.info("Received analysis  from form: {}", incident.getAnalysis());
            
            System.out.println("Received customer experience: " +incident.getCustomerExp());
            System.out.println("Received analysis : " +incident.getAnalysis());
            
            
            incidentTrackerService.updateIncident(incident);
            
            model.addAttribute("message", "Incident updated successfully");
            return "redirect:/search";
        } catch (Exception e) {
            model.addAttribute("errorMessage", "Failed to update incident: " + e.getMessage());
            return "editIncident";
        }
    }
    
    
    //@PostMapping("/incident/edit")
    public String editIncident_nouse(@ModelAttribute IncidentTrackerDTO incidentDTO, HttpServletRequest request, Model model) {
        try {
            String username = SecurityContextHolder.getContext().getAuthentication().getName();

            // Parse and convert date-time values if necessary
            logger.info("Received customer experience from form: {}", incidentDTO.getCustomerExp());

            
            // Fetch the existing IncidentTracker entity
            IncidentTracker existingIncident = incidentTrackerService.getIncidentByNumberAndTeam(
                    incidentDTO.getIncidentNumber(), incidentDTO.getTeam())
                .orElseThrow(() -> new IllegalArgumentException("Incident not found"));

            logger.info("Incoming DTO values: {}", incidentDTO);
            
            logger.info("existing customer experience from form: {}", existingIncident.getCustomerExp());
            // Update user information
            incidentDTO.setUpdateUser(username);

            // Call the service to update the incident
            incidentTrackerService.updateIncidentDTO(existingIncident, incidentDTO);

            model.addAttribute("message", "Incident updated successfully");
            return "redirect:/search";
        } catch (Exception e) {
            model.addAttribute("errorMessage", "Failed to update incident: " + e.getMessage());
            return "editIncident";
        }
    }
    
    
 // Helper method to create a DTO with formatted date strings
    private IncidentTrackerDTO createIncidentTrackerDTO(IncidentTracker incident) {
        //DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(ZoneId.of("America/New_York"));

        IncidentTrackerDTO dto = new IncidentTrackerDTO();
        dto.setIncidentNumber(incident.getIncidentNumber());
        dto.setTeam(incident.getTeam());
        dto.setCreateBy(incident.getCreateBy());
        dto.setCreateDatetime(convertToEST(incident.getCreateDatetime()));
        dto.setStartDatetime(convertToEST(incident.getStartDatetime()));
        dto.setDeductDatetime(convertToEST(incident.getDeductDatetime()));
        dto.setDiagnoseDatetime(convertToEST(incident.getDiagnoseDatetime()));
        dto.setMitigateDatetime(convertToEST(incident.getMitigateDatetime()));
        dto.setResolveDatetime(convertToEST(incident.getResolveDatetime()));
        dto.setMcEngageDatetime(convertToEST(incident.getMcEngageDatetime()));
        dto.setCustomerExp(incident.getCustomerExp());
        dto.setAnalysis(incident.getAnalysis());
        dto.setImpactCount(incident.getImpactCount());
        dto.setFlow(incident.getFlow());
        dto.setAlertName(incident.getAlertName());
        dto.setFlagItem(incident.getFlagItem());
        dto.setUpdateUser(incident.getUpdateUser());
        dto.setUpdateDatetime(convertToEST(incident.getUpdateDatetime()));

        return dto;
    }
    
    private String convertToEST(LocalDateTime dateTime) {
        if (dateTime == null) {
            return null;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(ZoneId.of("America/New_York"));
        return dateTime.atZone(ZoneId.systemDefault()).withZoneSameInstant(ZoneId.of("America/New_York")).format(formatter);
    }
    
    private String formatDateTime(LocalDateTime dateTime, DateTimeFormatter formatter) {
        if (dateTime == null) {
            return ""; // Return an empty string for null dates
        }
        return ZonedDateTime.of(dateTime, ZoneId.systemDefault()) // Convert from system default timezone
                            .withZoneSameInstant(ZoneId.of("America/New_York")) // Convert to EST
                            .format(formatter);
    }
    
    private String getTeamDetails(HttpServletRequest request, String screenId) {
    	
    	// Get team from user 
    	HttpSession session = request.getSession();
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        
        User user = userService.getUserByUsername(username);
        
        System.out.println("User Controller UserName: " + username);
        System.out.println("User Controller Http Session Id: " + session);
        System.out.println("User Controller Session Id: " + request.getSession().getId());        
        System.out.println("User Controller  Team Name: " + user.getTeam());
        	        
        String team = user.getTeam();	                 
        
		return team;
	}

   
    
    @GetMapping("/incident/delete/{incidentNumber}")
    public String deleteIncident(@PathVariable String incidentNumber, Model model, HttpServletRequest request) {
        try {
            incidentTrackerService.deleteIncident(incidentNumber);
            model.addAttribute("message", "Incident deleted successfully");
            return "redirect:/search";
        } catch (Exception e) {
            model.addAttribute("errorMessage", "Failed to delete incident: " + e.getMessage());
            return "search";
        }
    }

    @GetMapping("/chat-service")
    public String chatServicePage(Model model, HttpServletRequest request) {
        // Add user details to the model
        addUserDetailsToModel(model, "CHAT_SERVICE", "chatService", request);
        return "chatService"; // Render the chat service page
    }

    /*@PostMapping("/chat-service")
    public String handleChatServiceSearch(@RequestParam String query, Model model, HttpServletRequest request) {
        // Add user details to the model
        addUserDetailsToModel(model, "CHAT_SERVICE", "chatService", request);

        // Retrieve team details
        String team = getTeamDetails(request, "ChatService");

        // Fetch the top 5 incidents from the service
        List<ChatIncident> incidents = chatIncidentService.searchIncidents(query, team);

        // Add the incidents and user details to the model
       
        model.addAttribute("incidents", incidents);

        return "chatService"; // Re-render the page with the search results
    }*/

    
    private void addUserDetailsToModel(Model model, String screenId,String returnPage,HttpServletRequest request) {
		
    	try {
    		
    		HttpSession session = request.getSession();
    		
    		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String username = authentication.getName();
            
            if (username == null) {
                logger.warn("Unauthorized access. Redirecting to login.");                
            }
            
            logInfoService.logActivity(session.getId(), screenId, username);                             
            
            User user = userService.getUserByUsername(username);
            model.addAttribute("username", username);
            model.addAttribute("role", user.getRole());
            model.addAttribute("team", user.getTeam());
            //return "success";
            
         // Add attributes to the Session
            session.setAttribute("username", username);
            session.setAttribute("role", user.getRole());
            session.setAttribute("team", user.getTeam());
            
            System.out.println("addUserDetailsToModel UserName: " + username);
	        //System.out.println("addUserDetailsToModel Http Session Id: " + session);
            System.out.println("addUserDetailsToModel Http Session Id (Object): " + session.getId());
	        System.out.println("addUserDetailsToModel Session Id: " + request.getSession().getId());        
	        System.out.println("addUserDetailsToModel Team Name: " + user.getTeam());
	        	        
    		
    	}catch (Exception ex)
    	{
    		logInfoService.logActivity(request.getSession().getId(), screenId, "unknown", ex.getMessage(), "500");
            //return "error";
    	}    	
		
	}

}
