package com.example.demo.controller;

import com.example.demo.model.User;
import com.example.demo.service.LogInfoService;
import com.example.demo.service.UserService;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.beans.factory.annotation.Autowired;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {

    @Autowired
    private UserService userService;
    
    @Autowired
    private PasswordEncoder passwordEncoder; // Inject the PasswordEncoder bean
    
    @Autowired
    private LogInfoService logInfoService;

    @GetMapping("/dashboard")
    public String dashboard(Model model, HttpServletRequest request) {
    	
    	try {
    		
    		HttpSession session = request.getSession();
    		
    		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String username = authentication.getName();
            
            // Log dashboard access
            logInfoService.logActivity(session.getId(), "DASHBOARD", username);
            
            
            User user = userService.getUserByUsername(username);
            model.addAttribute("username", username);
            model.addAttribute("role", user.getRole());
            return "dashboard";
    		
    	}catch (Exception ex)
    	{
    		logInfoService.logActivity(request.getSession().getId(), "DASHBOARD", "unknown", ex.getMessage(), "500");
            return "error";
    	}
    	
        
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/register")
    public String showRegisterPage() {
        return "register"; // Thymeleaf template for the register page
    }
    
    @PostMapping("/register")
    public String register(@RequestParam String uName, 
                           @RequestParam String emailid, 
                           @RequestParam String team, 
                           @RequestParam String username, 
                           @RequestParam String password, 
                           @RequestParam String role) {
        // Registration logic here
        // Save user to the database (UserService handles this)
        userService.registerUser(uName, emailid, team, username, password, role);

        // Redirect to login page with success parameter
        return "redirect:/login?success=true";
    }
    
    @GetMapping("/forgot-password")
    public String showForgotPasswordPage() {
        return "forgot"; // Thymeleaf will render the forgot.html template
    }
    
    @PostMapping("/forgot-password")
    public String forgotPassword(@RequestParam String username, @RequestParam String password) {
        // Check if the user exists
        Optional<User> userOptional = userService.findByUsername(username);

        if (userOptional.isPresent()) {
            // User exists, update the password
            User user = userOptional.get();
            user.setPassword(passwordEncoder.encode(password)); // Hash the password
            userService.updateUser(user); // Update the user in the database
            return "redirect:/login?successReset=true"; // Redirect to login with success message
        } else {
            // User not found
            return "redirect:/forgot-password?error=true"; // Redirect to forgot page with error message
        }
    }

    @GetMapping("/search")
    public String searchPage(Model model, HttpServletRequest request) {
        try {
            HttpSession session = request.getSession();
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            String username = auth.getName();

            // Log search page access
            logInfoService.logActivity(session.getId(), "SEARCH_PAGE", username);
            
            User user = userService.getUserByUsername(username);
            model.addAttribute("username", username);
            model.addAttribute("role", user.getRole());
            
            return "detail";
        } catch (Exception ex) {
            logInfoService.logActivity(request.getSession().getId(), "SEARCH_PAGE", "unknown", ex.getMessage(), "500");
            return "error";
        }
    }
    
    @GetMapping("/perform-logout")
    public String logout(HttpServletRequest request) {
    	 System.out.println("Logging logout for before session: ");
        try {
            HttpSession session = request.getSession(false);

           

            if (session != null) {
                String sessionId = session.getId();
                String username = SecurityContextHolder.getContext().getAuthentication().getName();

                System.out.println("Logging logout for session: " + sessionId + " and username: " + username);

                // Log logout action
                logInfoService.logActivity(sessionId, "LOGOUT", username);
                session.invalidate();
                // Clear security context
                SecurityContextHolder.clearContext();
            }
            return "redirect:/login?logout=true1234";
        } catch (Exception ex) {
            logInfoService.logActivity(request.getSession().getId(), "LOGOUT", "unknown", ex.getMessage(), "500");
            return "error";
        }
    }
}
