package com.example.demo.dto;

import java.time.LocalDateTime;

import jakarta.persistence.Column;

public class IncidentTrackerDTO {
    private String incidentNumber;
    private String team;
    private String createBy;
    private String createDatetime; // Combined date and time as a string
    private String startDatetime;
    private String deductDatetime;
    private String diagnoseDatetime;
    private String mitigateDatetime;
    private String resolveDatetime;
    private String mcEngageDatetime;
    private String customerExp;
    private String analysis;
    private Integer impactCount;
    private String flow;
    private String alertName;
    private Boolean flagItem;
    private String updateUser;    
    private String updateDatetime;
    
	public String getIncidentNumber() {
		return incidentNumber;
	}
	public void setIncidentNumber(String incidentNumber) {
		this.incidentNumber = incidentNumber;
	}
	public String getTeam() {
		return team;
	}
	public void setTeam(String team) {
		this.team = team;
	}
	public String getCreateBy() {
		return createBy;
	}
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}
	public String getCreateDatetime() {
		return createDatetime;
	}
	public void setCreateDatetime(String createDatetime) {
		this.createDatetime = createDatetime;
	}
	public String getStartDatetime() {
		return startDatetime;
	}
	public void setStartDatetime(String startDatetime) {
		this.startDatetime = startDatetime;
	}
	public String getDeductDatetime() {
		return deductDatetime;
	}
	public void setDeductDatetime(String deductDatetime) {
		this.deductDatetime = deductDatetime;
	}
	public String getDiagnoseDatetime() {
		return diagnoseDatetime;
	}
	public void setDiagnoseDatetime(String diagnoseDatetime) {
		this.diagnoseDatetime = diagnoseDatetime;
	}
	public String getMitigateDatetime() {
		return mitigateDatetime;
	}
	public void setMitigateDatetime(String mitigateDatetime) {
		this.mitigateDatetime = mitigateDatetime;
	}
	public String getResolveDatetime() {
		return resolveDatetime;
	}
	public void setResolveDatetime(String resolveDatetime) {
		this.resolveDatetime = resolveDatetime;
	}
	public String getMcEngageDatetime() {
		return mcEngageDatetime;
	}
	public void setMcEngageDatetime(String mcEngageDatetime) {
		this.mcEngageDatetime = mcEngageDatetime;
	}
	public String getCustomerExp() {
		return customerExp;
	}
	public void setCustomerExp(String customerExp) {
		this.customerExp = customerExp;
	}
	public String getAnalysis() {
		return analysis;
	}
	public void setAnalysis(String analysis) {
		this.analysis = analysis;
	}
	public Integer getImpactCount() {
		return impactCount;
	}
	public void setImpactCount(Integer impactCount) {
		this.impactCount = impactCount;
	}
	public String getFlow() {
		return flow;
	}
	public void setFlow(String flow) {
		this.flow = flow;
	}
	public String getAlertName() {
		return alertName;
	}
	public void setAlertName(String alertName) {
		this.alertName = alertName;
	}
	public Boolean getFlagItem() {
		return flagItem;
	}
	public void setFlagItem(Boolean flagItem) {
		this.flagItem = flagItem;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public String getUpdateDatetime() {
		return updateDatetime;
	}
	public void setUpdateDatetime(String updateDatetime) {
		this.updateDatetime = updateDatetime;
	}

}
