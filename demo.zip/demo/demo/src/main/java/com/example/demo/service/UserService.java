package com.example.demo.service;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // Register a new user
    public void registerUser(String uName, String emailid, String team, String username, String password, String role) {
        User user = new User();
        user.setName(uName); // Ensure this maps correctly to your `name` column
        user.setEmail(emailid); // Ensure this maps correctly to your `email` column
        user.setTeam(team); // Ensure this maps correctly to your `team` column
        user.setUsername(username); // Ensure this maps correctly to your `username` column
        user.setPassword(passwordEncoder.encode(password)); // Hash the password before saving
        user.setRole(role); // Ensure this maps correctly to your `role` column

        userRepository.save(user);
    }
    
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));

        return org.springframework.security.core.userdetails.User.builder()
                .username(user.getUsername())
                .password(user.getPassword()) // Encrypted password
                .authorities(user.getRole())  // User role
                .build();
    }

    // Find a user by username
    public User getUserByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found: " + username));
    }
    
 // Find a user by username
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    // Update user details
    public void updateUser(User user) {
        userRepository.save(user);
    }
}
