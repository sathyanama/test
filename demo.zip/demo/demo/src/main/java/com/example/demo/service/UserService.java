package com.example.demo.service;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // Register a new user
    public void registerUser(String uName, String emailid,   String username, String password) {
    	
    	ZoneId estZoneId = ZoneId.of("America/New_York");
    	
        User user = new User();
        user.setName(uName); // Ensure this maps correctly to your `name` column
        user.setEmail(emailid); // Ensure this maps correctly to your `email` column
        user.setTeam("any"); // Ensure this maps correctly to your `team` column
        user.setUsername(username); // Ensure this maps correctly to your `username` column
        user.setPassword(passwordEncoder.encode(password)); // Hash the password before saving
        user.setRole("any"); // Ensure this maps correctly to your `role` column
        user.setApproveFlag(false);
        user.setUpdateUser(username);
        user.setUpdateDatetime(convertToEST(LocalDateTime.now(), estZoneId));                
        userRepository.save(user);
    }
    
    
 // Register a new user admin
    public void registerUserAdminRole(String uName, String emailid, String team, String username, String password, String role) {
    	
    	ZoneId estZoneId = ZoneId.of("America/New_York");
    	
        User user = new User();
        user.setName(uName); // Ensure this maps correctly to your `name` column
        user.setEmail(emailid); // Ensure this maps correctly to your `email` column
        user.setTeam(team); // Ensure this maps correctly to your `team` column
        user.setUsername(username); // Ensure this maps correctly to your `username` column
        user.setPassword(passwordEncoder.encode(password)); // Hash the password before saving
        user.setRole(role); // Ensure this maps correctly to your `role` column
        user.setApproveFlag(true);
        user.setUpdateUser(username);
        user.setUpdateDatetime(convertToEST(LocalDateTime.now(), estZoneId));   
        userRepository.save(user);
    }
    
    
    private LocalDateTime convertToEST(LocalDateTime dateTime, ZoneId estZoneId) {
        return ZonedDateTime.of(dateTime, ZoneId.systemDefault()) // From default system timezone
                .withZoneSameInstant(estZoneId)                   // Convert to EST
                .toLocalDateTime();                               // Return LocalDateTime in EST
    }
    
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));

        return org.springframework.security.core.userdetails.User.builder()
                .username(user.getUsername())
                .password(user.getPassword()) // Encrypted password
                .authorities(user.getRole())  // User role
                .build();
    }

    // Find a user by username
    public User getUserByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found: " + username));
    }
    
 // Find a user by username
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    // Update user details
    public void updateUser(User user) {
        userRepository.save(user);
    }
    
    public List<User> getUsersForApproval() {
        return userRepository.findByApproveFlagFalse(); // Ensure this query exists in UserRepository
    }

    public void approveUsers(List<Long> userIds, Map<Long, String> roles, Map<Long, String> teams, String loggedInUser) {
    	
    	System.out.println("Roles Map in approveUsers: " + roles);
        System.out.println("Teams Map in approveUsers: " + teams);
        
        List<User> users = userRepository.findAllById(userIds);

        for (User user : users) {
            user.setApproveFlag(true);
            
         // Extract the actual user ID from the prefixed keys
            String roleKey = "roles[" + user.getId() + "]";
            String teamKey = "teams[" + user.getId() + "]";

            String role = roles.get(roleKey);
            String team = teams.get(teamKey);
            
            System.out.println("Approve id: " + user.getId());
            System.out.println("Approve User: " + role);
            System.out.println("Approve Team: " + team);

            // Set default values if role or team is missing
            if (role == null || role.isEmpty()) {
                role = "USER"; // Default role
            }

            user.setRole(role);
            user.setTeam(team != null ? team : "DMC"); // Default team
            
            //user.setRole(roles.get(user.getId()));
            //user.setTeam(teams.get(user.getId()));
            
            
            user.setUpdateUser(loggedInUser); // Update with the logged-in user
            user.setUpdateDatetime(LocalDateTime.now()); // Set the current date and time
            userRepository.save(user);
        }
    }


    public void deleteUsers(List<Long> userIds) {
        userRepository.deleteAllById(userIds);
    }
}
