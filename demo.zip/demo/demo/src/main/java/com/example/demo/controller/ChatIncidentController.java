package com.example.demo.controller;

import com.example.demo.model.ChatIncident;
import com.example.demo.model.User;
import com.example.demo.service.ChatIncidentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import com.example.demo.service.UserService;

import java.util.List;

@RestController
@RequestMapping("/api/chat")
public class ChatIncidentController {

    @Autowired
    private ChatIncidentService chatIncidentService;
    
    @Autowired
    private UserService userService;

    @PostMapping
    public ResponseEntity<?> handleChatQuery(@RequestBody ChatRequest request, HttpServletRequest httprequest) {
        try {
            // Extract team, username, and role from the session or security context
        	
        	
        	HttpSession session = httprequest.getSession();
    		
    		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String username = authentication.getName();
                                                  
            
            User user = userService.getUserByUsername(username);
            //model.addAttribute("username", username);
            //model.addAttribute("role", user.getRole());
            //model.addAttribute("team", user.getTeam());
            
            
            String team = user.getTeam();
            String role = user.getRole();
            
            // Log the extracted details for debugging
            System.out.println("Username: " + username);
            System.out.println("Team: " + team);
            System.out.println("Role: " + role);

            if (team == null || username == null || role == null) {
                return ResponseEntity.status(400).body("Missing required session attributes: username, team, or role");
            }


           System.out.println("Incoming search query: {}" +  request.query);
           System.out.println("Team being used for search: {}" + team);
            // Fetch incidents based on the query and team
            List<ChatIncident> incidents = chatIncidentService.searchIncidents(request.getQuery(), team);

            return ResponseEntity.ok().body(new ChatResponse(incidents));
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error processing request: " + e.getMessage());
        }
    }

    // DTO for incoming request
    static class ChatRequest {
        private String query;

        public String getQuery() {
            return query;
        }

        public void setQuery(String query) {
            this.query = query;
        }
    }

    // DTO for outgoing response
    static class ChatResponse {
        private List<ChatIncident> incidents;

        public ChatResponse(List<ChatIncident> incidents) {
            this.incidents = incidents;
        }

        public List<ChatIncident> getIncidents() {
            return incidents;
        }

        public void setIncidents(List<ChatIncident> incidents) {
            this.incidents = incidents;
        }
    }
}
