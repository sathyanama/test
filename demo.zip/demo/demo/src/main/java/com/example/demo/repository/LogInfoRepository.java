package com.example.demo.repository;

import com.example.demo.model.LogInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LogInfoRepository extends JpaRepository<LogInfo, Long> {
    // This repository will provide basic CRUD operations for LogInfo table.
}
