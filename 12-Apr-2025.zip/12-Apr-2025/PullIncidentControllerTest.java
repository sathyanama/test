package com.example.demo.controller;

import com.example.demo.model.IncidentTracker;
import com.example.demo.model.PullIncident;
import com.example.demo.service.IncidentTrackerService;
import com.example.demo.service.PullIncidentService;
import com.example.demo.util.CommonUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.web.servlet.MockMvc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import org.thymeleaf.spring6.view.ThymeleafViewResolver;


@WebMvcTest(PullIncidentController.class)
@AutoConfigureMockMvc(addFilters = false)
@Import(ThymeleafBypassConfig.class)
public class PullIncidentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private IncidentTrackerService incidentTrackerService;

    @MockBean
    private PullIncidentService pullIncidentService;

    @MockBean
    private CommonUtil commonUtil;
    
    @MockBean
    private ThymeleafViewResolver thymeleafViewResolver;

    private MockHttpSession session;

    @BeforeEach
    public void setup() {
        session = new MockHttpSession();
        session.setAttribute("username", "testuser");
        session.setAttribute("role", "admin");
        session.setAttribute("team", "DMC");
        session.setAttribute("location", "SG");
    }
    
    @Test
    public void testPullRequestPage() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/pullRequest").session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("pullIncident"))
                .andExpect(model().attribute("username", "testuser"))
                .andExpect(model().attribute("role", "admin"))
                .andExpect(model().attribute("team", "DMC"));
    }
    
    @Test
    public void testHandlePullRequest_whenIncidentNotFoundInTable() throws Exception {
        when(pullIncidentService.getIncidentByNumber("INC999")).thenReturn(Optional.empty());

        mockMvc.perform(MockMvcRequestBuilders.post("/get-incident-pull-request")
                        .param("incidentNumber", "INC999")
                        .session(session))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/pullRequest"));
    }
    
    @Test
    public void testHandlePullRequest_createModeWhenIncidentNotInDb() throws Exception {
        PullIncident pull = new PullIncident();
        pull.setIncidentNumber("INC2024");
        pull.setCreateBy("JaneDoe");
        pull.setCustomerExp("Test experience");
        pull.setState("In Progress");
        pull.setAssignmentGroup("SysOps");
        pull.setAssignedTo("John Admin");
        pull.setActImpactClassification("Critical");
        pull.setClassification("Type A");
        pull.setImpact("High");
        pull.setUrgency("Urgent");
        pull.setPriority("P1");
        pull.setImpactedLob("LobX");
        pull.setParentIncident("INC1001");
        pull.setCategory("Infra");
        pull.setSubCategory("Switch");
        pull.setOwningLobLevel4("LOB L4");
        pull.setChangeRequest("CHG123"); // triggers causedByChange = Y
        pull.setExternalVendor("VendorX"); // triggers causedByVendor = Y
        pull.setOpenedTime(LocalDateTime.now());
        pull.setClosedTime(LocalDateTime.now());
        pull.setStartDatetime(LocalDateTime.now());
        pull.setDeductDatetime(LocalDateTime.now());
        pull.setDiagnoseDatetime(LocalDateTime.now());
        pull.setMitigateDatetime(LocalDateTime.now());
        pull.setResolveDatetime(LocalDateTime.now());
        pull.setCreateDatetime(LocalDateTime.now());

        when(pullIncidentService.getIncidentByNumber("INC2024")).thenReturn(Optional.of(pull));
        when(incidentTrackerService.getIncidentByNumberAndTeam("INC2024", "DMC")).thenReturn(Optional.empty());

        mockMvc.perform(MockMvcRequestBuilders.post("/get-incident-pull-request")
                        .param("incidentNumber", "INC2024")
                        .session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("CURDIncidentTemplate"))
                .andExpect(model().attribute("mode", "create"))
                .andExpect(model().attributeExists("incident"));
    }
    
    @Test
    public void testHandlePullRequest_updateModeWhenIncidentExistsInDb() throws Exception {
        PullIncident pull = new PullIncident();
        pull.setIncidentNumber("INC3030");
        pull.setCreateBy("JaneDoe");
        pull.setCustomerExp("Sample Experience");
        pull.setChangeRequest("CHG555");
        pull.setExternalVendor("VendorY");
        pull.setOpenedTime(LocalDateTime.now());
        pull.setClosedTime(LocalDateTime.now());
        pull.setStartDatetime(LocalDateTime.now());
        pull.setDeductDatetime(LocalDateTime.now());
        pull.setDiagnoseDatetime(LocalDateTime.now());
        pull.setMitigateDatetime(LocalDateTime.now());
        pull.setResolveDatetime(LocalDateTime.now());
        pull.setCreateDatetime(LocalDateTime.now());

        IncidentTracker existing = new IncidentTracker();
        existing.setId(99L);
        existing.setIncidentNumber("INC3030");
        existing.setUpdateDatetime(LocalDateTime.now());
        existing.setMcEngageDatetime(LocalDateTime.now());
        existing.setTag("existing-tag");

        when(pullIncidentService.getIncidentByNumber("INC3030")).thenReturn(Optional.of(pull));
        when(incidentTrackerService.getIncidentByNumberAndTeam("INC3030", "DMC")).thenReturn(Optional.of(existing));

        mockMvc.perform(MockMvcRequestBuilders.post("/get-incident-pull-request")
                        .param("incidentNumber", "INC3030")
                        .session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("CURDIncidentTemplate"))
                .andExpect(model().attribute("mode", "update"))
                .andExpect(model().attributeExists("incident", "updateDatetime", "mcEngageDatetime"));
    }
    
    @Test
    public void testCreateIncident_withTags() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/incident/create")
                        .session(session)
                        .param("incidentNumber", "INC5001")
                        .param("customerExp", "Good")
                        .param("analysis", "Initial analysis")
                        .param("tags", "tag1", "tag2"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/dashboard"));

        verify(incidentTrackerService, times(1)).createIncident(any(IncidentTracker.class));
    }

    @Test
    public void testEditIncident_withTags() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/incident/edit")
                        .session(session)
                        .param("id", "1")
                        .param("incidentNumber", "INC6001")
                        .param("customerExp", "Updated Exp")
                        .param("analysis", "Updated analysis")
                        .param("tags", "tagX", "tagY"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/dashboard"));

        verify(incidentTrackerService, times(1)).updateIncident(any(IncidentTracker.class));
    }
    
    @Test
    public void testEditIncident_withoutTags() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/incident/edit")
                        .session(session)
                        .param("id", "2")
                        .param("incidentNumber", "INC6002")
                        .param("customerExp", "No tag test")
                        .param("analysis", "Some updates"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/dashboard"));

        verify(incidentTrackerService, times(1)).updateIncident(any(IncidentTracker.class));
    }


    @Test
    public void testEditIncidentPage_success() throws Exception {
        IncidentTracker mockIncident = new IncidentTracker();
        mockIncident.setId(10L);
        mockIncident.setIncidentNumber("INC7001");
        mockIncident.setUpdateDatetime(LocalDateTime.now());
        mockIncident.setOpenedTimeEst(LocalDateTime.now());
        mockIncident.setClosedTimeEst(LocalDateTime.now());
        mockIncident.setStartDatetime(LocalDateTime.now());
        mockIncident.setDeductDatetime(LocalDateTime.now());
        mockIncident.setDiagnoseDatetime(LocalDateTime.now());
        mockIncident.setMitigateDatetime(LocalDateTime.now());
        mockIncident.setResolveDatetime(LocalDateTime.now());
        mockIncident.setMcEngageDatetime(LocalDateTime.now());
        mockIncident.setTag("tagX");

        when(incidentTrackerService.findById(10L)).thenReturn(Optional.of(mockIncident));

        mockMvc.perform(MockMvcRequestBuilders.get("/incident/edit/update/10/INC7001").session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("UpdateIncidentForm"))
                .andExpect(model().attributeExists(
                        "incident", "mode", "createDatetime", "openedTimeEst",
                        "closedTimeEst", "startDatetime", "deductDatetime",
                        "diagnoseDatetime", "mitigateDatetime", "resolveDatetime",
                        "mcEngageDatetime", "updateDatetime", "currentTag"));
    }

    @Test
    public void testHandlePullRequest_whenExceptionOccurs() throws Exception {
        when(pullIncidentService.getIncidentByNumber("INC9999"))
                .thenThrow(new RuntimeException("Simulated DB failure"));

        mockMvc.perform(MockMvcRequestBuilders.post("/get-incident-pull-request")
                        .param("incidentNumber", "INC9999")
                        .session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("CURDIncidentTemplate"))
                .andExpect(model().attributeExists("errorMessage"));
    }
    
    @Test
    public void testEditIncidentPage_whenIdNotFound_shouldThrowException() throws Exception {
        when(incidentTrackerService.findById(999L)).thenReturn(Optional.empty());

        mockMvc.perform(MockMvcRequestBuilders.get("/incident/edit/view/999/INC999")
                        .session(session))
                .andExpect(result -> {
                    Exception ex = result.getResolvedException();
                    assert ex instanceof IllegalArgumentException;
                    assert ex.getMessage().equals("Invalid Incident ID: 999");
                });
    }


    @Test
    public void testCreateIncident_withoutTags_setsEmptyTag() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/incident/create")
                        .session(session)
                        .param("incidentNumber", "INC8000")
                        .param("customerExp", "None")
                        .param("analysis", "Sample"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/dashboard"));

        verify(incidentTrackerService, times(1)).createIncident(argThat(incident ->
                "".equals(incident.getTag()) // ✅ ensure tag is empty
        ));
    }
    
    @Test
    public void testEditIncident_whenExceptionThrown_setsErrorMessage() throws Exception {
        doThrow(new RuntimeException("DB error"))
                .when(incidentTrackerService).updateIncident(any());

        mockMvc.perform(MockMvcRequestBuilders.post("/incident/edit")
                        .session(session)
                        .param("incidentNumber", "INC9000")
                        .param("customerExp", "Error case")
                        .param("analysis", "Trigger fail"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/dashboard"))
                .andExpect(flash().attributeExists("errorMessage"));
    }
    
    @Test
    public void testHandlePullRequest_setsCausedByChangeToN_whenNoChangeRequest() throws Exception {
        PullIncident pull = new PullIncident();
        pull.setIncidentNumber("INC_CAUSED_BY_CHANGE_N");
        pull.setChangeRequest("");  // ❗ forces the ELSE path
        pull.setExternalVendor("SomeVendor");  // skip vendor else for now
        pull.setCreateDatetime(LocalDateTime.now());
        pull.setOpenedTime(LocalDateTime.now());
        pull.setClosedTime(LocalDateTime.now());
        pull.setStartDatetime(LocalDateTime.now());
        pull.setDeductDatetime(LocalDateTime.now());
        pull.setDiagnoseDatetime(LocalDateTime.now());
        pull.setMitigateDatetime(LocalDateTime.now());
        pull.setResolveDatetime(LocalDateTime.now());

        when(pullIncidentService.getIncidentByNumber(any())).thenReturn(Optional.of(pull));
        when(incidentTrackerService.getIncidentByNumberAndTeam(any(), any())).thenReturn(Optional.empty());

        mockMvc.perform(MockMvcRequestBuilders.post("/get-incident-pull-request")
                        .param("incidentNumber", "INC_CAUSED_BY_CHANGE_N")
                        .session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("CURDIncidentTemplate"))
                .andExpect(model().attributeExists("incident"));
    }
    
    @Test
    public void testHandlePullRequest_setsCausedByVendorToN_whenNoExternalVendor() throws Exception {
        PullIncident pull = new PullIncident();
        pull.setIncidentNumber("INC_CAUSED_BY_VENDOR_N");
        pull.setChangeRequest("CHG1234"); // force change = Y, skip that else
        pull.setExternalVendor("");       // ❗ force vendor = N
        pull.setCreateDatetime(LocalDateTime.now());
        pull.setOpenedTime(LocalDateTime.now());
        pull.setClosedTime(LocalDateTime.now());
        pull.setStartDatetime(LocalDateTime.now());
        pull.setDeductDatetime(LocalDateTime.now());
        pull.setDiagnoseDatetime(LocalDateTime.now());
        pull.setMitigateDatetime(LocalDateTime.now());
        pull.setResolveDatetime(LocalDateTime.now());

        when(pullIncidentService.getIncidentByNumber(any())).thenReturn(Optional.of(pull));
        when(incidentTrackerService.getIncidentByNumberAndTeam(any(), any())).thenReturn(Optional.empty());

        mockMvc.perform(MockMvcRequestBuilders.post("/get-incident-pull-request")
                        .param("incidentNumber", "INC_CAUSED_BY_VENDOR_N")
                        .session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("CURDIncidentTemplate"))
                .andExpect(model().attributeExists("incident"));
    }
    
    @Test
    public void testEditIncident_catchBlock_whenServiceThrows() throws Exception {
        doThrow(new RuntimeException("Simulated failure"))
                .when(incidentTrackerService).updateIncident(any());

        mockMvc.perform(MockMvcRequestBuilders.post("/incident/edit")
                        .session(session)
                        .param("incidentNumber", "INC_ERROR")
                        .param("customerExp", "Err")
                        .param("analysis", "Testing failure"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/dashboard"))
                .andExpect(flash().attributeExists("errorMessage"));
    }






}    