package com.example.demo.controller;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.ViewResolver;

import java.util.Locale;

@TestConfiguration
public class ThymeleafBypassConfig {

    @Bean
    public ViewResolver testViewResolver() {
        return new ViewResolver() {
            @Override
            public View resolveViewName(String viewName, Locale locale) {
                return (model, request, response) -> {
                    response.getWriter().write("Bypassed view: " + viewName);
                };
            }
        };
    }
}
