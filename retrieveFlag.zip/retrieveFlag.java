import org.springframework.stereotype.Service;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.nio.file.*;
import java.util.Base64;

@Service
public class AdfsService {

    private final AdfsProperties adfsProperties;

    public AdfsService(AdfsProperties adfsProperties) {
        this.adfsProperties = adfsProperties;
    }

    public void processCredentials() {
        try {
            if ("Y".equalsIgnoreCase(adfsProperties.getRetrieveFlag())) {
                System.out.println("Reading secret.key...");
                SecretKey key = loadSecretKey("secret.key");
                System.out.println("Secret key loaded successfully.");
            } else {
                System.out.println("Reading passwordConfig.config...");
                readAndDecryptPassword("passwordConfig.config");
            }
        } catch (Exception e) {
            System.err.println("Error processing credentials: " + e.getMessage());
        }
    }
	
	
	public void printAdfsDetails() {
        System.out.println("Username: " + adfsProperties.getUsername());
        System.out.println("Client ID: " + adfsProperties.getClientId());
        System.out.println("Resource: " + adfsProperties.getResource());
        System.out.println("Domain: " + adfsProperties.getDomain());
        System.out.println("Password: " + adfsProperties.getPassword());
    }

    // Load and decode secret key from file
    private SecretKey loadSecretKey(String filePath) throws Exception {
        Path path = Paths.get(filePath);
        byte[] keyBytes = Files.readAllBytes(path);
        byte[] decodedKey = Base64.getDecoder().decode(new String(keyBytes));
        return new SecretKeySpec(decodedKey, 0, decodedKey.length, "AES");
    }

    // Read the passwordConfig.config file, split by "~", and print the values
    private void readAndDecryptPassword(String filePath) throws Exception {
        Path path = Paths.get(filePath);
        String content = Files.readString(path);

        // Split by "~"
        String[] parts = content.split("~");
        if (parts.length == 2) {
            String key = parts[0]; // e.g., "keytodecrypt"
            String encryptedValue = parts[1]; // e.g., "fgfgf:dfdfd"

            System.out.println("Key: " + key);
            System.out.println("Encrypted Password: " + encryptedValue);
        } else {
            System.err.println("Invalid file format in passwordConfig.config");
        }
    }
}




///


adfs:
  username: myusername
  client-id: my-client-id
  resource: my-resource
  domain: mydomain
  password: mypassword
  retrieve-flag: Y  # Change to N to read passwordConfig.config


///

AdfsProperties 

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "adfs")
public class AdfsProperties {
    private String username;
    private String clientId;
    private String resource;
    private String domain;
    private String password;
    private String retrieveFlag;

    // Getters and Setters
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getClientId() { return clientId; }
    public void setClientId(String clientId) { this.clientId = clientId; }

    public String getResource() { return resource; }
    public void setResource(String resource) { this.resource = resource; }

    public String getDomain() { return domain; }
    public void setDomain(String domain) { this.domain = domain; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getRetrieveFlag() { return retrieveFlag; }
    public void setRetrieveFlag(String retrieveFlag) { this.retrieveFlag = retrieveFlag; }
}
