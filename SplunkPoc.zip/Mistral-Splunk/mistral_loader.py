# mistral_loader.py
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

print("Loading Mistral...")
model_path = "C:/Users/sathy/Downloads/personal/SpringBoot/Mistral-7B-Instruct-v0.3"
device = "cuda" if torch.cuda.is_available() else "cpu"
torch_dtype = torch.float16 if device == "cuda" else torch.float32

tokenizer = AutoTokenizer.from_pretrained(model_path, use_fast=False, trust_remote_code=True)
model = AutoModelForCausalLM.from_pretrained(
    model_path,
    torch_dtype=torch_dtype,
    trust_remote_code=True,
    low_cpu_mem_usage=True
).to(device).eval()

def mistral_generate(prompt, max_tokens):
    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    print("Generating...")
    import time
    start_time = time.time()
    outputs = model.generate(
        **inputs,
        max_new_tokens=max_tokens,
        do_sample=False,
        pad_token_id=tokenizer.eos_token_id
    )
    duration = time.time() - start_time
    print(f"Response generated in {duration:.2f} seconds.")
    return tokenizer.decode(outputs[0], skip_special_tokens=True).strip(), duration

# Save tokenizer and model for import
__all__ = ["mistral_generate"]
