#uvicorn splunk_api:app --reload
#pip install python-multipart
#pip install fastapi uvicorn


from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from mistral_loader import mistral_generate
from Splunk_Mistral_Main import context, generate_query_prompt, run_splunk_query
import time
from concurrent.futures import ThreadPoolExecutor

app = FastAPI()
templates = Jinja2Templates(directory="templates")

# ========== LOG ANALYSIS ==========
def summarize_logs(logs):
    formatted = "\n".join([str(log) for log in logs])
    prompt = f'''
        You are a Splunk log analyst.
        Given:
        {formatted}
        1. Summarize top 2 error types by count.
        2. Breakdown: 2xx, 4xx, 5xx counts.
        3. Mention any 5xx codes.
        4. Suggest action.
        Return clean English.
        '''
    return mistral_generate(prompt, max_tokens=512).strip()

# ========== RUN ALL QUERIES ==========
def run_all_queries(user_input):
    print(f"\nRunning all Splunk queries for: {user_input} | Time range: {context['time_range']}\n")

    def process_query(qid):
        try:
            prompt = generate_query_prompt(user_input, qid)
            print(f"\n--- Prompt for Query {qid} ---\n{prompt}\n")
            start_time = time.time()
            response_text = mistral_generate(prompt, max_tokens=256).strip()
            generation_time = time.time() - start_time

            print("\n==== FULL RAW RESPONSE ====")
            print(response_text)
            print("===========================")

            query_start = response_text.lower().find("### splunk query:")
            if query_start != -1:
                query_part = response_text[query_start + len("### Splunk Query:"):].strip()
            else:
                query_part = response_text.strip()

            splunk_query = "\n".join(line.strip() for line in query_part.splitlines() if line.strip())
            if not splunk_query.lower().startswith("search"):
                splunk_query = "search " + splunk_query

            splunk_query = splunk_query \
                .replace('“', '"').replace('”', '"') \
                .replace('‘', "'").replace('’', "'") \
                .replace('–', '-') \
                .replace('`', '"')

            context["last_query"] = splunk_query

            print(f"\n[Query {qid}] Splunk Query:\n{splunk_query}")
            print(f"[Query {qid}] Fetching logs...")
            splunk_start = time.time()
            logs = run_splunk_query(splunk_query)
            splunk_duration = time.time() - splunk_start
            print(f"[Query {qid}] Splunk query executed in {splunk_duration:.2f} seconds.")

            print(f"[Query {qid}] Retrieved {len(logs)} log records.")
            summary = summarize_logs(logs)

            return {
                "qid": qid,
                "query": splunk_query,
                "logs": logs,
                "summary": summary,
                "gen_time": generation_time
            }

        except Exception as e:
            print(f"[Query {qid}] Failed: {str(e)}")
            return {
                "qid": qid,
                "query": "",
                "logs": [],
                "summary": f"Error: {str(e)}",
                "gen_time": 0.0
            }

    with ThreadPoolExecutor(max_workers=7) as executor:
        futures = [executor.submit(process_query, qid) for qid in range(1, 8)]

    all_results = [f.result() for f in futures]

    print("\nSummary of Results:")
    for r in all_results:
        print(f"Query {r['qid']}: {len(r['logs'])} rows")
    return all_results

# ========== ROUTES ==========
@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/generate", response_class=HTMLResponse)
async def generate_query(request: Request, user_input: str = Form(...)):
    all_results = run_all_queries(user_input)
    return templates.TemplateResponse("index.html", {
        "request": request,
        "user_input": user_input,
        "results": all_results
    })

# ========== ENTRY POINT ==========
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("splunk_api:app", host="127.0.0.1", port=8000, reload=True)

