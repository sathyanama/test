from mistral_loader import mistral_generate
import time
from concurrent.futures import ThreadPoolExecutor

# ========== CONTEXT ==========
context = {
    "time_range": "15m",
    "last_query": ""
}

# ========== CLEANUP ========== 
def clean_user_input(user_input):
    stop_words = {"show", "would", "like", "i", "please", "give", "get", "want", "me", "to","customer", "unable", "customers", "seems", "are", "is", "the", "to", "and", 
                                "of", "for", "a", "an", "some", "experienced", "while", "may", "have", 
                                "through", "retrieving", "received", "on", "when", "issues", "issue", "errors", "with","make","perform","in","failures","failure","success","last"}
                                
    tokens = [word.strip().lower() for word in user_input.split() if word.lower() not in stop_words]
    return "*" + "*".join(tokens) + "*" if tokens else user_input

# ========== RUN SPLUNK QUERY MOCK ==========
def run_splunk_query(splunk_query):
    print(f"Mocking query execution for: {splunk_query}")
    return [
        {"channelId": "C30", "httpCode": 200, "count": 4500},
        {"channelId": "MON", "httpCode": 200, "count": 5678},
        {"channelId": "C30", "httpCode": 404, "count": 112},
        {"channelId": "MON", "httpCode": 503, "count": 89},
    ]

# ========== PRINT TABLE ==========
def print_results_table(title, logs):
    print(f"\n{title}")
    print("channelId | httpCode | count")
    print("-----------|----------|------")
    for log in logs:
        print(f"{log['channelId']:9} | {log['httpCode']:8} | {log['count']}")

# ========== GENERATE PROMPT ==========
def generate_query_prompt(user_input, qid):
    cleaned_input = clean_user_input(user_input)
    keyword = cleaned_input.replace(" ", "*")
    prompt = f'''
        You are a Splunk expert.

        From the user input, extract channelId and determine if the query is about failures.
        Format the extracted keyword with wildcards: *payment*, *bill*pay*, *app*data*, etc. Avoid using spaces.

        Build the query:
        - index=abc_digital_19022
        - sourcetype=*httpd*
        - Use wildcard match on urlPath: *<{keyword}>*
        - Add: earliest=-{context['time_range']}
        - If user asks about:
            - Success: httpCode=200 or httpCode=302
            - 4xx Failure: httpCode >= 400 AND httpCode < 500
            - 5xx Failure: httpCode >= 500        
        - Then:
          | stats count by channelId, httpCode

        Return only the query and nothing else.
        ### User Input: {user_input}
        ### Splunk Query:
        '''
    return prompt

# ========== ANALYSIS ==========
def summarize_logs(logs):
    formatted_logs = "\n".join([str(log) for log in logs])
    analysis_prompt = f'''
        You are a Splunk log analyst.

        Below are sample log records from a Splunk query:
        {formatted_logs}

        Please provide a natural language summary with:
        1. The top 2 error types (httpCode 4xx or 5xx) based on highest count.
        2. A brief breakdown of how many 2xx, 4xx, and 5xx responses occurred overall.
        3. Always mention any 5xx codes, even if their count is low.
        4. Suggest what actions might be needed (e.g., investigate high 404s or recurring 5xx).

        Return only a clean English explanation. Do NOT write a Splunk query.
        '''
    ai_summary = mistral_generate(analysis_prompt, max_tokens=256)
    print("\n=== Mistral Log Summary ===")
    print(ai_summary)

# ========== MAIN EXECUTION ==========
def run_all_queries(user_input):
    print(f"\nRunning all Splunk queries for: {user_input} | Time range: {context['time_range']}\n")

    def process_query(qid):
        try:
            prompt = generate_query_prompt(user_input, qid)
            print(f"\n--- Prompt for Query {user_input} ---\n{prompt}\n")
            start_time = time.time()
            response_text = mistral_generate(prompt, max_tokens=128).strip()
            generation_time = time.time() - start_time

            print("\n==== FULL RAW RESPONSE ====")
            print(response_text)
            print("===========================")

            query_start = response_text.lower().find("### splunk query:")
            if query_start != -1:
                query_part = response_text[query_start + len("### Splunk Query:"):].strip()
            else:
                query_part = response_text.strip()

            splunk_query = "\n".join(line.strip() for line in query_part.splitlines() if line.strip())

            if not splunk_query.lower().startswith("search"):
                splunk_query = "search " + splunk_query

            splunk_query = splunk_query \
                .replace('“', '"').replace('”', '"') \
                .replace('‘', "'").replace('’', "'") \
                .replace('–', '-') \
                .replace('`', '"')

            context["last_query"] = splunk_query

            print(f"\n[Query {qid}] Splunk Query:\n{splunk_query}")
            print(f"[Query {qid}] Fetching logs...")
            splunk_start = time.time()
            logs = run_splunk_query(splunk_query)
            splunk_duration = time.time() - splunk_start
            print(f"[Query {qid}] Splunk query executed in {splunk_duration:.2f} seconds.")

            print(f"[Query {qid}] Retrieved {len(logs)} log records.")
            print_results_table(f"[Query {qid}] Results", logs)

            summarize_logs(logs)

            return (qid, logs)

        except Exception as e:
            print(f"[Query {qid}] Failed: {str(e)}")
            return (qid, [])

    with ThreadPoolExecutor(max_workers=7) as executor:
        futures = [executor.submit(process_query, 1)]  # adjust query ID here as needed

    all_results = {qid: logs for qid, logs in (f.result() for f in futures)}

    print("\nSummary of Results:")
    for qid, logs in all_results.items():
        print(f"Query {qid}: {len(logs)} rows")
    return all_results

if __name__ == "__main__":
    while True:
        user_input = input("\nYour request (type 'quit' to exit): ").strip()
        if user_input.lower() == 'quit':
            break
        run_all_queries(user_input)
