#uvicorn splunk_api:app --reload
#pip install python-multipart
#pip install fastapi uvicorn


from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from fastapi.responses import JSONResponse
from splunkLLM_openai  import context, generate_query_prompt,openai_generate
import time
from concurrent.futures import ThreadPoolExecutor

app = FastAPI()
templates = Jinja2Templates(directory="templates")

class QueryRequest(BaseModel):
    user_input: str
    
# ========== LOG ANALYSIS ==========
def summarize_logs(logs):
    formatted_logs = "\n".join([str(log) for log in logs])
    analysis_prompt = f"""
    You are a Splunk log analyst.

    Below are sample log records from a Splunk query:
    {formatted_logs}

    Please provide a natural language summary with:
    1. The top 2 error types (httpCode 4xx or 5xx) based on highest count.
    2. A brief breakdown of how many 2xx, 4xx, and 5xx responses occurred overall.
    3. Always mention any 5xx codes, even if their count is low.
    4. Suggest what actions might be needed (e.g., investigate high 404s or recurring 5xx).

    Return only a clean English explanation. Do NOT write a Splunk query.
    """
    ai_summary = openai_generate(analysis_prompt, max_tokens=512)
    print("\n=== Inside OpenAI Log Summary ===")
    print(ai_summary)
    return ai_summary

# ========== RUN ALL QUERIES ==========
def run_all_queries(user_input):
    print(f"\nRunning all Splunk queries for: {user_input} | Time range: {context['time_range']}\n")
    
    PROMPT_LABELS = {
        1: "Status Code Breakdown",
        2: "Error Message Frequency",
        3: "Timechart by HTTP Code",
        4: "Channel-wise Failures",
        5: "Env-wise Status",
        6: "IP to Region Mapping",
        7: "Service Segment Failures"
    }

    def process_query(qid):
        try:
            prompt = generate_query_prompt(user_input, qid)
            print(f"\n--- Prompt for Query {qid} ---\n{prompt}\n")
            start_time = time.time()
            response_text = openai_generate(prompt, max_tokens=1024).strip()
            generation_time = time.time() - start_time

            print("\n==== Open AI FULL RAW RESPONSE ====")
            print(response_text)
            print("===========================")

            query_start = response_text.lower().find("### splunk query:")
            if query_start != -1:
                query_part = response_text[query_start + len("### Splunk Query:"):].strip()
            else:
                query_part = response_text.strip()

            splunk_query = "\n".join(line.strip() for line in query_part.splitlines() if line.strip())
            if not splunk_query.lower().startswith("search"):
                splunk_query = "search " + splunk_query

            splunk_query = splunk_query \
                .replace('“', '"').replace('”', '"') \
                .replace('‘', "'").replace('’', "'") \
                .replace('–', '-') \
                .replace('`', '"')

            context["last_query"] = splunk_query

            print(f"\n[Query {qid}] Splunk Query:\n{splunk_query}")
            print(f"[Query {qid}] Fetching logs...")
            splunk_start = time.time()
            #logs = run_splunk_query(splunk_query)
            logs = [
                {"channelId": "C30", "httpCode": 200, "count": 4500},
                {"channelId": "MON", "httpCode": 200, "count": 5678},
                {"channelId": "C30", "httpCode": 404, "count": 112},
                {"channelId": "MON", "httpCode": 503, "count": 89},
            ]
            splunk_duration = time.time() - splunk_start
            print(f"[Query {qid}] Splunk query executed in {splunk_duration:.2f} seconds.")

            print(f"[Query {qid}] Retrieved {len(logs)} log records.")
            summary = summarize_logs(logs)
            
            return {
                "qid": qid,
                "label": PROMPT_LABELS.get(qid, f"Prompt {qid}"),
                "query": splunk_query,
                "logs": logs,
                "summary": summary,
                "gen_time": generation_time
            }

        except Exception as e:
            print(f"[Query {qid}] Failed: {str(e)}")
            return {
                "qid": qid,
                "label": PROMPT_LABELS.get(qid, f"Prompt {qid}"),
                "query": "",
                "logs": [],
                "summary": f"Error: {str(e)}",
                "gen_time": 0.0
            }

    with ThreadPoolExecutor(max_workers=7) as executor:
        futures = [executor.submit(process_query, qid) for qid in range(1, 8)]
        #futures = [executor.submit(process_query, 4)]

    all_results = [f.result() for f in futures]

    print("\nSummary of Results:")
    for r in all_results:
        print(f"Query {r['qid']}: {len(r['logs'])} rows")
    return all_results

# ========== ROUTES ==========
@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/generate")
async def generate_query(request_data: QueryRequest):
    user_input = request_data.user_input
    all_results = run_all_queries(user_input)
    return JSONResponse(content={"results": all_results})

# ========== ENTRY POINT ==========
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("splunk_api:app", host="127.0.0.1", port=8000, reload=True)

