import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from splunklib.client import Service
import json
import time
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import pandas as pd

# ========== SPLUNK CONFIG ==========
with open("splunk_config.json") as f:
    SPLUNK_CONFIG = json.load(f)

# ========== CONTEXT MEMORY ==========
context = {
    "last_intent": "",
    "time_range": "15m",
    "last_query": ""
}

# ========== SPLUNK QUERY RUNNER ==========
def run_splunk_query(query):
    service = Service(**SPLUNK_CONFIG)
    service.login()
    job = service.jobs.create(query)

    timeout = 60
    start_time = time.time()
    while not job.is_done():
        if time.time() - start_time > timeout:
            print("Timeout: Splunk job took too long.")
            return []
        time.sleep(1)

    results_stream = job.results(output_mode="json")
    results_json = json.load(results_stream)
    logs = results_json.get('results', [])
    return logs

# ========== MISTRAL LOADER ==========
print("Loading Mistral...")
model_path = "./models/mistral-7b-instruct"
tokenizer = AutoTokenizer.from_pretrained(model_path, use_fast=False, trust_remote_code=True)
device = "cuda" if torch.cuda.is_available() else "cpu"
torch_dtype = torch.float16 if device == "cuda" else torch.float32
model = AutoModelForCausalLM.from_pretrained(model_path, torch_dtype=torch_dtype, trust_remote_code=True, low_cpu_mem_usage=True).to(device).eval()

# ========== TIME UTILS ==========
def is_time_update(user_input):
    import re
    return bool(re.match(r'^(now\s*)?(make it|try|do)\s*\d+\s*(m|mins|minutes|h|hrs|hours)$', user_input.lower()))

def extract_time_range(text):
    import re
    match = re.search(r'(\d+)\s*(m|mins|minutes|h|hrs|hours)', text.lower())
    if match:
        val, unit = match.groups()
        return f"{val}{'m' if 'm' in unit else 'h'}"
    return "15m"

# ========== MISTRAL CHAT ==========
def mistral_generate(prompt, max_tokens=300):
    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    print("Generating...")
    start_time = time.time()
    outputs = model.generate(**inputs, max_new_tokens=max_tokens, do_sample=False)
    duration = time.time() - start_time
    print(f"Response generated in {duration:.2f} seconds.")
    return tokenizer.decode(outputs[0], skip_special_tokens=True).strip()

# ========== PROMPT GENERATORS ==========
def generate_query_prompt(user_input, query_id):
    index_default = SPLUNK_CONFIG.get("index", "index=cfs_digital_88082")
    sourcetype_default = SPLUNK_CONFIG.get("sourcetype", "sourcetype=*httpd*")

    url_mapping_instructions = """
    How to interpret user requests:
    - If the user mentions a service like \"payment\", \"bill pay\", \"user login\", or \"app data\",
      map it to: urlPath="*payment*", urlPath="*bill*pay*", urlPath="*user*login*", urlPath="*app*data*"
      and requestUrl="*payment*", etc. where applicable
    """

    prompts = {
        1: f'''
        You are a Splunk expert.

        From the user input, extract the relevant keyword or phrase (e.g., "app data", "payment", "bill pay", etc.).

        Now construct a Splunk query using the following rules:

        - index=cfs_digital_88082
        - sourcetype=*httpd*
        - urlPath should use wildcard: urlPath="*<extracted>*"
        - Add: earliest=-{context['time_range']} in the main search clause
        - Then:
          | eval urlPath=replace(urlPath, "/?!v|1[^/]*\\d[^/]*", "/X")
          | eval urlPath=replace(urlPath, "::[a-zA-Z0-9]*","::*")
          | eval urlPath=replace(urlPath, "\\/\\d+","/*")
          | stats count as Volume,
                  count(eval(httpCode<=299)) as "Success",
                  count(eval(httpCode=302)) as "302",
                  count(eval(httpCode=304)) as "304",
                  count(eval(httpCode>399 AND httpCode<500)) as "4XX",
                  count(eval(httpCode>499)) as "5XX",
                  count(eval(httpCode=400)) as "400",
                  count(eval(httpCode=401)) as "401",
                  count(eval(httpCode=403)) as "403",
                  count(eval(httpCode=404)) as "404",
                  count(eval(httpCode=409)) as "409",
                  count(eval(httpCode=412)) as "412",
                  count(eval(httpCode=500)) as "500",
                  count(eval(httpCode=502)) as "502",
                  count(eval(httpCode=503)) as "503",
                  count(eval(httpCode=504)) as "504",
                  count(eval(httpCode=512)) as "512",
                  count(eval(httpCode>399)) as Fail,
                  avg(responseTimeMs) as avgResponseTime,
                  perc50(responseTimeMs) as Percentile50,
                  perc95(responseTimeMs) as Percentile95,
                  perc99(responseTimeMs) as Percentile99
                  by urlPath podId
          | eval FP=round(Fail*100/Volume, 2)
          | eval AR=round(avgResponseTime, 0)
          | eval P50=round(Percentile50, 0)
          | eval P95=round(Percentile95, 0)
          | eval P99=round(Percentile99, 0)
          | fields podId* urlPath* Volume* Success* Fail* FP* AR* P95* 4* 5*

        Return only the query and nothing else.
        ### User Input: {user_input}
        ### Splunk Query:
        '''
,

        2: f'''
        You are a Splunk expert.

        From the user input, extract only the relevant keyword or phrase related to service name (e.g., "payment", "bill pay", "quick deposit", "user login", "app/data", etc.).

        Now construct a Splunk query using the following rules:

        - index=cfs_digital_88082
        - sourcetype=*svc*_st
        - requestUrl should match the extracted keyword using wildcard: requestUrl="*<extracted>*"
        - Add conditions: loglevel=ERROR and status
        - Add earliest=-{context['time_range']} in the main search line
        - Then: | eval message=substr(message, 1, 210)
        - Finally: | stats count by message

        Return only the query and nothing else.
        ### User Input: {user_input}
        ### Splunk Query:
        ''',

        3: f'''
        You are a Splunk expert.

        From the user input, extract the relevant keyword or phrase (e.g., "payments", "quick deposit", etc.).

        Now construct a Splunk query using these rules:
        - index=cfs_digital_88082
        - sourcetype=*httpd*
        - urlPath should use wildcard: urlPath="*<extracted>*"
        - Add: earliest=-{{context['time_range']}} in the main search clause
        - Then: | timechart span=5m count by httpCode

        Return only the query and nothing else.
        ### User Input: {{user_input}}
        ### Splunk Query:
        '''

        4: f'''
        You are a Splunk expert.

        From the user input, extract the relevant keyword or phrase.

        Now construct a Splunk query using these rules:
        - index=cfs_digital_88082
        - sourcetype=*httpd*
        - urlPath should use wildcard: urlPath="*<extracted>*"
        - Add: earliest=-{{context['time_range']}} in the main search clause
        - Then: | stats count by channelId

        Return only the query and nothing else.
        ### User Input: {{user_input}}
        ### Splunk Query:
        '''

        5: f'''
        You are a Splunk expert.

        From the user input, extract the relevant keyword or phrase.

        Now construct a Splunk query using these rules:
        - index=cfs_digital_88082
        - sourcetype=*httpd*
        - urlPath should use wildcard: urlPath="*<extracted>*"
        - Add: earliest=-{{context['time_range']}} in the main search clause
        - Then: | stats count by Env

        Return only the query and nothing else.
        ### User Input: {{user_input}}
        ### Splunk Query:
        '''

        6: f'''
        You are a Splunk expert.

        From the user input, extract the relevant keyword or phrase.

        Now construct a Splunk query using these rules:
        - index=cfs_digital_88082
        - sourcetype=*httpd*
        - urlPath should use wildcard: urlPath="*<extracted>*"
        - Add: earliest=-{{context['time_range']}} in the main search clause
        - Then:
          | fields _time, Aggregator, httpCode, xForwardfor
          | lookup IPtoASN CIDR as xForwardfor OUTPUT ASN as ASN, ISP as ISP
          | iplocation allfields=true xForwardfor
          | stats count as Volume by Aggregator, ASN, ISP, Regiion, Country, httpCode

        Return only the query and nothing else.
        ### User Input: {{user_input}}
        ### Splunk Query:
        '''

        7: f'''
        You are a Splunk expert.

        From the user input, extract the relevant keyword or phrase (e.g., "app data", "payment", etc.).

        Now construct a Splunk query using these rules:
        - index=cfs_digital_trace_88082
        - Use wildcard match on the extracted keyword: *<extracted>*
        - Add: message.sc > 499
        - Add: earliest=-{{context['time_range']}} in the main search clause
        - Then: | stats count by message.seg

        Return only the query and nothing else.
        ### User Input: {{user_input}}
        ### Splunk Query:
        '''

    }
    return prompts[query_id]

# ========== FORMAT RESULTS ==========
def print_results_table(title, results):
    if not results:
    print(f"{title}: No results found.")
    return

        df = pd.DataFrame(results)
        print(f"\n{title} [{len(df)} rows]:")

        try:
    from tabulate import tabulate
    print(df.to_markdown(index=False))
        except ImportError:
    print(" Missing optional dependency 'tabulate'. Run: pip install tabulate")
    print(df.head())  # fallback basic table

# ========== PARALLEL QUERY EXECUTION ==========
def run_all_queries(user_input):
    print(f"\nRunning all Splunk queries for: {user_input} | Time range: {context['time_range']}\n")

    def process_query(qid):
        try:
            prompt = generate_query_prompt(user_input, qid)
            start_time = time.time()
            response_text = mistral_generate(prompt, max_tokens=300).strip()
            generation_time = time.time() - start_time

            print("\n==== FULL RAW RESPONSE ====")
            print(response_text)
            print("===========================")

            query_start = response_text.lower().find("### splunk query:")
            if query_start != -1:
                query_part = response_text[query_start + len("### Splunk Query:"):].strip()
            else:
                query_part = response_text.strip()

            splunk_query = query_part.splitlines()[0].strip() if query_part else "search"

            if not splunk_query.lower().startswith("search"):
                splunk_query = "search " + splunk_query
    
            splunk_query = splunk_query \
                .replace('“', '"').replace('”', '"') \
                .replace('‘', "'").replace('’', "'") \
                .replace('–', '-') \
                .replace('`', '"')

            context["last_query"] = splunk_query

            print(f"\n[Query {qid}] Splunk Query:\n{splunk_query}")
            print(f"[Query {qid}] Fetching logs...")
            splunk_start = time.time()
            logs = run_splunk_query(splunk_query)
            splunk_duration = time.time() - splunk_start
            print(f"[Query {qid}] Splunk query executed in {splunk_duration:.2f} seconds.")

            print(f"[Query {qid}] Retrieved {len(logs)} log records.")
            print_results_table(f"[Query {qid}] Results", logs)

            return (qid, logs)

        except Exception as e:
            print(f"[Query {qid}] Failed: {str(e)}")
            return (qid, [])

    with ThreadPoolExecutor(max_workers=7) as executor:
        futures = [executor.submit(process_query, qid) for qid in range(1, 8)]

    all_results = {qid: logs for qid, logs in (f.result() for f in futures)}

    print("\nSummary of Results:")
    for qid, logs in all_results.items():
        print(f"Query {qid}: {len(logs)} rows")
    return all_results

# ========== MAIN ==========
if __name__ == "__main__":
    while True:
        user_input = input("\nYour request (type 'quit' to exit): ").strip()
        if user_input.lower() == 'quit':
            break
        if is_time_update(user_input):
            context['time_range'] = extract_time_range(user_input)
            print(f"Time range updated to: {context['time_range']}")
        else:
            run_all_queries(user_input)
