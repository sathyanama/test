package com.example.demo.repository;

import com.example.demo.model.VendorList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface VendorListRepository extends JpaRepository<VendorList, Long> {
	
	Optional<VendorList> findBySealIdAndSealApplicationName(String sealId, String sealApplicationName);
	
}

