package com.example.demo.repository;

import com.example.demo.model.VendorList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ThirdPartyVendorRepository extends JpaRepository<VendorList, Long> {
}
