package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "vendor_list")
public class VendorList {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    
    @Column(name = "ECONTRACT_NUMBER")
    private String econtractNumber;

    @Column(name = "COMPASS_LINK")
    private String compassLink;

    @Column(name = "CONTRACT_ID")
    private String contractId;

    @Column(name = "CONTRACT_END")
    private LocalDate contractEnd;

    @Lob
    @Column(name = "VENDOR_NAME")
    private String vendorName;

    @Lob
    @Column(name = "ENGEGEMENT_DESCRIPTION")
    private String engegementDescription;

    @Column(name = "PRODUCT_LINE")
    private String productLine;

    @Column(name = "PORTFOLIO")
    private String portfolio;

    @Column(name = "SEAL_ID")
    private String sealId;

    @Lob
    @Column(name = "SEAL_APPLICATION_NAME")
    private String sealApplicationName;

    @Column(name = "SEAL_STATE")
    private String sealState;

    @Column(name = "RTO")
    private String rto;

    @Column(name = "CPOF")
    private String cpof;

    @Lob
    @Column(name = "ESCALATION_PROCEDURE")
    private String escalationProcedure;

    @Lob
    @Column(name = "RUNBOOK")
    private String runbook;

    @Column(name = "RELATIONSHIP_MANAGER")
    private String relationshipManager;

    @Column(name = "DELIVERY_OPERATION_MANAGER")
    private String deliveryOperationManager;

    @Column(name = "L1_OPERATE_MANAGER")
    private String l1OperateManager;

    @Column(name = "L2_OPERATE_MANAGER")
    private String l2OperateManager;

    @Column(name = "TECH_PARTNER_HOT")
    private String techPartnerHot;

    @Column(name = "PRODUCT_OWNER")
    private String productOwner;

    @Column(name = "APPLICATION_OWENER")
    private String applicationOwener;

    @Column(name = "PRODUCTION_DIRECTORS")
    private String productionDirectors;

    @Column(name = "SRE_SUPPORT")
    private String sreSupport;

    @Column(name = "SRE_DIRECTOR")
    private String sreDirector;

    @Lob
    @Column(name = "VENDOR_CONTRACT_E_MAIL")
    private String vendorContractEMail;

    @Column(name = "TEAM")
    private String team;

    @Column(name = "UPDATE_DATE")
    private LocalDateTime updateDate;

    @Column(name = "UPDATE_USERNAME")
    private String updateUserName;

    @Column(name = "UPLOAD_TAG")
    private String uploadTag;
    
    
	public Long getId() {
		return id;
	}
	public String getEcontractNumber() {
		return econtractNumber;
	}
	public String getCompassLink() {
		return compassLink;
	}
	public String getContractId() {
		return contractId;
	}
	public LocalDate getContractEnd() {
		return contractEnd;
	}
	public String getVendorName() {
		return vendorName;
	}
	public String getEngegementDescription() {
		return engegementDescription;
	}
	public String getProductLine() {
		return productLine;
	}
	public String getPortfolio() {
		return portfolio;
	}
	public String getSealId() {
		return sealId;
	}
	public String getSealApplicationName() {
		return sealApplicationName;
	}
	public String getSealState() {
		return sealState;
	}
	public String getRto() {
		return rto;
	}
	public String getCpof() {
		return cpof;
	}
	public String getEscalationProcedure() {
		return escalationProcedure;
	}
	public String getRunbook() {
		return runbook;
	}
	public String getRelationshipManager() {
		return relationshipManager;
	}
	public String getDeliveryOperationManager() {
		return deliveryOperationManager;
	}
	public String getL1OperateManager() {
		return l1OperateManager;
	}
	public String getL2OperateManager() {
		return l2OperateManager;
	}
	public String getTechPartnerHot() {
		return techPartnerHot;
	}
	public String getProductOwner() {
		return productOwner;
	}
	public String getApplicationOwener() {
		return applicationOwener;
	}
	public String getProductionDirectors() {
		return productionDirectors;
	}
	public String getSreSupport() {
		return sreSupport;
	}
	public String getSreDirector() {
		return sreDirector;
	}
	public String getVendorContractEMail() {
		return vendorContractEMail;
	}
	public String getTeam() {
		return team;
	}
	public LocalDateTime getUpdateDate() {
		return updateDate;
	}
	public String getUpdateUserName() {
		return updateUserName;
	}
	public String getUploadTag() {
		return uploadTag;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setEcontractNumber(String econtractNumber) {
		this.econtractNumber = econtractNumber;
	}
	public void setCompassLink(String compassLink) {
		this.compassLink = compassLink;
	}
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	public void setContractEnd(LocalDate contractEnd) {
		this.contractEnd = contractEnd;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public void setEngegementDescription(String engegementDescription) {
		this.engegementDescription = engegementDescription;
	}
	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}
	public void setPortfolio(String portfolio) {
		this.portfolio = portfolio;
	}
	public void setSealId(String sealId) {
		this.sealId = sealId;
	}
	public void setSealApplicationName(String sealApplicationName) {
		this.sealApplicationName = sealApplicationName;
	}
	public void setSealState(String sealState) {
		this.sealState = sealState;
	}
	public void setRto(String rto) {
		this.rto = rto;
	}
	public void setCpof(String cpof) {
		this.cpof = cpof;
	}
	public void setEscalationProcedure(String escalationProcedure) {
		this.escalationProcedure = escalationProcedure;
	}
	public void setRunbook(String runbook) {
		this.runbook = runbook;
	}
	public void setRelationshipManager(String relationshipManager) {
		this.relationshipManager = relationshipManager;
	}
	public void setDeliveryOperationManager(String deliveryOperationManager) {
		this.deliveryOperationManager = deliveryOperationManager;
	}
	public void setL1OperateManager(String l1OperateManager) {
		this.l1OperateManager = l1OperateManager;
	}
	public void setL2OperateManager(String l2OperateManager) {
		this.l2OperateManager = l2OperateManager;
	}
	public void setTechPartnerHot(String techPartnerHot) {
		this.techPartnerHot = techPartnerHot;
	}
	public void setProductOwner(String productOwner) {
		this.productOwner = productOwner;
	}
	public void setApplicationOwener(String applicationOwener) {
		this.applicationOwener = applicationOwener;
	}
	public void setProductionDirectors(String productionDirectors) {
		this.productionDirectors = productionDirectors;
	}
	public void setSreSupport(String sreSupport) {
		this.sreSupport = sreSupport;
	}
	public void setSreDirector(String sreDirector) {
		this.sreDirector = sreDirector;
	}
	public void setVendorContractEMail(String vendorContractEMail) {
		this.vendorContractEMail = vendorContractEMail;
	}
	public void setTeam(String team) {
		this.team = team;
	}
	public void setUpdateDate(LocalDateTime updateDate) {
		this.updateDate = updateDate;
	}
	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}
	public void setUploadTag(String uploadTag) {
		this.uploadTag = uploadTag;
	}
    
	public void updateFrom(VendorList source) {
	    this.setEcontractNumber(source.getEcontractNumber());
	    this.setCompassLink(source.getCompassLink());
	    this.setContractId(source.getContractId());
	    this.setContractEnd(source.getContractEnd());
	    this.setVendorName(source.getVendorName());
	    this.setEngegementDescription(source.getEngegementDescription());
	    this.setProductLine(source.getProductLine());
	    this.setPortfolio(source.getPortfolio());
	    this.setSealState(source.getSealState());
	    this.setRto(source.getRto());
	    this.setCpof(source.getCpof());
	    this.setEscalationProcedure(source.getEscalationProcedure());
	    this.setRunbook(source.getRunbook());
	    this.setRelationshipManager(source.getRelationshipManager());
	    this.setDeliveryOperationManager(source.getDeliveryOperationManager());
	    this.setL1OperateManager(source.getL1OperateManager());
	    this.setL2OperateManager(source.getL2OperateManager());
	    this.setTechPartnerHot(source.getTechPartnerHot());
	    this.setProductOwner(source.getProductOwner());
	    this.setApplicationOwener(source.getApplicationOwener());
	    this.setProductionDirectors(source.getProductionDirectors());
	    this.setSreSupport(source.getSreSupport());
	    this.setSreDirector(source.getSreDirector());
	    this.setVendorContractEMail(source.getVendorContractEMail());
	    this.setTeam(source.getTeam());
	    this.setUpdateDate(source.getUpdateDate());
	    this.setUpdateUserName(source.getUpdateUserName());
	    this.setUploadTag(source.getUploadTag());
	}


}

