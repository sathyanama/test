package com.example.demo.service;

import com.example.demo.model.VendorList;
import com.example.demo.repository.ThirdPartyVendorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;



@Service
public class ThirdPartyVendorService {

    @Autowired
    private ThirdPartyVendorRepository vendorRepository;

    public List<VendorList> getAllVendors() {
        return vendorRepository.findAll();
    }

    public VendorList getVendorById(Long id) {
        return vendorRepository.findById(id).orElseThrow(() -> new RuntimeException("Vendor not found"));
    }

    
    public void saveVendor(VendorList vendor, String username, String team) {
        ZonedDateTime estTime = ZonedDateTime.now(ZoneId.of("America/New_York"));

        if (vendor.getId() == null) {            
            vendor.setTeam(team);
        }
        vendor.setUpdateUserName(username);
        
        vendor.setUploadTag("M");
        vendor.setUpdateDate(LocalDateTime.now(ZoneId.of("America/New_York")));
        
        vendorRepository.save(vendor);
    }

    public void deleteVendor(Long id) {
        vendorRepository.deleteById(id);
    }
    
    public Page<VendorList> getVendorsPaginated(Pageable pageable) {
        return vendorRepository.findAll(pageable);
    }
    
    
    
  
}

