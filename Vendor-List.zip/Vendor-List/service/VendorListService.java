package com.example.demo.service;

import com.example.demo.model.VendorList;
import com.example.demo.repository.VendorListRepository;
import com.example.demo.util.ExcelHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;

@Service
public class VendorListService {

    @Autowired
    private VendorListRepository vendorListRepository;

    public void processVendorExcel(MultipartFile file, String username, String team) {
        try {
            List<VendorList> vendorListFromExcel = ExcelHelper.convertExcelToVendorList(file);

            for (VendorList excelVendor : vendorListFromExcel) {
                Optional<VendorList> existingOpt = vendorListRepository.findBySealIdAndSealApplicationName(
                        excelVendor.getSealId(), excelVendor.getSealApplicationName());

                excelVendor.setUpdateUserName(username);
                excelVendor.setTeam(team);
                excelVendor.setUploadTag("F");
                excelVendor.setUpdateDate(LocalDateTime.now(ZoneId.of("America/New_York"))); // EST

                if (existingOpt.isPresent()) {
                    // Update the existing entity's fields
                    VendorList existing = existingOpt.get();
                    existing.updateFrom(excelVendor); // You will implement this method
                    vendorListRepository.save(existing);
                } else {
                    vendorListRepository.save(excelVendor);
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to process Excel file: " + e.getMessage(), e);
        }
    }
}

