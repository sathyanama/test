package com.example.demo.util;

import com.example.demo.model.VendorList;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class ExcelHelper {

    public static List<VendorList> convertExcelToVendorList(MultipartFile file) {
        List<VendorList> vendorLists = new ArrayList<>();

        try (InputStream is = file.getInputStream(); Workbook workbook = new XSSFWorkbook(is)) {
            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rows = sheet.iterator();

            int rowNumber = 0;
            while (rows.hasNext()) {
                Row row = rows.next();
                if (rowNumber++ == 0) continue; // skip header

                VendorList vendor = new VendorList();
                vendor.setEcontractNumber(getStringCell(row, 0));
                vendor.setCompassLink(getStringCell(row, 1));
                vendor.setContractId(getStringCell(row, 2));
                vendor.setContractEnd(getDateCell(row, 3));
                vendor.setVendorName(getStringCell(row, 4));
                vendor.setEngegementDescription(getStringCell(row, 5));
                vendor.setProductLine(getStringCell(row, 6));
                vendor.setPortfolio(getStringCell(row, 7));
                vendor.setSealId(getStringCell(row, 8));
                vendor.setSealApplicationName(getStringCell(row, 9));
                vendor.setSealState(getStringCell(row, 10));
                vendor.setRto(getStringCell(row, 11));
                vendor.setCpof(getStringCell(row, 12));
                vendor.setEscalationProcedure(getStringCell(row, 13));
                vendor.setRunbook(getStringCell(row, 14));
                vendor.setRelationshipManager(getStringCell(row, 15));
                vendor.setDeliveryOperationManager(getStringCell(row, 16));
                vendor.setL1OperateManager(getStringCell(row, 17));
                vendor.setL2OperateManager(getStringCell(row, 18));
                vendor.setTechPartnerHot(getStringCell(row, 19));
                vendor.setProductOwner(getStringCell(row, 20));
                vendor.setApplicationOwener(getStringCell(row, 21));
                vendor.setProductionDirectors(getStringCell(row, 22));
                vendor.setSreSupport(getStringCell(row, 23));
                vendor.setSreDirector(getStringCell(row, 24));
                vendor.setVendorContractEMail(getStringCell(row, 25));
                //vendor.setTeam(getStringCell(row, 26));
                // UpdateDate and UploadTag are handled in service
                vendorLists.add(vendor);
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse Excel file: " + e.getMessage());
        }

        return vendorLists;
    }
    
    
    

    private static String getStringCell(Row row, int colIdx) {
        Cell cell = row.getCell(colIdx);
        return (cell == null) ? null : cell.toString().trim();
    }

    public static LocalDate getDateCell(Row row, int cellIndex) {
        Cell cell = row.getCell(cellIndex);
        if (cell == null || cell.getCellType() == CellType.BLANK) {
            return null;
        }

        try {
            // Case 1: Excel native date format
            if (cell.getCellType() == CellType.NUMERIC && DateUtil.isCellDateFormatted(cell)) {
                return cell.getLocalDateTimeCellValue().toLocalDate();
            }

            // Case 2: Excel cell is string — try parsing string patterns
            if (cell.getCellType() == CellType.STRING) {
                String dateStr = cell.getStringCellValue().trim();

                if (dateStr.isEmpty()) return null;

                // Try multiple known patterns
                	DateTimeFormatter[] formatters = new DateTimeFormatter[] {
                    DateTimeFormatter.ofPattern("yyyy-MM-dd"),       // 2026-04-25
                    DateTimeFormatter.ofPattern("dd-MM-yyyy"),       // 25-04-2025
                    DateTimeFormatter.ofPattern("MMM-dd", Locale.ENGLISH), // Apr-25 (fallback)
                };

                for (DateTimeFormatter formatter : formatters) {
                    try {
                        // Special case for "Apr-25" -> add year if missing
                        if (formatter.toString().contains("MMM-dd") && !dateStr.matches(".*\\d{4}")) {
                            dateStr = dateStr + "-2025"; // Default year if missing
                            formatter = DateTimeFormatter.ofPattern("MMM-dd-yyyy", Locale.ENGLISH);
                        }

                        return LocalDate.parse(dateStr, formatter);
                    } catch (DateTimeParseException ignored) {
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error parsing date at row " + row.getRowNum() + ", col " + cellIndex + ": " + e.getMessage());
        }

        return null;
    }

}
