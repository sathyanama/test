package com.example.demo.controller;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import jakarta.servlet.http.HttpSession;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.example.demo.controller.VendorUploadController;
import com.example.demo.service.VendorListService;
import com.example.demo.util.CommonUtil;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;

@WebMvcTest(VendorUploadController.class)
@AutoConfigureMockMvc(addFilters = false)
public class VendorUploadControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private VendorListService vendorListService;

    @MockBean
    private CommonUtil commonUtil;
    
    
    @Test
    void testShowUploadForm_successMessageDisplayed() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/vendor/upload")
                .param("message", "Uploaded successfully"))
                .andExpect(status().isOk())
                .andExpect(model().attributeExists("message"))
                .andExpect(view().name("vendorUpload"));
    }

    @Test
    void testShowUploadForm_errorMessageDisplayed() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/vendor/upload")
                .param("error", "Upload failed"))
                .andExpect(status().isOk())
                .andExpect(model().attributeExists("errorMessage"))
                .andExpect(view().name("vendorUpload"));
    }
    
    @Test
    void testUploadExcel_validFile_redirectsWithSuccess() throws Exception {
        MockMultipartFile mockFile = new MockMultipartFile(
                "file", "vendors.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "dummy content".getBytes());

        mockMvc.perform(MockMvcRequestBuilders.multipart("/vendor/upload")
                .file(mockFile)
                .sessionAttr("username", "testUser")
                .sessionAttr("team", "MC"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("/vendor/upload?message=*"));
    }
    
    @Test
    void testUploadExcel_invalidFileExtension_redirectsWithError() throws Exception {
        MockMultipartFile mockFile = new MockMultipartFile(
                "file", "invalid.txt", "text/plain", "not excel".getBytes());

        mockMvc.perform(MockMvcRequestBuilders.multipart("/vendor/upload")
                .file(mockFile)
                .sessionAttr("username", "testUser")
                .sessionAttr("team", "MC"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("/vendor/upload?error=*"));
    }
    
    
    @Test
    void testUploadExcel_exceptionDuringProcessing_redirectsWithError() throws Exception {
        MockMultipartFile mockFile = new MockMultipartFile(
                "file", "vendors.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "content".getBytes());

        Mockito.doThrow(new RuntimeException("Parse error")).when(vendorListService)
               .processVendorExcel(Mockito.any(), Mockito.anyString(), Mockito.anyString());

        mockMvc.perform(MockMvcRequestBuilders.multipart("/vendor/upload")
                .file(mockFile)
                .sessionAttr("username", "testUser")
                .sessionAttr("team", "MC"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("/vendor/upload?error=*"));
    }
    
    @Test
    void testUploadExcel_shouldRejectInvalidFileFormat() throws Exception {
        MockMultipartFile invalidFile = new MockMultipartFile(
                "file", "test.txt", "text/plain", "dummy content".getBytes());

        mockMvc.perform(multipart("/vendor/upload").file(invalidFile))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("/vendor/upload?error=*"));
    }
}    