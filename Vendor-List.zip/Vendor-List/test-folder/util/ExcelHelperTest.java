package com.example.demo.util;

import com.example.demo.model.VendorList;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ExcelHelperTest {

	@Test
    void testConvertExcelToVendorList_validExcel_returnsList() throws Exception {
        FileInputStream fis = new FileInputStream("src/test/resources/Test_Vendor_Upload.xlsx");
        MockMultipartFile mockFile = new MockMultipartFile("file", "Test_Vendor_Upload.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fis);

        List<VendorList> vendorList = ExcelHelper.convertExcelToVendorList(mockFile);

        assertEquals(1, vendorList.size());
        VendorList vendor = vendorList.get(0);

        assertEquals("ECON123", vendor.getEcontractNumber());
        assertEquals("http://compass.link", vendor.getCompassLink());
        assertEquals("CID456", vendor.getContractId());
        assertNotNull(vendor.getContractEnd());
        assertEquals("Acme Corp", vendor.getVendorName());
        assertEquals("Handles support", vendor.getEngegementDescription());
        assertEquals("Infra", vendor.getProductLine());
        assertEquals("Operations", vendor.getPortfolio());
        assertEquals("SEAL123", vendor.getSealId());
        assertEquals("App001", vendor.getSealApplicationName());
        assertEquals("Active", vendor.getSealState());
        assertEquals("24h", vendor.getRto());
        assertEquals("Y", vendor.getCpof());
        assertEquals("Follow SOP", vendor.getEscalationProcedure());
        assertEquals("http://runbook.link", vendor.getRunbook());
        assertEquals("John Doe", vendor.getRelationshipManager());
        assertEquals("Jane Smith", vendor.getDeliveryOperationManager());
        assertEquals("Alan Turing", vendor.getL1OperateManager());
        assertEquals("Grace Hopper", vendor.getL2OperateManager());
        assertEquals("Yes", vendor.getTechPartnerHot());
        assertEquals("PO Name", vendor.getProductOwner());
        assertEquals("App Owner", vendor.getApplicationOwener());
        assertEquals("Director Name", vendor.getProductionDirectors());
        assertEquals("Y", vendor.getSreSupport());
        assertEquals("SRE Director", vendor.getSreDirector());
        assertEquals("support@vendor.com", vendor.getVendorContractEMail());
    }

    @Test
    void testConvertExcelToVendorList_emptyFile_returnsEmptyList() throws Exception {
        Workbook workbook = new XSSFWorkbook();
        workbook.createSheet("Vendors");

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        workbook.write(out);
        workbook.close();

        MockMultipartFile mockFile = new MockMultipartFile(
                "file", "vendors.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                out.toByteArray()
        );

        List<VendorList> result = ExcelHelper.convertExcelToVendorList(mockFile);
        assertTrue(result.isEmpty());
    }

    @Test
    void testConvertExcelToVendorList_invalidFormat_throwsException() {
        MockMultipartFile invalidFile = new MockMultipartFile(
                "file", "bad.txt", "text/plain", "not an excel".getBytes()
        );

        assertThrows(Exception.class, () -> {
            ExcelHelper.convertExcelToVendorList(invalidFile);
        });
    }
}


