package com.example.demo.model;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

public class VendorListTest {

    @Test
    void testUpdateFrom_shouldCopyBasicFields() {
        VendorList source = new VendorList();
        source.setEcontractNumber("E123");
        source.setCompassLink("https://example.com");
        source.setContractId("C456");

        VendorList target = new VendorList();
        target.updateFrom(source);

        assertEquals("E123", target.getEcontractNumber());
        assertEquals("https://example.com", target.getCompassLink());
        assertEquals("C456", target.getContractId());
    }

    @Test
    void testUpdateFrom_shouldCopySealFields() {
        VendorList source = new VendorList();
        source.setSealState("ACTIVE");
        source.setRto("24");
        source.setCpof("Y");

        VendorList target = new VendorList();
        target.updateFrom(source);

        assertEquals("ACTIVE", target.getSealState());
        assertEquals("24", target.getRto());
        assertEquals("Y", target.getCpof());
    }

    @Test
    void testUpdateFrom_shouldCopyOwnerAndManagerFields() {
        VendorList source = new VendorList();
        source.setRelationshipManager("John Doe");
        source.setL1OperateManager("L1 Manager");

        VendorList target = new VendorList();
        target.updateFrom(source);

        assertEquals("John Doe", target.getRelationshipManager());
        assertEquals("L1 Manager", target.getL1OperateManager());
    }

    @Test
    void testUpdateFrom_shouldCopyAuditFields() {
        VendorList source = new VendorList();
        source.setTeam("MC");
        source.setUpdateUserName("uploader");
        source.setUploadTag("F");
        source.setUpdateDate(LocalDateTime.of(2025, 7, 20, 12, 0));

        VendorList target = new VendorList();
        target.updateFrom(source);

        assertEquals("MC", target.getTeam());
        assertEquals("uploader", target.getUpdateUserName());
        assertEquals("F", target.getUploadTag());
        assertEquals(LocalDateTime.of(2025, 7, 20, 12, 0), target.getUpdateDate());
    }
}
