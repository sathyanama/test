package com.example.demo.service;

import com.example.demo.model.VendorList;
import com.example.demo.repository.VendorListRepository;
import com.example.demo.service.VendorListService;
import com.example.demo.util.ExcelHelper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class VendorListServiceTest {

    @InjectMocks
    private VendorListService vendorListService;

    @Mock
    private VendorListRepository vendorListRepository;

    private VendorList vendorFromExcel;
    private MockMultipartFile mockFile;

    @BeforeEach
    void setup() {
        vendorFromExcel = new VendorList();
        vendorFromExcel.setSealId("SEAL001");
        vendorFromExcel.setSealApplicationName("App001");

        mockFile = new MockMultipartFile("file", "vendors.xlsx", "application/vnd.ms-excel", "dummy".getBytes());
    }

    @Test
    void testProcessVendorExcel_shouldInsertIfNotExists() {
        try (MockedStatic<ExcelHelper> staticMock = mockStatic(ExcelHelper.class)) {
            staticMock.when(() -> ExcelHelper.convertExcelToVendorList(any()))
                      .thenReturn(List.of(vendorFromExcel));

            when(vendorListRepository.findBySealIdAndSealApplicationName("SEAL001", "App001"))
                    .thenReturn(Optional.empty());

            vendorListService.processVendorExcel(mockFile, "uploadUser", "Ops");

            verify(vendorListRepository, times(1)).save(argThat(v ->
                    v.getUpdateUserName().equals("uploadUser") &&
                    v.getTeam().equals("Ops") &&
                    v.getUploadTag().equals("F") &&
                    v.getUpdateDate() != null
            ));
        }
    }

    @Test
    void testProcessVendorExcel_shouldUpdateIfExists() {
        VendorList existing = spy(new VendorList());
        existing.setSealId("SEAL001");
        existing.setSealApplicationName("App001");

        try (MockedStatic<ExcelHelper> staticMock = mockStatic(ExcelHelper.class)) {
            staticMock.when(() -> ExcelHelper.convertExcelToVendorList(any()))
                      .thenReturn(List.of(vendorFromExcel));

            when(vendorListRepository.findBySealIdAndSealApplicationName("SEAL001", "App001"))
                    .thenReturn(Optional.of(existing));

            doNothing().when(existing).updateFrom(any(VendorList.class));

            vendorListService.processVendorExcel(mockFile, "uploader", "TeamX");

            verify(vendorListRepository).save(existing);
        }
    }
    
    @Test
    void testProcessVendorExcel_shouldThrowExceptionOnFailure() {
        MultipartFile badFile = new MockMultipartFile("file", "bad.xlsx", "application/vnd.ms-excel", new byte[0]);

        try (MockedStatic<ExcelHelper> staticMock = mockStatic(ExcelHelper.class)) {
            staticMock.when(() -> ExcelHelper.convertExcelToVendorList(any()))
                      .thenThrow(new RuntimeException("Parse error"));

            RuntimeException ex = assertThrows(RuntimeException.class, () ->
                    vendorListService.processVendorExcel(badFile, "anyUser", "anyTeam"));

            assertTrue(ex.getMessage().contains("Failed to process Excel file"));
        }
    }
}

