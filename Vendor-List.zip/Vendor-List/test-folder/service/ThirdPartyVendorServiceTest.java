package com.example.demo.service;

import com.example.demo.model.VendorList;
import com.example.demo.repository.ThirdPartyVendorRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.data.domain.*;

import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ThirdPartyVendorServiceTest {

    @InjectMocks
    private ThirdPartyVendorService vendorService;

    @Mock
    private ThirdPartyVendorRepository vendorRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllVendors() {
        List<VendorList> mockList = List.of(new VendorList(), new VendorList());
        when(vendorRepository.findAll()).thenReturn(mockList);

        List<VendorList> result = vendorService.getAllVendors();
        assertEquals(2, result.size());
        verify(vendorRepository, times(1)).findAll();
    }

    @Test
    void testGetVendorById_found() {
        VendorList vendor = new VendorList();
        vendor.setId(1L);
        when(vendorRepository.findById(1L)).thenReturn(Optional.of(vendor));

        VendorList result = vendorService.getVendorById(1L);
        assertEquals(1L, result.getId());
        verify(vendorRepository, times(1)).findById(1L);
    }

    @Test
    void testGetVendorById_notFound() {
        when(vendorRepository.findById(99L)).thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, () -> vendorService.getVendorById(99L));
        assertEquals("Vendor not found", ex.getMessage());
    }

    @Test
    void testSaveVendor_newVendor_shouldSetTeamAndUploadTag() {
        VendorList vendor = new VendorList(); // new vendor (id null)
        vendorService.saveVendor(vendor, "uploadUser", "MC");

        assertEquals("uploadUser", vendor.getUpdateUserName());
        assertEquals("MC", vendor.getTeam());
        assertEquals("M", vendor.getUploadTag());
        assertNotNull(vendor.getUpdateDate());

        verify(vendorRepository, times(1)).save(vendor);
    }

    @Test
    void testSaveVendor_existingVendor_shouldNotSetTeam() {
        VendorList vendor = new VendorList();
        vendor.setId(5L); // existing vendor

        vendorService.saveVendor(vendor, "uploadUser2", "ShouldNotSet");

        assertEquals("uploadUser2", vendor.getUpdateUserName());
        assertNotEquals("ShouldNotSet", vendor.getTeam()); // team should not be overridden
        assertEquals("M", vendor.getUploadTag());
        assertNotNull(vendor.getUpdateDate());

        verify(vendorRepository, times(1)).save(vendor);
    }

    @Test
    void testDeleteVendor() {
        vendorService.deleteVendor(10L);
        verify(vendorRepository, times(1)).deleteById(10L);
    }

    @Test
    void testGetVendorsPaginated() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<VendorList> mockPage = new PageImpl<>(List.of(new VendorList(), new VendorList()));
        when(vendorRepository.findAll(pageable)).thenReturn(mockPage);

        Page<VendorList> result = vendorService.getVendorsPaginated(pageable);
        assertEquals(2, result.getContent().size());
        verify(vendorRepository, times(1)).findAll(pageable);
    }
}
