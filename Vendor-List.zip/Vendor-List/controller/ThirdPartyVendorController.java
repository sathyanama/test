package com.example.demo.controller;

import com.example.demo.model.VendorList;
import com.example.demo.service.ThirdPartyVendorService;
import com.example.demo.util.CommonUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

@Controller
@RequestMapping("/vendor")
public class ThirdPartyVendorController {

    private final ThirdPartyVendorService vendorService;
    private final CommonUtil commonUtil;

    public ThirdPartyVendorController(ThirdPartyVendorService vendorService, CommonUtil commonUtil) {
        this.vendorService = vendorService;
        this.commonUtil = commonUtil;
    }

    
    @GetMapping("/list")
    public String viewVendors(Model model,
                              HttpServletRequest request,
                              @RequestParam(defaultValue = "0") int page,
                              @RequestParam(defaultValue = "100") int size,
                              @RequestParam(required = false) String message) {

        commonUtil.addUserDetailsToModel(model, "Vendor-List", "Vendor-List", request);

        Pageable pageable = PageRequest.of(page, size, Sort.by("updateDate").descending());
        Page<VendorList> pagedResult = vendorService.getVendorsPaginated(pageable);

        model.addAttribute("records", pagedResult.getContent());
        model.addAttribute("totalPages", pagedResult.getTotalPages());
        model.addAttribute("currentPage", page);
        model.addAttribute("message", message);

        return "vendorListView";
    }
    
    @GetMapping("/view-details/{id}")
    public String viewVendorDetails(@PathVariable Long id, Model model, HttpServletRequest request) {
    	
    	commonUtil.addUserDetailsToModel(model, "Vendor-List", "Vendor-List", request);    	
        VendorList vendor = vendorService.getVendorById(id);
        model.addAttribute("vendor", vendor);                
        return "vendorDetailView";
    }
    
    @GetMapping("/details/{id}")
    public String viewFullVendorDetails(@PathVariable Long id,
                                        @RequestParam(required = false, defaultValue = "view") String action,
                                        Model model,
                                        HttpServletRequest request) {

        commonUtil.addUserDetailsToModel(model, "Vendor-Full-Details", "Vendor-Full-Details", request);

        VendorList vendor = vendorService.getVendorById(id);
        model.addAttribute("vendor", vendor);
        model.addAttribute("action", action);

        return "vendorFullDetailView";
    }
    
    @GetMapping("/add")
    public String showAddForm(Model model,HttpServletRequest request) {
    	
    	commonUtil.addUserDetailsToModel(model, "Vendor-Full-Details", "Vendor-Full-Details", request);
    	
    	model.addAttribute("vendor", new VendorList());
        model.addAttribute("action", "add");
        return "vendorFullDetailView";
    }
    
    
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model,HttpServletRequest request) {
    	
    	commonUtil.addUserDetailsToModel(model, "Vendor-Full-Details", "Vendor-Full-Details", request);
    	
    	VendorList vendor = vendorService.getVendorById(id);
        model.addAttribute("vendor", vendor);
        model.addAttribute("action", "edit");
        return "vendorFullDetailView";
    }
    
    @PostMapping("/save")
    public String saveVendor(@ModelAttribute VendorList vendor,
    		HttpServletRequest request, Model model) {
    	
    	commonUtil.addUserDetailsToModel(model, "Vendor-Full-Details", "Vendor-Full-Details", request);
    	
        String username = (String) request.getSession().getAttribute("username");
        String team = (String) request.getSession().getAttribute("team");

        vendorService.saveVendor(vendor, username, team);
        
        return "redirect:/vendor/list?message=Vendor Details Saved Successfully";
    }
    
    @GetMapping("/delete/{id}")
    public String deleteVendor(@PathVariable Long id, HttpServletRequest request,Model model) {
    	commonUtil.addUserDetailsToModel(model, "Vendor-Full-Details", "Vendor-Full-Details", request);
        vendorService.deleteVendor(id);
        
        return "redirect:/vendor/list?message=Vendor Details Deleted Successfully";
    }

    


}

