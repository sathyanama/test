package com.example.demo.controller;

import com.example.demo.service.IncidentTrackerService;
import com.example.demo.service.VendorListService;
import com.example.demo.util.CommonUtil;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping("/vendor")
public class VendorUploadController {
	
	private static final String UPLOAD_XLS = "Vendor-List-Upload";


    @Autowired
    private final VendorListService vendorListService;
    
    private final CommonUtil commonUtil;
    
    @Autowired
    public VendorUploadController(CommonUtil commonUtil, VendorListService vendorListService) {
        this.commonUtil = commonUtil;
        this.vendorListService = vendorListService;
    }
    

    @PostMapping("/upload")
    public String uploadExcel(@RequestParam("file") MultipartFile file, Model model, HttpServletRequest request) {
    	
    	commonUtil.addUserDetailsToModel(model, UPLOAD_XLS, UPLOAD_XLS, request);
    	
    	HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");
        String team = (String) session.getAttribute("team");
        String message=null;
    	
        try {
            if (!file.getOriginalFilename().endsWith(".xls") && !file.getOriginalFilename().endsWith(".xlsx")) {
            	message = "Invalid file format. Please upload Excel file only.";
                return "redirect:/vendor/upload?error=" + URLEncoder.encode(message, StandardCharsets.UTF_8);
            }
            vendorListService.processVendorExcel(file, username,team);
            message = "Vendor data uploaded successfully!";
            return "redirect:/vendor/upload?message=" + URLEncoder.encode(message, StandardCharsets.UTF_8);
        } catch (Exception e) {
        	message = "Upload failed: " + e.getMessage();
            return "redirect:/vendor/upload?error=" + URLEncoder.encode(message, StandardCharsets.UTF_8);
        }                
    }

    @GetMapping("/upload")
    public String showUploadForm(Model model, HttpServletRequest request) {
    	
    	commonUtil.addUserDetailsToModel(model, UPLOAD_XLS, UPLOAD_XLS, request);
    	String successMsg = request.getParameter("message");
        String errorMsg = request.getParameter("error");
        
        if (successMsg != null) {
            model.addAttribute("message", successMsg);
        }

        if (errorMsg != null) {
            model.addAttribute("errorMessage", errorMsg);
        }

        return "vendorUpload";
    }
}

