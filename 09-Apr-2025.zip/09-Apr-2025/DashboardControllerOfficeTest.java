package com.example.demo.controller;

import com.example.demo.model.IncidentTracker;
import com.example.demo.service.IncidentTrackerService;
import com.example.demo.util.CommonUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

@WebMvcTest(DashboardController.class)
@AutoConfigureMockMvc(addFilters = false)
public class DashboardControllerOfficeTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CommonUtil commonUtil;

    @MockBean
    private IncidentTrackerService incidentTrackerService;

    @Mock
    private Authentication authentication;

    @Mock
    private SecurityContext securityContext;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);

        when(authentication.getName()).thenReturn("adfsUser");
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
    }

    @Test
    void testOpenDashboard() throws Exception {
        mockMvc.perform(get("/dashboard")
                .sessionAttr("team", "DMC")
                .sessionAttr("location", "SG")
                .sessionAttr("role", "ADMIN"))
                .andExpect(status().isOk())
                .andExpect(view().name("dashboard"));
    }

    @Test
    void testOpenMenu() throws Exception {
        mockMvc.perform(get("/menu")
                .sessionAttr("team", "DMC")
                .sessionAttr("location", "SG")
                .sessionAttr("role", "ADMIN"))
                .andExpect(status().isOk())
                .andExpect(view().name("menu"));
    }

    @Test
    void testOpenSearch() throws Exception {
        mockMvc.perform(get("/search")
                .sessionAttr("team", "DMC")
                .sessionAttr("location", "SG")
                .sessionAttr("role", "ADMIN"))
                .andExpect(status().isOk())
                .andExpect(view().name("search"));
    }

    @Test
    void testHandleLandingSearch() throws Exception {
        when(incidentTrackerService.findIncidentsBySearchCriteria(anyString(), anyString()))
                .thenReturn(Collections.singletonList(new IncidentTracker()));

        mockMvc.perform(post("/landingSearch")
                .param("query", "network")
                .sessionAttr("team", "DMC")
                .sessionAttr("role", "ADMIN"))
                .andExpect(status().isOk())
                .andExpect(view().name("dashboard"))
                .andExpect(model().attributeExists("incidents"))
                .andExpect(model().attributeExists("team"));
    }

    @Test
    void testGetHandoverPage() throws Exception {
        when(incidentTrackerService.getFlaggedIncidents(anyString(), anyString()))
                .thenReturn(Collections.singletonList(new IncidentTracker()));

        mockMvc.perform(get("/handover")
                .sessionAttr("team", "DMC")
                .sessionAttr("location", "SG")
                .sessionAttr("role", "ADMIN"))
                .andExpect(status().isOk())
                .andExpect(view().name("handover"))
                .andExpect(model().attributeExists("flaggedIncidents"));
    }

    @Test
    void testChatServicePage() throws Exception {
        mockMvc.perform(get("/chat-service")
                .sessionAttr("team", "DMC")
                .sessionAttr("location", "SG")
                .sessionAttr("role", "ADMIN"))
                .andExpect(status().isOk())
                .andExpect(view().name("chatService"));
    }
}