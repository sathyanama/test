package com.example.demo.repository;


import com.example.demo.model.VendorList;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ThirdPartyVendorRepository extends JpaRepository<VendorList, Long> {
	
	 // Vendor Landing Page Search Criteria 
    @Query(value = "SELECT * FROM vendor_list i " +
            "WHERE (UPPER(i.SEAL_ID) LIKE UPPER(CONCAT('%', :query, '%')) " +
            "OR UPPER(i.VENDOR_NAME) LIKE UPPER(CONCAT('%', :query, '%')) " +            
            "OR LOWER(i.SEAL_APPLICATION_NAME) LIKE LOWER(CONCAT('%', :query, '%'))) " +
            "ORDER BY i.UPDATE_DATE DESC", nativeQuery = true)
    List<VendorList> findVendorBySearchCriteria(@Param("query") String query);
}
