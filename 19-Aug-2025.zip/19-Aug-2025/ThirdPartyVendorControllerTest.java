package com.example.demo.controller;

import com.example.demo.model.VendorList;
import com.example.demo.service.ThirdPartyVendorService;
import com.example.demo.util.CommonUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;


import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;


public class ThirdPartyVendorControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ThirdPartyVendorService vendorService;

    @Mock
    private CommonUtil commonUtil;

    @InjectMocks
    private ThirdPartyVendorController vendorController;

    private MockHttpSession session;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(vendorController).build();

        session = new MockHttpSession();
        session.setAttribute("username", "testUser");
        session.setAttribute("team", "MC");
    }

    @Test
    public void testViewVendors() throws Exception {
        when(vendorService.getVendorsPaginated(any())).thenReturn(Page.empty());
        mockMvc.perform(MockMvcRequestBuilders.get("/vendor/list").session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("vendorListView"));
    }

    @Test
    public void testViewVendorDetails() throws Exception {
        VendorList vendor = new VendorList();
        vendor.setId(1L);
        when(vendorService.getVendorById(1L)).thenReturn(vendor);

        mockMvc.perform(MockMvcRequestBuilders.get("/vendor/view-details/1").session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("vendorDetailView"))
                .andExpect(model().attributeExists("vendor"));
    }

    @Test
    public void testViewFullVendorDetails() throws Exception {
        VendorList vendor = new VendorList();
        when(vendorService.getVendorById(1L)).thenReturn(vendor);

        mockMvc.perform(MockMvcRequestBuilders.get("/vendor/details/1").session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("vendorFullDetailView"))
                .andExpect(model().attributeExists("vendor"))
                .andExpect(model().attribute("action", "view"));
    }

    @Test
    public void testShowAddForm() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/vendor/add").session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("vendorFullDetailView"))
                .andExpect(model().attribute("action", "add"))
                .andExpect(model().attributeExists("vendor"));
    }

    @Test
    public void testShowEditForm() throws Exception {
        VendorList vendor = new VendorList();
        vendor.setId(1L);
        when(vendorService.getVendorById(1L)).thenReturn(vendor);

        mockMvc.perform(MockMvcRequestBuilders.get("/vendor/edit/1").session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("vendorFullDetailView"))
                .andExpect(model().attribute("action", "edit"))
                .andExpect(model().attributeExists("vendor"));
    }

    @Test
    public void testSaveVendor() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/vendor/save")
                        .param("vendorName", "Sample Vendor")
                        .session(session))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/vendor/list?message=Vendor Details Saved Successfully"));

        verify(vendorService, times(1)).saveVendor(any(), eq("testUser"), eq("MC"));
    }

    @Test
    public void testDeleteVendor() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/vendor/delete/1").session(session))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/vendor/list?message=Vendor Details Deleted Successfully"));

        verify(vendorService, times(1)).deleteVendor(1L);
    }
    
    //adeed newly
    
    @Test
    void testSearchVendors() throws Exception {
        String query = "TestQuery";

        VendorList vendor = new VendorList();
        vendor.setVendorName("TestVendor");

        List<VendorList> vendorList = Collections.singletonList(vendor);

        when(vendorService.findVendorBySearchCriteria(query)).thenReturn(vendorList);

        mockMvc.perform(post("/vendor/landingVendor")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("query", query)
                .sessionAttr("username", "testUser")
                .sessionAttr("team", "testTeam")
                .sessionAttr("role", "admin"))
            .andExpect(status().isOk())
            .andExpect(view().name("vendorListView"))
            .andExpect(model().attribute("records", vendorList))
            .andExpect(model().attribute("username", "testUser"))
            .andExpect(model().attribute("team", "testTeam"))
            .andExpect(model().attribute("role", "admin"));

        verify(vendorService, times(1)).findVendorBySearchCriteria(query);        
    }
}


