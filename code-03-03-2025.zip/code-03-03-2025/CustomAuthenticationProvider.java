package com.example.demo.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

    @Autowired
    private UserService userService;

    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private UserRepository userRepository;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String username = authentication.getName();
        String password = authentication.getCredentials().toString();

        UserDetails userDetails  = userService.loadUserByUsername(username);

        if (userDetails  == null) {
            throw new BadCredentialsException("Invalid Username"); // Custom error message
        }
        
        // Check if the user is approved (0 = not approved, 1 = approved)
        
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new BadCredentialsException("Invalid Username"));
        
        if (!user.getApproveFlag()) { 
            throw new BadCredentialsException("Your account has not been approved for login yet");
        }

        System.out.println("Going to invalid password");
        if (!passwordEncoder.matches(password, userDetails .getPassword())) {
            throw new BadCredentialsException("Invalid Password"); // Custom error message
        }

        return new UsernamePasswordAuthenticationToken(
        		userDetails .getUsername(), userDetails .getPassword(), userDetails .getAuthorities());
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
