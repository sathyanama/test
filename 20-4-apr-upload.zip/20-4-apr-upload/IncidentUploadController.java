package com.example.demo.controller;

import com.example.demo.model.IncidentTracker;
import com.example.demo.service.IncidentTrackerService;
import com.example.demo.util.CommonUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

@Controller
public class IncidentUploadController {

	private static final Logger logger = LoggerFactory.getLogger(IncidentUploadController.class);
	
    private final IncidentTrackerService incidentTrackerService;   
    private final CommonUtil commonUtil;

    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final String UPLOAD_CSV = "UPLOAD_CSV";
    private static final String RETRUN_FILE_UPLOAD = "fileUploadIncident";
    private static final String REDIRECT_FILE_UPLOAD = "redirect:/incident/upload";
    private static final String _Username = "username";
    private static final String _Team = "team";
    
    
    
    @Autowired
	 public IncidentUploadController (CommonUtil commonUtil , IncidentTrackerService incidentTrackerService)
	 {
		 this.commonUtil=commonUtil;
		 this.incidentTrackerService = incidentTrackerService;
	 }

    @GetMapping("/incident/upload")
    public String openUploadPage(Model model, HttpServletRequest request) {
        commonUtil.addUserDetailsToModel(model, UPLOAD_CSV, UPLOAD_CSV, request);
        return RETRUN_FILE_UPLOAD;
    }

    @PostMapping("/incident/upload")
    public String handleFileUpload(@RequestParam("file") MultipartFile file,
                                   HttpServletRequest request,
                                   RedirectAttributes redirectAttributes) {
        if (file.isEmpty() ||  (!file.getOriginalFilename().endsWith(".csv") && !file.getOriginalFilename().endsWith(".txt"))) {
			redirectAttributes.addFlashAttribute("errorMessage", "Only CSV or TXT files with ^^ delimiter are supported.");
			return "redirect:/incident/upload";
		}

        HttpSession session = request.getSession();
        String username = (String) session.getAttribute(_Username);
        String team = (String) session.getAttribute(_Team);
        ZoneId estZoneId = ZoneId.of("America/New_York");

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            String header = reader.readLine(); // skip header
            String line;
            logger.info("File Upload Starts");
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("\\^\\^", -1); // using ^^ as delimiter
                
                

                String incidentNumber = fields[0].trim();
                Optional<IncidentTracker> optional = incidentTrackerService.getIncidentByNumberAndTeam(incidentNumber, team);

                IncidentTracker incident = optional.orElse(new IncidentTracker());

                // Always update or insert
                incident.setIncidentNumber(incidentNumber);
                incident.setTeam(team);
                incident.setUpdateUser(username);
                incident.setUpdateDatetime(LocalDateTime.now());
                incident.setCreateBy(username);
                incident.setCreateDatetime(LocalDateTime.now());

                incident.setClassification(fields[2].trim());
                incident.setTag(fields[3].trim());
                incident.setCustomerExp(fields[4].trim());
                incident.setPriority(fields[5].trim());
                incident.setAssignmentGroup(fields[6].trim());
                incident.setImpact(fields[7].trim());
                incident.setStartDatetime(parseDate(fields[8]));
                incident.setDeductDatetime(parseDate(fields[9]));
                incident.setDiagnoseDatetime(parseDate(fields[10]));
                incident.setMitigateDatetime(parseDate(fields[11]));
                incident.setResolveDatetime(parseDate(fields[12]));

                String rawAnalysis = fields[13]; // do NOT trim yet
                String analysis = (rawAnalysis == null) ? null : rawAnalysis.trim();
                if (analysis == null || analysis.isEmpty()) {
                    analysis = incident.getCustomerExp();
                }

                incident.setAnalysis(analysis);

                String impactCount = fields[14].trim();
                incident.setImpactCount(impactCount.isEmpty() ? null : Integer.parseInt(impactCount));

                incident.setFlow(fields[15].trim());
                incident.setSplunkQueries(fields[16].trim());
                incident.setFlagItem(false);

                // Compute duration fields
                incident.calculateTimes();

                if (incident.getTtm() != null)
                    incident.setFormattedTTM(formatDuration(incident.getTtm()));
                if (incident.getMttr() != null)
                    incident.setFormattedMTTR(formatDuration(incident.getMttr()));
                
                incident.setUpdateUser(username);
                incident.setUpdateDatetime(convertToEST(LocalDateTime.now(), estZoneId));

                if (optional.isPresent()) {
                    incident.setId(optional.get().getId()); // update
                }

                incidentTrackerService.saveIncident(incident);
            }
            
            logger.info("File Upload Ends");
            redirectAttributes.addFlashAttribute("successMessage", "File Upload Success");
        } catch (Exception e) {
        	logger.info("Exception");
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("errorMessage", "File Upload Failed: " + e.getMessage());
        }

        return REDIRECT_FILE_UPLOAD;
    }

    private LocalDateTime parseDate(String input) {
        try {
        	if (input == null || input.isEmpty()) return null;
        	return LocalDateTime.parse(input, formatter);

        } catch (Exception e) {
            return null;
        }
    }

    private String formatDuration(Long minutes) {
        long hrs = minutes / 60;
        long min = minutes % 60;
        return hrs + "h " + min + "m";
    }
    
    private LocalDateTime convertToEST(LocalDateTime dateTime, ZoneId estZoneId) {
        return ZonedDateTime.of(dateTime, ZoneId.systemDefault()) // From default system timezone
                .withZoneSameInstant(estZoneId)                   // Convert to EST
                .toLocalDateTime();                               // Return LocalDateTime in EST
    }
}
