package com.example.demo.controller;

import com.example.demo.model.RcaDetails;
import com.example.demo.model.RcaFolder;
import com.example.demo.service.RcaService;
import com.example.demo.service.UserService;
import com.example.demo.service.LogInfoService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.mockito.Mockito.verify;


import java.security.Principal;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(RcaController.class)
@AutoConfigureMockMvc(addFilters = false)
class RcaControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private RcaService rcaService;
    
    @MockBean
    private UserService userService;

    @MockBean
    private LogInfoService logInfoService;

    @Test
    void testOpenRcaPage() throws Exception {
        mockMvc.perform(get("/rca")
                .sessionAttr("team", "DMC")
                .sessionAttr("location", "SG")
                .sessionAttr("role", "ADMIN")
                .principal(() -> "testuser"))
            .andExpect(status().isOk())
            .andExpect(view().name("rcaFolderList"));  // ✅ fixed here
    }
    
    @Test
    void testViewByFolder() throws Exception {
        Long folderId = 1L;
        int page = 0;

        // Prepare mock RCA details
        RcaDetails rcaDetails = new RcaDetails();
        Page<RcaDetails> mockPage = new PageImpl<>(List.of(rcaDetails));
        when(rcaService.getDetailsByFolder(folderId, page, 10)).thenReturn(mockPage);

        // Prepare mock folder
        RcaFolder folder = new RcaFolder();
        folder.setId(folderId);
        folder.setFolderName("Test Folder");
        when(rcaService.getFolderById(folderId)).thenReturn(Optional.of(folder));

        // Perform GET request with session attributes and verify
        mockMvc.perform(get("/rca/view")
                .param("folderId", folderId.toString())
                .param("page", String.valueOf(page))
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC")
                .sessionAttr("role", "ADMIN"))
            .andExpect(status().isOk())
            .andExpect(view().name("rcaView"))
            .andExpect(model().attributeExists("records"))
            .andExpect(model().attributeExists("currentPage"))
            .andExpect(model().attributeExists("totalPages"))
            .andExpect(model().attribute("folderId", folderId))
            .andExpect(model().attribute("folderName", "Test Folder"));
    }
    
    @Test
    void testCreateForm() throws Exception {
        Long folderId = 1L;
        RcaFolder folder = new RcaFolder();
        folder.setId(folderId);

        when(rcaService.getAllFolders()).thenReturn(List.of(folder));

        mockMvc.perform(get("/rca/create")
                .param("folderId", folderId.toString())
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC")
                .sessionAttr("role", "ADMIN"))
            .andExpect(status().isOk())
            .andExpect(view().name("rcaForm"))
            .andExpect(model().attributeExists("rca"))
            .andExpect(model().attributeExists("folders"));
    }
    
    @Test
    void testEditForm() throws Exception {
        Long id = 1L;
        RcaDetails rca = new RcaDetails();
        rca.setId(id);

        when(rcaService.getById(id)).thenReturn(Optional.of(rca));
        when(rcaService.getAllFolders()).thenReturn(List.of(new RcaFolder()));

        mockMvc.perform(get("/rca/edit/{id}", id)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC")
                .sessionAttr("role", "ADMIN"))
            .andExpect(status().isOk())
            .andExpect(view().name("rcaForm"))
            .andExpect(model().attributeExists("rca"))
            .andExpect(model().attributeExists("folders"));
    }

    @Test
    void testSaveRca() throws Exception {
        mockMvc.perform(post("/rca/save")
                .param("rcaFolder.id", "1") // Required to reconstruct nested object
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
            .andExpect(status().is3xxRedirection())
            .andExpect(redirectedUrl("/rca/view?folderId=1"))
            .andExpect(flash().attribute("message", "RCA record saved successfully."));

        verify(rcaService).save(any(RcaDetails.class));
    }


    @Test
    void testDelete() throws Exception {
        Long id = 1L;
        RcaFolder folder = new RcaFolder();
        folder.setId(1L);
        RcaDetails rca = new RcaDetails();
        rca.setId(id);
        rca.setRcaFolder(folder);

        when(rcaService.getById(id)).thenReturn(Optional.of(rca));

        mockMvc.perform(get("/rca/delete/{id}", id))
            .andExpect(status().is3xxRedirection())
            .andExpect(redirectedUrl("/rca/view?folderId=1"));

        verify(rcaService).delete(id);
    }

    @Test
    void testCreateFolder() throws Exception {
        mockMvc.perform(post("/rca/create-folder")
                .param("folderName", "TestFolder")
                .sessionAttr("username", "testuser"))
            .andExpect(status().is3xxRedirection())
            .andExpect(redirectedUrl("/rca"));

        verify(rcaService).createFolder("TestFolder", "testuser");
    }


}
