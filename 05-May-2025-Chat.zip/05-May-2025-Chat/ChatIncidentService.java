package com.example.demo.service;

import com.example.demo.model.ChatIncident;
import com.example.demo.repository.ChatIncidentRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import ai.onnxruntime.OrtException;

import java.util.concurrent.TimeUnit;

@Service
public class ChatIncidentService {

    private final ChatIncidentRepository repository;
    private final EmbeddingService embeddingService;
    
    private static final Logger logger = LoggerFactory.getLogger(ChatIncidentService.class);

    public ChatIncidentService(ChatIncidentRepository repository, EmbeddingService embeddingService) {
        this.repository = repository;
        this.embeddingService = embeddingService;
        System.out.println("ChatIncidentService constructor called...");
    }
    
    //newly updated due to sonar
    public List<ChatIncident> searchIncidentsSqlFiltering(String query, String team) throws Exception {
        logger.info("Starting SQL search with query: {}, team: {}", query, team);

        List<String> keywords = ignoreRelevantKeywords(query);
        List<ChatIncident> incidents = fetchIncidentsBasedOnKeywords(query, keywords, query);

        if (incidents.isEmpty()) {
            logger.info("No incidents found for query: {} and team: {}", query, team);
            return List.of();
        }

        float[] queryEmbedding = getCachedEmbedding(query);
        if (queryEmbedding == null || queryEmbedding.length == 0) {
            throw new IllegalStateException("Query embedding is null or empty!");
        }

        logger.info("Query embedding computed.");

        enrichIncidentEmbeddings(incidents);

        List<ChatIncident> sortedIncidents = sortBySimilarity(incidents, queryEmbedding);

        if (sortedIncidents.size() < 10 && incidents.size() >= 10) {
            logger.info("Less than 10 incidents matched. Filling with top 10 fallback.");
            return incidents.stream().limit(10).collect(Collectors.toList());
        } else if (sortedIncidents.isEmpty()) {
            logger.info("No incidents passed filtering. Returning at least one result.");
            return incidents.stream().limit(1).collect(Collectors.toList());
        }

        return sortedIncidents;
    }
    
    //newly added on 5th May 2025
    private List<ChatIncident> fetchIncidentsBasedOnKeywords(String query, List<String> keywords, String originalQuery) {
        logger.info("Original Query: {}", originalQuery);
        logger.info("Filtered Keywords Count: {}", keywords.size());
        logger.info("Filtered Keywords List: {}", keywords);

        if (keywords.isEmpty() || keywords.size() == 1) {
            logger.info("No meaningful keywords found, using fallback to fetchIncidentsJava.");
            return repository.fetchIncidentsJava(query);
        }

        String searchKeyword1 = keywords.get(0);
        String searchKeyword2 = keywords.size() > 1 ? keywords.get(1) : searchKeyword1;

        logger.info("Found keywords: {} and {}. Calling fetchIncidentsSql.", searchKeyword1, searchKeyword2);
        return repository.fetchIncidentsSql(searchKeyword1, searchKeyword2);
    }

    private void enrichIncidentEmbeddings(List<ChatIncident> incidents) {
        incidents.parallelStream().forEach(incident -> {
            float[] embedding = incident.getEmbedding();
            if (embedding == null || embedding.length == 0) {
                try {
                    String text = determineTextForEmbedding(incident);
                    incident.setEmbedding(getCachedEmbedding(text));
                } catch (Exception e) {
                    logger.error("Error computing embedding for incident ID {}", incident.getId());
                }
            }
        });
    }

    private List<ChatIncident> sortBySimilarity(List<ChatIncident> incidents, float[] queryEmbedding) {
        List<ChatIncident> sorted = incidents.stream()
            .peek(incident -> {
                if (incident.getEmbedding() == null || incident.getEmbedding().length == 0) {
                    try {
                        String text = determineTextForEmbedding(incident);
                        incident.setEmbedding(getCachedEmbedding(text));
                    } catch (Exception e) {
                        logger.error("Error computing embedding during sort for incident ID {}", incident.getId());
                    }
                }
            })
            .sorted(Comparator.comparingDouble(incident -> {
                float[] embedding = incident.getEmbedding();
                if (embedding == null || embedding.length == 0) {
                    return Double.NEGATIVE_INFINITY;  // Push invalid results to the end
                }
                return -cosineSimilarity(queryEmbedding, embedding);
            }))
            .limit(10)
            .collect(Collectors.toList());

        logger.info("Total incidents available: {}", incidents.size());
        sorted.forEach(incident -> logger.info(
            "Incident ID: {}, Similarity: {}",
            incident.getId(),
            cosineSimilarity(queryEmbedding, incident.getEmbedding())
        ));

        return sorted;
    }

    
  //newly ended on 5th May 2025


    protected final Cache<String, float[]> embeddingCache = Caffeine.newBuilder()
            .maximumSize(1000)
            .expireAfterWrite(10, TimeUnit.MINUTES)
            .build();

    protected float[] getCachedEmbedding(String text) throws OrtException {
    	
    	 if (embeddingCache.asMap().containsKey(text)) {
    	        System.out.println("searchIncidentsSqlFiltering - Cache hit for query: " + text);
    	    } else {
    	        System.out.println("searchIncidentsSqlFiltering - Cache miss for query: " + text);
    	    }
    	 try {
    		 return embeddingCache.get(text, key -> {
    	            try {
    	                return embeddingService.computeEmbedding(key);
    	            } catch (OrtException e) {
    	                System.err.println("Embedding computation failed for: " + key);
    	                return new float[0]; // Handle errors gracefully
    	            }
    	        });
    	 } catch (Exception outer) {
	        System.err.println("Unexpected error in caching: " + outer.getMessage());
	        return new float[0]; // Fallback in case Caffeine throws
	    }
    }

    

 // Method to ignore the unwanted words from the query (can be improved with NLP libraries)
    private List<String> ignoreRelevantKeywords(String query) {
        String[] commonWords = {"customer", "unable", "customers", "seems", "are", "is", "the", "to", "and", 
                                "of", "for", "a", "an", "some", "experienced", "while", "may", "have", 
                                "through", "retrieving", "received", "on", "when", "issues", "issue", "errors", "with","make","perform","in"};

        Set<String> allMatch = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        allMatch.addAll(Arrays.asList(commonWords));

        return Arrays.stream(query.split("\\s+"))
                     .filter(word -> !allMatch.contains(word))  // Case-insensitive match
                     .collect(Collectors.toList());
    }

    private String determineTextForEmbedding(ChatIncident incident) {
        // Prioritize customerExp, fallback to analysis, then alertName
        if (incident.getCustomerExp() != null && !incident.getCustomerExp().isEmpty()) {
            return incident.getCustomerExp();
        } else if (incident.getAnalysis() != null && !incident.getAnalysis().isEmpty()) {
            return incident.getAnalysis();
        } else if (incident.getAlertName() != null && !incident.getAlertName().isEmpty()) {
            return incident.getAlertName();
        }
        return "No Text"; // No valid text found
    }

    private double cosineSimilarity(float[] vectorA, float[] vectorB) {
        double dotProduct = 0.0, normA = 0.0, normB = 0.0;
        for (int i = 0; i < vectorA.length; i++) {
            dotProduct += vectorA[i] * vectorB[i];
            normA += Math.pow(vectorA[i], 2);
            normB += Math.pow(vectorB[i], 2);
        }
        return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
    }
}
