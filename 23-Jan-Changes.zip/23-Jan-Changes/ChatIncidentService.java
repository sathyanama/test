package com.example.demo.service;

import com.example.demo.model.ChatIncident;
import com.example.demo.repository.ChatIncidentRepository;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import ai.onnxruntime.OrtException;

import java.util.concurrent.TimeUnit;

@Service
public class ChatIncidentService {

    private final ChatIncidentRepository repository;
    private final EmbeddingService embeddingService;

    public ChatIncidentService(ChatIncidentRepository repository, EmbeddingService embeddingService) {
        this.repository = repository;
        this.embeddingService = embeddingService;
        System.out.println("ChatIncidentService constructor called...");
    }
    
    
    public List<ChatIncident> searchIncidentsSqlFiltering(String query, String team) throws Exception {
        
    	System.out.println("Starting SQL search with query in searchIncidentsSqlFiltering: " + query + ", team: " + team);

        List<String> keywords = ignoreRelevantKeywords(query);
        List<ChatIncident> incidents;

        System.out.println("Original Query: " + query);
        System.out.println("Filtered Keywords Count: " + keywords.size());
        System.out.println("Filtered Keywords List: " + keywords);

        if (keywords.isEmpty()) {
            System.out.println("No meaningful keywords found in query and calling fetchIncidentJava method.");
            incidents = repository.fetchIncidentsJava(query, team);
        } else {
            System.out.println("Found meaningful keywords and calling fetchIncidentsSql.");
            String searchKeyword1 = keywords.get(0);
            String searchKeyword2 = keywords.size() > 1 ? keywords.get(1) : searchKeyword1;
            System.out.println("searchKeyword1: " + searchKeyword1 + " and searchKeyword2: " + searchKeyword2 + " calling fetchIncidentsSql.");
            incidents = repository.fetchIncidentsSql(searchKeyword1, searchKeyword2, team);
        }

        if (incidents.isEmpty()) {
            System.out.println("No incidents found for query: " + query + " and team: " + team);
            return List.of();
        }

        System.out.println("Found " + incidents.size() + " incidents.");

        float[] queryEmbedding = getCachedEmbedding(query);
        if (queryEmbedding == null || queryEmbedding.length == 0) {
            throw new IllegalStateException("Query embedding is null or empty!");
        }
        System.out.println("Query embedding computed.");

        incidents.parallelStream().forEach(incident -> {
            float[] incidentEmbedding = incident.getEmbedding();
            if (incidentEmbedding == null || incidentEmbedding.length == 0) {
                try {
                    String textToEmbed = determineTextForEmbedding(incident);
                    incidentEmbedding = getCachedEmbedding(textToEmbed);
                    incident.setEmbedding(incidentEmbedding);
                } catch (Exception e) {
                    System.err.println("Error computing embedding for incident ID " + incident.getId());
                }
            }
        });

        incidents.sort(Comparator.comparingDouble(incident -> {
            float[] incidentEmbedding = incident.getEmbedding();
            if (incidentEmbedding == null || incidentEmbedding.length == 0) {
                try {
                    String textToEmbed = determineTextForEmbedding(incident);
                    incidentEmbedding = getCachedEmbedding(textToEmbed);
                    incident.setEmbedding(incidentEmbedding);
                } catch (Exception e) {
                    System.err.println("Error computing embedding for incident ID " + incident.getId());
                    return Double.NEGATIVE_INFINITY;
                }
            }
            return cosineSimilarity(queryEmbedding, incidentEmbedding);
        }));

        return incidents.stream().limit(5).collect(Collectors.toList());
    }

    private final Cache<String, float[]> embeddingCache = Caffeine.newBuilder()
            .maximumSize(1000)
            .expireAfterWrite(10, TimeUnit.MINUTES)
            .build();

    private float[] getCachedEmbedding(String text) throws OrtException {
    	
    	 if (embeddingCache.asMap().containsKey(text)) {
    	        System.out.println("searchIncidentsSqlFiltering - Cache hit for query: " + text);
    	    } else {
    	        System.out.println("searchIncidentsSqlFiltering - Cache miss for query: " + text);
    	    }
    	 
        return embeddingCache.get(text, key -> {
            try {
                return embeddingService.computeEmbedding(key);
            } catch (OrtException e) {
                System.err.println("Embedding computation failed for: " + key);
                return new float[0]; // Handle errors gracefully
            }
        });
    }

    public List<ChatIncident> searchIncidentsSqlFiltering_workingonewithoutcache(String query, String team) throws Exception {
    	
        System.out.println("Starting SQL search with query in searchIncidentsSqlFiltering: " + query + ", team: " + team);
             
        List<String> keywords = ignoreRelevantKeywords(query);        
        List<ChatIncident> incidents = null;
        
        System.out.println("Original Query: " + query);
        System.out.println("Filtered Keywords Count: " + keywords.size());
        System.out.println("Filtered Keywords List: " + keywords);
        
        if (keywords.isEmpty()) {
            System.out.println("No meaningful keywords found in query and calling fetchIncidentJava method.");
            incidents = repository.fetchIncidentsJava(query, team);
            //return List.of();
        }
        else
        {
        	System.out.println("Found meaningful keywords and calling fetchIncidentsSql .");        	
        	String searchKeyword1 = keywords.size() > 0 ? keywords.get(0) : "";
            String searchKeyword2 = keywords.size() > 1 ? keywords.get(1) : searchKeyword1;  // Use the same word if only one found    
            System.out.println("searchKeyword1" + searchKeyword1 +" and searchKeyword2 : " + searchKeyword2 +" calling fetchIncidentsSql ."); 
            incidents = repository.fetchIncidentsSql(searchKeyword1, searchKeyword2, team);
        }
                
        if (incidents.isEmpty()) {
            System.out.println("No incidents found for query: " + query + " and team: " + team);
            return List.of();
        }

        System.out.println("Found " + incidents.size() + " incidents.");

        // Compute or retrieve query embedding
        float[] queryEmbedding = embeddingService.computeEmbedding(query);
        if (queryEmbedding == null || queryEmbedding.length == 0) {
            throw new IllegalStateException("Query embedding is null or empty!");
        }
        System.out.println("Query embedding computed.");

        // Rank incidents by similarity
        incidents.sort(Comparator.comparingDouble(incident -> {
            float[] incidentEmbedding = incident.getEmbedding();

            if (incidentEmbedding == null || incidentEmbedding.length == 0) {
                try {
                    String textToEmbed = determineTextForEmbedding(incident);
                    incidentEmbedding = embeddingService.computeEmbedding(textToEmbed);
                    incident.setEmbedding(incidentEmbedding);
                } catch (Exception e) {
                    return Double.NEGATIVE_INFINITY;
                }
            }
            return cosineSimilarity(queryEmbedding, incidentEmbedding);
        }));

        return incidents.stream().limit(5).collect(Collectors.toList());
    }

 // Method to ignore the unwanted words from the query (can be improved with NLP libraries)
    private List<String> ignoreRelevantKeywords(String query) {
        String[] commonWords = {"customer", "unable", "customers", "seems", "are", "is", "the", "to", "and", 
                                "of", "for", "a", "an", "some", "experienced", "while", "may", "have", 
                                "through", "retrieving", "received", "on", "when", "issues", "issue", "errors", "with","make","perform","in"};

        Set<String> allMatch = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        allMatch.addAll(Arrays.asList(commonWords));

        return Arrays.stream(query.split("\\s+"))
                     .filter(word -> !allMatch.contains(word))  // Case-insensitive match
                     .collect(Collectors.toList());
    }

    public List<ChatIncident> searchIncidents_old(String query, String team) throws Exception {
        System.out.println("Starting search with query: " + query + ", team: " + team);

        // Fetch candidate incidents
        List<ChatIncident> incidents = repository.fetchIncidents(query, team);

        if (incidents.isEmpty()) {
            System.out.println("No incidents found for query: " + query + " and team: " + team);
            return List.of(); // Return an empty list if no incidents are found
        } else {
            System.out.println("Found " + incidents.size() + " incidents.");
        }

        // Compute or retrieve query embedding
        float[] queryEmbedding = embeddingService.computeEmbedding(query);
        if (queryEmbedding == null || queryEmbedding.length == 0) {
            throw new IllegalStateException("Query embedding is null or empty!");
        }
        System.out.println("Query embedding: " + Arrays.toString(queryEmbedding));

        // Validate and rank candidates by similarity
        incidents.sort(Comparator.comparingDouble(incident -> {
            float[] incidentEmbedding = incident.getEmbedding();

            // Compute dynamic embedding if missing
            if (incidentEmbedding == null || incidentEmbedding.length == 0) {
                try {
                    System.err.println("Incident missing embedding. Computing dynamically: " + incident.getId());
                    String textToEmbed = determineTextForEmbedding(incident);
                    if (textToEmbed == null || textToEmbed.isEmpty()) {
                        System.err.println("No valid text found for incident: " + incident.getId());
                        return Double.NEGATIVE_INFINITY;
                    }

                    incidentEmbedding = embeddingService.computeEmbedding(textToEmbed);
                    incident.setEmbedding(incidentEmbedding); // Assuming a setter for embedding
                } catch (Exception e) {
                    System.err.println("Error computing embedding for incident: " + incident.getId());
                    return Double.NEGATIVE_INFINITY;
                }
            }

            return cosineSimilarity(queryEmbedding, incidentEmbedding);
        }));

        // Log ranked incidents
        System.out.println("Ranked incidents:");
        incidents.forEach(incident -> {
            float[] incidentEmbedding = incident.getEmbedding();
            if (incidentEmbedding != null && incidentEmbedding.length > 0) {
                double similarity = cosineSimilarity(queryEmbedding, incidentEmbedding);
                System.out.println("Incident ID: " + incident.getId() + ", Similarity: " + similarity);
            }
        });

        // Return top 5 results
        List<ChatIncident> topIncidents = incidents.stream().limit(5).toList();
        if (topIncidents.isEmpty()) {
            System.out.println("No top incidents to return.");
        } else {
            System.out.println("Returning top " + topIncidents.size() + " incidents.");
        }
        return topIncidents;
    }

    private String determineTextForEmbedding(ChatIncident incident) {
        // Prioritize customerExp, fallback to analysis, then alertName
        if (incident.getCustomerExp() != null && !incident.getCustomerExp().isEmpty()) {
            return incident.getCustomerExp();
        } else if (incident.getAnalysis() != null && !incident.getAnalysis().isEmpty()) {
            return incident.getAnalysis();
        } else if (incident.getAlertName() != null && !incident.getAlertName().isEmpty()) {
            return incident.getAlertName();
        }
        return null; // No valid text found
    }

    private double cosineSimilarity(float[] vectorA, float[] vectorB) {
        double dotProduct = 0.0, normA = 0.0, normB = 0.0;
        for (int i = 0; i < vectorA.length; i++) {
            dotProduct += vectorA[i] * vectorB[i];
            normA += Math.pow(vectorA[i], 2);
            normB += Math.pow(vectorB[i], 2);
        }
        return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
    }
}
