def handle_chitchat_response_structured(user_input, history=[], token=None, deployment_id=None):
    try:
        url = f"https://your-api-host.com/v1/deployments/{deployment_id}/chat/completions"
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

        messages = [{"role": "system", "content": "You are a helpful assistant."}]
        for turn in history:
            messages.append({"role": "user", "content": turn["user"]})
            messages.append({"role": "assistant", "content": turn["bot"]})
        messages.append({"role": "user", "content": user_input})

        payload = {"messages": messages}

        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        result = response.json()
        return result["Prompts"][0]["ResponseFromAssistant"].strip()

    except Exception as e:
        print(f"[Chitchat Error - Structured] {e}")
        return "I'm sorry, could you please clarify?"


def handle_chitchat_response_flat(user_input, history=[], token=None, deployment_id=None):
    try:
        url = f"https://your-api-host.com/v1/deployments/{deployment_id}/chat/completions"
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

        # Combine all turns into a text prompt
        conversation = "You are a helpful assistant.\n"
        for turn in history:
            conversation += f"User: {turn['user']}\nAssistant: {turn['bot']}\n"
        conversation += f"User: {user_input}"

        payload = {"question": conversation}

        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        result = response.json()
        return result["Prompts"][0]["ResponseFromAssistant"].strip()

    except Exception as e:
        print(f"[Chitchat Error - Flattened] {e}")
        return "I'm sorry, could you please clarify?"
        
def is_splunk_query(user_input):
    try:
        print(f"[Intent Classifier] User said: {user_input}")
        
        system_prompt = (
            "Classify the user input intent as one of: "
            "splunk_query, general_ai_question, small_talk, thanks.\n\n"
            f"User: {user_input}"
        )

        raw_intent = invoke_chat(token, deployment_id, system_prompt).lower()
        intent = raw_intent.replace("intent:", "").strip()
        
        print(f"[Intent Classifier] GPT raw response: {raw_intent}")
        print(f"[Intent Classifier] Cleaned intent: {intent}")
        print(f"[Intent Classifier] Final interpreted intent: {intent == 'splunk_query'}")

        return intent == "splunk_query"

    except Exception as e:
        print(f"[Classifier Error] {e}")
        return False        