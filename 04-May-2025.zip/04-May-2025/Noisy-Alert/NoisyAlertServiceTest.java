package com.example.demo.service;

import com.example.demo.model.NoisyAlert;
import com.example.demo.repository.NoisyAlertRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.openMocks;

class NoisyAlertServiceTest {

    private NoisyAlertRepository repository;
    private NoisyAlertService service;

    @BeforeEach
    void setUp() {
        repository = mock(NoisyAlertRepository.class);
        service = new NoisyAlertService(repository);
    }

    @Test
    void testFindByTeam() {
        List<NoisyAlert> alerts = new ArrayList<>();
        alerts.add(new NoisyAlert());
        when(repository.findByTeam("DMC")).thenReturn(alerts);

        List<NoisyAlert> result = service.findByTeam("DMC");

        assertEquals(1, result.size());
        verify(repository).findByTeam("DMC");
    }

    @Test
    void testFindByIdExists() {
        NoisyAlert alert = new NoisyAlert();
        alert.setId(1L);
        when(repository.findById(1L)).thenReturn(Optional.of(alert));

        Optional<NoisyAlert> result = service.findById(1L);

        assertTrue(result.isPresent());
        assertEquals(1L, result.get().getId());
    }

    @Test
    void testFindByIdNotFound() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        Optional<NoisyAlert> result = service.findById(99L);

        assertFalse(result.isPresent());
    }

    @Test
    void testSaveNewAlert() {
        NoisyAlert alert = new NoisyAlert();
        alert.setId(null); // new alert

        service.save(alert, "tester", "DMC");

        assertNotNull(alert.getCreateDatetime());
        assertNotNull(alert.getUpdateUserDatetime());
        assertEquals("tester", alert.getUpdateUserName());
        assertEquals("DMC", alert.getTeam());
        verify(repository).save(alert);
    }

    @Test
    void testSaveExistingAlert() {
        NoisyAlert alert = new NoisyAlert();
        alert.setId(10L);
        alert.setCreateDatetime(LocalDateTime.now().minusDays(1));

        service.save(alert, "admin", "PRM");

        assertNotNull(alert.getUpdateUserDatetime());
        assertEquals("admin", alert.getUpdateUserName());
        assertEquals("PRM", alert.getTeam());
        verify(repository).save(alert);
    }

    @Test
    void testDelete() {
        service.delete(7L);

        verify(repository).deleteById(7L);
    }
    
    @Test
    void testSaveNewAlertSetsBlackoutToNIfNull() {
        NoisyAlert alert = new NoisyAlert();
        alert.setId(null); // new alert
        alert.setBlackout(null); // should trigger the condition

        service.save(alert, "tester", "DMC");

        assertEquals("N", alert.getBlackout(), "Blackout should default to 'N'");
        verify(repository).save(alert);
    }

    @Test
    void testSaveNewAlertKeepsBlackoutIfY() {
        NoisyAlert alert = new NoisyAlert();
        alert.setId(null);
        alert.setBlackout("Y"); // valid value

        service.save(alert, "tester", "DMC");

        assertEquals("Y", alert.getBlackout(), "Blackout should remain 'Y'");
        verify(repository).save(alert);
    }

}
