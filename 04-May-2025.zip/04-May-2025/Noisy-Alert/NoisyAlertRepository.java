package com.example.demo.repository;

import com.example.demo.model.NoisyAlert;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface NoisyAlertRepository extends JpaRepository<NoisyAlert, Long> {
    List<NoisyAlert> findByTeam(String team);
}
