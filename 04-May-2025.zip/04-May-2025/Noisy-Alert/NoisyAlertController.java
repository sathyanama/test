package com.example.demo.controller;

import com.example.demo.model.NoisyAlert;
import com.example.demo.service.NoisyAlertService;
import com.example.demo.util.CommonUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/noisy")
public class NoisyAlertController {

    private static final Logger logger = LoggerFactory.getLogger(NoisyAlertController.class);

    private final NoisyAlertService noisyAlertService;
    private final CommonUtil commonUtil;

    private static final String RETURN_PAGE_NOISY_ALERT = "noisyView";

    public NoisyAlertController(NoisyAlertService noisyAlertService, CommonUtil commonUtil) {
        this.noisyAlertService = noisyAlertService;
        this.commonUtil = commonUtil;
    }

    @GetMapping("/view")
    public String viewAlerts(@RequestParam(value = "message", required = false) String message,
                             Model model, HttpServletRequest request) {
        commonUtil.addUserDetailsToModel(model, "NOISY_ALERT", "noisyAlert", request);
        HttpSession session = request.getSession();
        String team = (String) session.getAttribute("team");
        List<NoisyAlert> records = noisyAlertService.findByTeam(team);
        logger.info("Fetched {} noisy alerts for team {}", records.size(), team);
        model.addAttribute("records", records);
        model.addAttribute("message", message);
        return RETURN_PAGE_NOISY_ALERT;
    }

    @GetMapping("/create")
    public String createAlert(Model model, HttpServletRequest request) {
        commonUtil.addUserDetailsToModel(model, "NOISY_ALERT", "noisyAlert", request);
        model.addAttribute("noisyAlert", new NoisyAlert());
        logger.debug("Creating new Noisy Alert entry");
        return "noisyForm";
    }

    @GetMapping("/edit/{id}")
    public String editAlert(@PathVariable Long id, Model model, HttpServletRequest request) {
        commonUtil.addUserDetailsToModel(model, "NOISY_ALERT", "noisyAlert", request);
        Optional<NoisyAlert> alert = noisyAlertService.findById(id);
        logger.info("Editing Noisy Alert with ID {}", id);
        model.addAttribute("noisyAlert", alert.orElse(new NoisyAlert()));
        return "noisyForm";
    }

    @PostMapping("/save")
    public String saveAlert(@ModelAttribute NoisyAlert noisyAlert, HttpServletRequest request, Model model) {
        commonUtil.addUserDetailsToModel(model, "NOISY_ALERT", "noisyAlert", request);
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");
        String team = (String) session.getAttribute("team");
        noisyAlertService.save(noisyAlert, username, team);
        logger.info("Saved Noisy Alert by user {} for team {}", username, team);
        return "redirect:/noisy/view?message=Noisy Alert saved successfully";
    }

    @GetMapping("/delete/{id}")
    public String deleteAlert(@PathVariable Long id, HttpServletRequest request) {
        commonUtil.addUserDetailsToModel(null, "NOISY_ALERT", "noisyAlert", request);
        noisyAlertService.delete(id);
        logger.warn("Deleted Noisy Alert with ID {}", id);
        return "redirect:/noisy/view?message=Noisy Alert deleted";
    }
}
