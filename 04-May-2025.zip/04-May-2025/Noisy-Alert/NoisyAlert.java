// NoisyAlert.java
package com.example.demo.model;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class NoisyAlert {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime createDatetime;
    private String alertType;

    @Lob
    private String summary;

    private String sealId;
    private String type;
    private String product;
    private String status;

    @Lob
    private String runbookReference;
    private String contact;
    private String dmcAssignee;

    @Lob
    private String notes;
    private String blackout;

    @Lob
    private String productJira;
    
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate targetDate;

    private String team;
    private String updateUserName;
    private LocalDateTime updateUserDatetime;

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public LocalDateTime getCreateDatetime() { return createDatetime; }
    public void setCreateDatetime(LocalDateTime createDatetime) { this.createDatetime = createDatetime; }

    public String getAlertType() { return alertType; }
    public void setAlertType(String alertType) { this.alertType = alertType; }

    public String getSummary() { return summary; }
    public void setSummary(String summary) { this.summary = summary; }

    public String getSealId() { return sealId; }
    public void setSealId(String sealId) { this.sealId = sealId; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getProduct() { return product; }
    public void setProduct(String product) { this.product = product; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getRunbookReference() { return runbookReference; }
    public void setRunbookReference(String runbookReference) { this.runbookReference = runbookReference; }

    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }

    public String getDmcAssignee() { return dmcAssignee; }
    public void setDmcAssignee(String dmcAssignee) { this.dmcAssignee = dmcAssignee; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public String getBlackout() { return blackout; }
    public void setBlackout(String blackout) { this.blackout = blackout; }

    public String getProductJira() { return productJira; }
    public void setProductJira(String productJira) { this.productJira = productJira; }

    public LocalDate getTargetDate() { return targetDate; }
    public void setTargetDate(LocalDate  targetDate) { this.targetDate = targetDate; }

    public String getTeam() { return team; }
    public void setTeam(String team) { this.team = team; }

    public String getUpdateUserName() { return updateUserName; }
    public void setUpdateUserName(String updateUserName) { this.updateUserName = updateUserName; }

    public LocalDateTime getUpdateUserDatetime() { return updateUserDatetime; }
    public void setUpdateUserDatetime(LocalDateTime updateUserDatetime) { this.updateUserDatetime = updateUserDatetime; }
}


