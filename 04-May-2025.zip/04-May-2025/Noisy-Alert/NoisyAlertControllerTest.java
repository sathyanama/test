package com.example.demo.controller;

import com.example.demo.model.NoisyAlert;
import com.example.demo.service.NoisyAlertService;
import com.example.demo.util.CommonUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.ui.Model;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.openMocks;

public class NoisyAlertControllerTest {

    @Mock
    private NoisyAlertService noisyAlertService;

    @Mock
    private CommonUtil commonUtil;

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpSession session;

    @Mock
    private Model model;

    @InjectMocks
    private NoisyAlertController controller;

    @BeforeEach
    void setUp() {
        openMocks(this);
        when(request.getSession()).thenReturn(session);
    }

    @Test
    void testViewAlerts() {
        List<NoisyAlert> dummyAlerts = new ArrayList<>();
        when(session.getAttribute("team")).thenReturn("DMC");
        when(noisyAlertService.findByTeam("DMC")).thenReturn(dummyAlerts);

        String viewName = controller.viewAlerts("Success", model, request);

        verify(commonUtil).addUserDetailsToModel(model, "NOISY_ALERT", "noisyAlert", request);
        verify(model).addAttribute("records", dummyAlerts);
        verify(model).addAttribute("message", "Success");
        assertEquals("noisyView", viewName);
    }

    @Test
    void testCreateAlert() {
        String view = controller.createAlert(model, request);

        verify(commonUtil).addUserDetailsToModel(model, "NOISY_ALERT", "noisyAlert", request);
        verify(model).addAttribute(eq("noisyAlert"), any(NoisyAlert.class));
        assertEquals("noisyForm", view);
    }

    @Test
    void testEditAlert() {
        NoisyAlert alert = new NoisyAlert();
        when(noisyAlertService.findById(1L)).thenReturn(Optional.of(alert));

        String view = controller.editAlert(1L, model, request);

        verify(commonUtil).addUserDetailsToModel(model, "NOISY_ALERT", "noisyAlert", request);
        verify(model).addAttribute("noisyAlert", alert);
        assertEquals("noisyForm", view);
    }

    @Test
    void testEditAlertNotFound() {
        when(noisyAlertService.findById(99L)).thenReturn(Optional.empty());

        String view = controller.editAlert(99L, model, request);

        verify(commonUtil).addUserDetailsToModel(model, "NOISY_ALERT", "noisyAlert", request);
        verify(model).addAttribute(eq("noisyAlert"), any(NoisyAlert.class));
        assertEquals("noisyForm", view);
    }

    @Test
    void testSaveAlert() {
        NoisyAlert alert = new NoisyAlert();
        when(session.getAttribute("username")).thenReturn("tester");
        when(session.getAttribute("team")).thenReturn("DMC");

        String view = controller.saveAlert(alert, request, model);

        verify(commonUtil).addUserDetailsToModel(model, "NOISY_ALERT", "noisyAlert", request);
        verify(noisyAlertService).save(alert, "tester", "DMC");
        assertEquals("redirect:/noisy/view?message=Noisy Alert saved successfully", view);
    }

    @Test
    void testDeleteAlert() {
        String view = controller.deleteAlert(10L, request);

        verify(commonUtil).addUserDetailsToModel(null, "NOISY_ALERT", "noisyAlert", request);
        verify(noisyAlertService).delete(10L);
        assertEquals("redirect:/noisy/view?message=Noisy Alert deleted", view);
    }
}