package com.example.demo.service;

import com.example.demo.model.KnownIssue;
import com.example.demo.repository.KnownIssueRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class KnownIssueServiceTest {

    private KnownIssueRepository repository;
    private KnownIssueService service;

    @BeforeEach
    void setUp() {
        repository = mock(KnownIssueRepository.class);
        service = new KnownIssueService(repository); // Use constructor injection directly
    }

    @Test
    void testFindByTeam() {
        when(repository.findByTeam("DMC")).thenReturn(List.of(new KnownIssue()));
        List<KnownIssue> result = service.findByTeam("DMC");

        assertEquals(1, result.size());
        verify(repository, times(1)).findByTeam("DMC");
    }

    @Test
    void testFindById() {
        KnownIssue issue = new KnownIssue();
        issue.setId(1L);

        when(repository.findById(1L)).thenReturn(Optional.of(issue));
        Optional<KnownIssue> result = service.findById(1L);

        assertTrue(result.isPresent());
        assertEquals(1L, result.get().getId());
    }

    @Test
    void testSave() {
        KnownIssue issue = new KnownIssue();
        service.save(issue, "sathya", "DMC");

        ArgumentCaptor<KnownIssue> captor = ArgumentCaptor.forClass(KnownIssue.class);
        verify(repository).save(captor.capture());

        KnownIssue saved = captor.getValue();
        assertEquals("sathya", saved.getUsername());
        assertEquals("DMC", saved.getTeam());
        assertNotNull(saved.getUpdateDatetime());
    }

    @Test
    void testDelete() {
        service.delete(5L);
        verify(repository, times(1)).deleteById(5L);
    }
}
