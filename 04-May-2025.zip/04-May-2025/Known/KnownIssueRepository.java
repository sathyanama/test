package com.example.demo.repository;

import com.example.demo.model.KnownIssue;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface KnownIssueRepository extends JpaRepository<KnownIssue, Long> {
    List<KnownIssue> findByTeam(String team);
}