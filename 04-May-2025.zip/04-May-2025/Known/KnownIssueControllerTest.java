package com.example.demo.controller;

import com.example.demo.model.KnownIssue;
import com.example.demo.service.KnownIssueService;
import com.example.demo.util.CommonUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;
import java.util.Optional;
import java.security.Principal;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(KnownIssueController.class)
@AutoConfigureMockMvc(addFilters = false)
public class KnownIssueControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private KnownIssueService knownIssueService;

    @MockBean
    private CommonUtil commonUtil;

    private Principal principal;

    @BeforeEach
    void setUp() {
        principal = () -> "testuser";
    }

    @Test
    void testViewKnownIssues() throws Exception {
        when(knownIssueService.findByTeam("DMC")).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/known/view")
                        .sessionAttr("team", "DMC")
                        .sessionAttr("username", "testuser")
                        .sessionAttr("role", "USER")
                        .param("message", "Saved")
                        .principal(principal))
                .andExpect(status().isOk())
                .andExpect(view().name("knownView"))
                .andExpect(model().attributeExists("records"))
                .andExpect(model().attribute("message", "Saved"));
    }

    @Test
    void testCreateKnownIssue() throws Exception {
        mockMvc.perform(get("/known/create")
                        .sessionAttr("team", "DMC")
                        .sessionAttr("username", "testuser")
                        .sessionAttr("role", "ADMIN")
                        .principal(principal))
                .andExpect(status().isOk())
                .andExpect(view().name("knownForm"))
                .andExpect(model().attributeExists("knownIssue"));
    }

    @Test
    void testEditKnownIssue_Found() throws Exception {
        KnownIssue ki = new KnownIssue();
        ki.setId(1L);
        ki.setAlertName("Test Alert");

        when(knownIssueService.findById(1L)).thenReturn(Optional.of(ki));

        mockMvc.perform(get("/known/edit/1")
                        .sessionAttr("team", "DMC")
                        .sessionAttr("username", "testuser")
                        .sessionAttr("role", "ADMIN")
                        .principal(principal))
                .andExpect(status().isOk())
                .andExpect(view().name("knownForm"))
                .andExpect(model().attributeExists("knownIssue"));
    }

    @Test
    void testEditKnownIssue_NotFound() throws Exception {
        when(knownIssueService.findById(99L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/known/edit/99")
                        .sessionAttr("team", "DMC")
                        .sessionAttr("username", "testuser")
                        .sessionAttr("role", "ADMIN")
                        .principal(principal))
                .andExpect(status().isOk())
                .andExpect(view().name("knownForm"))
                .andExpect(model().attributeExists("knownIssue"));
    }

    @Test
    void testSaveKnownIssue() throws Exception {
        mockMvc.perform(post("/known/save")
                        .sessionAttr("team", "DMC")
                        .sessionAttr("username", "testuser")
                        .sessionAttr("role", "ADMIN")
                        .param("alertName", "Test Alert")
                        .param("jiraRef", "JIRA-123")
                        .param("description", "Sample description")
                        .principal(principal))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/known/view?message=Known Issue saved successfully"));
    }

    @Test
    void testDeleteKnownIssue() throws Exception {
        doNothing().when(knownIssueService).delete(1L);

        mockMvc.perform(get("/known/delete/1")
                        .sessionAttr("team", "DMC")
                        .sessionAttr("username", "testuser")
                        .sessionAttr("role", "ADMIN")
                        .principal(principal))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/known/view?message=Known Issue deleted"));
    }
}
