package com.example.demo.service;

import com.example.demo.model.KnownIssue;
import com.example.demo.repository.KnownIssueRepository;
import org.springframework.stereotype.Service;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class KnownIssueService {

    
    private final KnownIssueRepository repository;
    
    public KnownIssueService(KnownIssueRepository repository) {
        this.repository = repository;               
    }

    public List<KnownIssue> findByTeam(String team) {
        return repository.findByTeam(team);
    }

    public Optional<KnownIssue> findById(Long id) {
        return repository.findById(id);
    }

    public void save(KnownIssue issue, String username, String team) {
        issue.setUsername(username);
        issue.setTeam(team);
        issue.setUpdateDatetime(ZonedDateTime.now(ZoneId.of("America/New_York")).toLocalDateTime());
        repository.save(issue);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}