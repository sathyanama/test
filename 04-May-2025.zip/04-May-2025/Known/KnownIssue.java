package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "known_issue")
public class KnownIssue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String team;

    @Lob
    private String alertName;

    @Lob
    private String jiraRef;

    @Lob
    private String description;

    private String username;

    private LocalDateTime updateDatetime;

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTeam() { return team; }
    public void setTeam(String team) { this.team = team; }

    public String getAlertName() { return alertName; }
    public void setAlertName(String alertName) { this.alertName = alertName; }

    public String getJiraRef() { return jiraRef; }
    public void setJiraRef(String jiraRef) { this.jiraRef = jiraRef; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public LocalDateTime getUpdateDatetime() { return updateDatetime; }
    public void setUpdateDatetime(LocalDateTime updateDatetime) { this.updateDatetime = updateDatetime; }
}
