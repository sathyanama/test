package com.example.demo.controller;

import com.example.demo.model.KnownIssue;
import com.example.demo.service.KnownIssueService;
import com.example.demo.util.CommonUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/known")
public class KnownIssueController {

    private static String RETURN_PAGE_KNOWN_ISSUE = "knownView";
    private static String _knownView = "KNOWN-VIEW";
    
    private static String _knownForm = "knownForm";
    private static String _knownCreate = "KNOWN-CREATE";
    private static String _knownEdit = "KNOWN-EDIT";
    private static String _knownSave = "KNOWN-SAVE";
    private static String _knownDelete = "KNOWN-DELETE";
    

    @Autowired
    private KnownIssueService knownIssueService;

    @Autowired
    private CommonUtil commonUtil;

    @GetMapping("/view")
    public String viewKnownIssues(Model model, HttpServletRequest request,
                                   @RequestParam(value = "message", required = false) String message) {
        commonUtil.addUserDetailsToModel(model, _knownView, _knownView, request);
        HttpSession session = request.getSession();
        String team = (String) session.getAttribute("team");
        model.addAttribute("records", knownIssueService.findByTeam(team));
        model.addAttribute("message", message);
        return RETURN_PAGE_KNOWN_ISSUE;
    }

    @GetMapping("/create")
    public String create(Model model, HttpServletRequest request) {
        commonUtil.addUserDetailsToModel(model, _knownCreate, _knownCreate, request);
        model.addAttribute("knownIssue", new KnownIssue());
        return _knownForm;
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable Long id, Model model, HttpServletRequest request) {
        commonUtil.addUserDetailsToModel(model, _knownEdit, _knownEdit, request);
        knownIssueService.findById(id).ifPresentOrElse(
                ki -> model.addAttribute("knownIssue", ki),
                () -> model.addAttribute("knownIssue", new KnownIssue())
        );
        return _knownForm;
    }

    @PostMapping("/save")
    public String save(@ModelAttribute KnownIssue knownIssue, HttpServletRequest request, Model model) {
        commonUtil.addUserDetailsToModel(model, _knownSave, _knownSave, request);
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");
        String team = (String) session.getAttribute("team");
        knownIssueService.save(knownIssue, username, team);
        return "redirect:/known/view?message=Known Issue saved successfully";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, HttpServletRequest request, Model model) {
        commonUtil.addUserDetailsToModel(model, _knownDelete, _knownDelete, request);
        knownIssueService.delete(id);
        return "redirect:/known/view?message=Known Issue deleted";
    }
}