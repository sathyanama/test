import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class TicketService {

    private static final Logger logger = LoggerFactory.getLogger(TicketService.class);
    private final AdfsProperties adfsProperties;

    public TicketService(AdfsProperties adfsProperties) {
        this.adfsProperties = adfsProperties;
    }

    public List<TicketDetails> getT3IncidentDetails(String incidentNumber) throws InterruptedException {
        RestTemplate restTemplate = new RestTemplate();
        String externalApiUrl = adfsProperties.getExternalT3URL() + incidentNumber;

        ResponseEntity<String> response = restTemplate.getForEntity(externalApiUrl, String.class);
        if (response.getStatusCode() != HttpStatus.OK || response.getBody() == null) {
            logger.error("Error fetching ticket details from external system. Status: {}", response.getStatusCode());
            Thread.sleep(10000);
            return Collections.emptyList();
        }

        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode rootNode;
        try {
            rootNode = objectMapper.readTree(response.getBody());
        } catch (JsonProcessingException e) {
            logger.error("Error parsing JSON response", e);
            return Collections.emptyList();
        }

        if (rootNode == null || !rootNode.isArray() || rootNode.isEmpty()) {
            logger.info("Root JSON node is empty or not an array.");
            return Collections.emptyList();
        }

        Map<String, TicketDetails> ticketMap = new LinkedHashMap<>();

        for (JsonNode element : rootNode) {
            Optional.ofNullable(extractTicketDetails(element, ticketMap))
                    .ifPresent(ticket -> ticketMap.put(ticket.getIncidentNumber(), ticket));
        }

        return new ArrayList<>(ticketMap.values());
    }

    private TicketDetails extractTicketDetails(JsonNode element, Map<String, TicketDetails> ticketMap) {
        String incidentNum = element.path("cgsincident.incident_numner").asText("");
        return Optional.ofNullable(incidentNum)
                .filter(num -> !num.isBlank())
                .map(num -> {
                    TicketDetails ticket = ticketMap.getOrDefault(num, new TicketDetails());
                    ticket.setIncidentNumber(num);

                    ticket.setShortDescription(Optional.ofNullable(ticket.getShortDescription()).orElse(element.path("cgsincident.short_description").asText("")));
                    ticket.setState(Optional.ofNullable(ticket.getState()).orElse(element.path("cgsincident.state").asText("")));
                    ticket.setAssignmentGroup(Optional.ofNullable(ticket.getAssignmentGroup()).orElse(element.path("cgsincident.assignment_group").asText("")));
                    ticket.setAssignmentTo(Optional.ofNullable(ticket.getAssignmentTo()).orElse(element.path("cgsincident.assignment_to").asText("")));
                    ticket.setOpenedTime(Optional.ofNullable(ticket.getOpenedTime()).orElse(element.path("cgsincident.opened_time_est").asText("")));
                    ticket.setClosedTime(Optional.ofNullable(ticket.getClosedTime()).orElse(element.path("cgsincident.closed_time_est").asText("")));
                    ticket.setMiStarted(Optional.ofNullable(ticket.getMiStarted()).orElse(element.path("cgsincident.mi_started_est").asText("")));
                    ticket.setMiDiagonosed(Optional.ofNullable(ticket.getMiDiagonosed()).orElse(element.path("cgsincident.mi_diagonosed_est").asText("")));
                    ticket.setMiDetected(Optional.ofNullable(ticket.getMiDetected()).orElse(element.path("cgsincident.mi_detected_est").asText("")));
                    ticket.setMiMitigated(Optional.ofNullable(ticket.getMiMitigated()).orElse(element.path("cgsincident.mi_mitigated_est").asText("")));
                    ticket.setMiResolved(Optional.ofNullable(ticket.getMiResolved()).orElse(element.path("cgsincident.mi_resolved_est").asText("")));
                    ticket.setImpact(Optional.ofNullable(ticket.getImpact()).orElse(element.path("cgsincident.impact").asText("")));
                    ticket.setUrgency(Optional.ofNullable(ticket.getUrgency()).orElse(element.path("cgsincident.urgency").asText("")));
                    ticket.setPriority(Optional.ofNullable(ticket.getPriority()).orElse(element.path("cgsincident.priority").asText("")));
                    ticket.setActImpactClassification(Optional.ofNullable(ticket.getActImpactClassification()).orElse(element.path("cgsincident.actual_impact_classification").asText("")));
                    ticket.setClassification(Optional.ofNullable(ticket.getClassification()).orElse(element.path("cgsincident.classification").asText("")));
                    ticket.setImpactedLob(Optional.ofNullable(ticket.getImpactedLob()).orElse(element.path("cgsincident.impacted_lob").asText("")));
                    ticket.setParentIncident(Optional.ofNullable(ticket.getParentIncident()).orElse(element.path("cgsincident.parent_incident").asText("")));
                    ticket.setCategory(Optional.ofNullable(ticket.getCategory()).orElse(element.path("cgsincident.category").asText("")));
                    ticket.setSubCategory(Optional.ofNullable(ticket.getSubCategory()).orElse(element.path("cgsincident.sub_category").asText("")));
                    ticket.setOwningLobLevel4(Optional.ofNullable(ticket.getOwningLobLevel4()).orElse(element.path("cgsincident.owning_lob_level4").asText("")));
                    ticket.setChangeRequest(Optional.ofNullable(ticket.getChangeRequest()).orElse(element.path("cgsincident.change_request").asText("")));
                    ticket.setExternalVendor(Optional.ofNullable(ticket.getExternalVendor()).orElse(element.path("cgsincident.external_vendor").asText("")));
                    ticket.setCreateBy(Optional.ofNullable(ticket.getCreateBy()).orElse(element.path("cgsincident.opened_by").asText("")));

                    addUnique(ticket.getChangeNumbers(), element.path("cicrt.change_number").asText(""));
                    addUnique(ticket.getChangeRequestTypes(), element.path("cicrt.change_request_type").asText(""));
                    addUnique(ticket.getCiItems(), element.path("cic.ci_item").asText(""));
                    addUnique(ticket.getCiConfigurations(), element.path("cic.ci_configuration").asText(""));
                    addUnique(ticket.getUserImpacts(), element.path("cic.user_impact").asText(""));

                    return ticket;
                })
                .orElse(null);
    }

    private void addUnique(List<String> list, String value) {
        Optional.ofNullable(value)
                .filter(val -> !val.isBlank())
                .filter(val -> !list.contains(val))
                .ifPresent(list::add);
    }
}


//setCommonValues

private void setCommonValues(IncidentTracker incident, PullIncident ticket, String username, String team) {

    incident.setIncidentNumber(ticket.getIncidentNumber());
    incident.setCreateBy(ticket.getCreateBy());
    incident.setCustomerExp(ticket.getCustomerExp());
    incident.setTeam(team);
    incident.setUpdateUser(username);
    incident.setState(ticket.getState());
    incident.setAssignmentGroup(ticket.getAssignmentGroup());
    incident.setAssignedTo(ticket.getAssignedTo());
    incident.setActImpClassification(ticket.getActImpactClassification());
    incident.setClassification(ticket.getClassification());
    incident.setImpact(ticket.getImpact());
    incident.setUrgency(ticket.getUrgency());
    incident.setPriority(ticket.getPriority());
    incident.setImpactedLob(ticket.getImpactedLob());
    incident.setParentIncident(ticket.getParentIncident());
    incident.setCategory(ticket.getCategory());
    incident.setSubcategory(ticket.getSubCategory());
    incident.setOwningLobLevel4(ticket.getOwningLobLevel4());

    // === Caused by Change ===
    incident.setCausedByChange("N");
    incident.setChangeNumber("");

    List<String> types = ticket.getChangeRequestTypes();
    List<String> numbers = ticket.getChangeNumbers();

    for (int i = 0; i < types.size(); i++) {
        String type = types.get(i).trim().toLowerCase();
        if (type.contains("caused by")) {
            String number = (i < numbers.size()) ? numbers.get(i) : "";
            incident.setCausedByChange("Y");
            incident.setChangeNumber(number);
            break;
        }
    }

    // === Caused by Vendor ===
    String vendor = Optional.ofNullable(ticket.getExternalVendor()).orElse("");
    incident.setCausedByVendor(vendor.isBlank() ? "N" : "Y");
    incident.setVendorDetails(vendor);

    // === CIC Fields as multi-line values ===
    incident.setAffectedCiItems(String.join("\n", ticket.getCiItems()));
    incident.setCiConfigurations(String.join("\n", ticket.getCiConfigurations()));
    incident.setUserImpacts(String.join("\n", ticket.getUserImpacts()));
}
