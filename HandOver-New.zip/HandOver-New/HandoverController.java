package com.example.demo.controller;

import com.example.demo.model.HandoverTracker;
import com.example.demo.model.User;
import com.example.demo.service.HandoverService;
import com.example.demo.service.IncidentTrackerService;
import com.example.demo.service.UserService;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import com.example.demo.model.IncidentTracker;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api/handover")
@CrossOrigin(origins = "*")
public class HandoverController {
	
	
	private static final Logger logger = LoggerFactory.getLogger(HandoverController.class);
	
    @Autowired
    private HandoverService handoverService;
    
    @Autowired
    private IncidentTrackerService incidentTrackerService;
    
    @Autowired
    private UserService userService;

    // Fetch handover details    
    
    @GetMapping
    public Map<String, Object> getHandover(Principal principal) {
    	
    	String username = principal.getName();
        User user = userService.getUserByUsername(username);

        String team = user.getTeam();
        String location = user.getLocation();
        LocalDateTime now = LocalDateTime.now(ZoneId.of("America/New_York"));

        // Simulated login for HALT
        //if ("sathyahalt1".equalsIgnoreCase(username)) now = now.withHour(21).withMinute(30);
        //if ("sathyahalt2".equalsIgnoreCase(username)) now = now.withHour(2).withMinute(30);
        //if ("sathyahalt3".equalsIgnoreCase(username)) now = now.withHour(10).withMinute(15);

        // 1. HALT Logic
        if ("HALT".equalsIgnoreCase(team)) {
            LocalDateTime shiftStart;
            LocalDateTime shiftEnd;
            String heading;

            ZoneId zone = ZoneId.of("America/New_York");
            ZonedDateTime nowET = ZonedDateTime.now(zone);
            int hour = nowET.getHour();
            int minute = nowET.getMinute();

            System.out.println("Now ET: " + nowET + " | Hour: " + hour + " | Minute: " + minute + " | Location: " + location);

            if ("IND".equalsIgnoreCase(location)) {
                if ((hour >= 21) || (hour < 6) || (hour == 6 && minute <= 30)) {
                    // India 1st shift: 9PM → 6AM ET (grace until 6:30AM)
                    if (hour < 6 || (hour == 6 && minute <= 30)) {
                        shiftStart = nowET.minusDays(1).withHour(21).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    } else {
                        shiftStart = nowET.withHour(21).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    }
                    shiftEnd = shiftStart.plusHours(9);
                    heading = "Handover from India 1st Shift to India 2nd Shift";

                } else if ((hour >= 6 && hour < 11) || (hour == 11 && minute <= 30)) {
                    // India 2nd shift: 6AM → 11AM ET (grace until 11:30AM)
                    shiftStart = nowET.withHour(6).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    shiftEnd = shiftStart.plusHours(5);
                    heading = "Handover from India 2nd Shift to US Shift";

                } else {
                    // US Shift: 10AM → 9PM ET
                    shiftStart = nowET.withHour(10).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    shiftEnd = nowET.withHour(21).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    heading = "Handover from US Shift to India 1st Shift";
                }

            } else if ("US".equalsIgnoreCase(location)) {
                if ((hour >= 9 && hour < 21) || (hour == 21 && minute < 30)) {
                    shiftStart = nowET.withHour(10).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    shiftEnd = nowET.withHour(21).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    heading = "Handover from US Shift to India 1st Shift";
                } else {
                    shiftStart = nowET.toLocalDateTime();
                    shiftEnd = shiftStart.plusHours(1);
                    heading = "Handover Time Unknown (Outside Shift Range)";
                }
            } else {
                shiftStart = nowET.toLocalDateTime();
                shiftEnd = shiftStart.plusHours(1);
                heading = "Handover Time Unknown (Check Location)";
            }

            return buildHandoverMapHalt(team, shiftStart, shiftEnd, heading);
        }



        // 2. DMC/CCC Logic
        if ("DMC".equalsIgnoreCase(team) || "CCC".equalsIgnoreCase(team)) {
            ZoneId zone = ZoneId.of("America/New_York");
            ZonedDateTime nowET = ZonedDateTime.now(zone);
            int hour = nowET.getHour();
            int minute = nowET.getMinute();

            LocalDateTime shiftStart = null;
            LocalDateTime shiftEnd = null;
            String heading = "";

            // ================ US LOCATION ================
            if ("US".equalsIgnoreCase(location)) {
                if (hour >= 5 && hour < 9) {
                    shiftStart = nowET.withHour(5).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    shiftEnd = nowET.withHour(9).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    heading = "Handover from IND to US Shift";

                } else if (hour == 9 && minute < 30) {
                    shiftStart = nowET.withHour(5).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    shiftEnd = nowET.withHour(9).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    heading = "Handover from IND to US Shift (Grace Period)";

                } else if (hour >= 9 && hour < 19) {
                    shiftStart = nowET.withHour(9).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    shiftEnd = nowET.withHour(19).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    heading = "Handover from US to SG Shift";

                } else if (hour == 19 && minute < 30) {
                    shiftStart = nowET.withHour(9).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    shiftEnd = nowET.withHour(19).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    heading = "Handover from US to SG Shift (Grace Period)";
                }
            }

            // ================ SG LOCATION ================
            else if ("SG".equalsIgnoreCase(location)) {
                if ((hour == 18) || (hour == 19 && minute < 30)) {
                    shiftStart = nowET.withHour(9).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    shiftEnd = nowET.withHour(19).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    heading = "Handover from US to SG Shift";

                } else if ((hour >= 19) || (hour < 5) || (hour == 5 && minute < 30)) {
                    LocalDateTime sgStart = (hour < 5 || (hour == 5 && minute < 30))
                        ? nowET.minusDays(1).withHour(19).withMinute(0).withSecond(0).withNano(0).toLocalDateTime()
                        : nowET.withHour(19).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();

                    shiftStart = sgStart;
                    shiftEnd = sgStart.plusHours(10);  // 7PM → 5AM ET
                    heading = (hour == 5 && minute < 30)
                        ? "Handover from SG to IND Shift (Grace Period)"
                        : "Handover from SG to IND Shift";
                }
            }

            // ================ IND LOCATION ================
            else if ("IND".equalsIgnoreCase(location)) {
                if (hour >= 19 || hour < 5) {
                    LocalDateTime sgStart = (hour < 5)
                        ? nowET.minusDays(1).withHour(19).withMinute(0).withSecond(0).withNano(0).toLocalDateTime()
                        : nowET.withHour(19).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();

                    shiftStart = sgStart;
                    shiftEnd = sgStart.plusHours(10);  // 7PM → 5AM ET
                    heading = "Handover from SG to IND Shift";

                } else if (hour >= 5 && hour < 9) {
                    shiftStart = nowET.withHour(5).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    shiftEnd = nowET.withHour(9).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    heading = "Handover from IND to US Shift";

                } else if (hour == 9 && minute < 30) {
                    shiftStart = nowET.withHour(5).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    shiftEnd = nowET.withHour(9).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    heading = "Handover from IND to US Shift (Grace Period)";
                }
            }

            // ================ Fallback ================
            if (shiftStart != null && shiftEnd != null) {
                return buildHandoverMap(team, shiftStart, shiftEnd, heading);
            }

            // Default fallback
            if ("US".equalsIgnoreCase(location)) {
                shiftStart = nowET.withHour(9).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                shiftEnd = nowET.withHour(19).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                heading = "Handover from US to SG Shift";

            } else if ("SG".equalsIgnoreCase(location)) {
                shiftStart = nowET.withHour(19).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                shiftEnd = shiftStart.plusHours(10);
                heading = "Handover from SG to IND Shift";

            } else if ("IND".equalsIgnoreCase(location)) {
                shiftStart = nowET.withHour(5).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                shiftEnd = nowET.withHour(9).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                heading = "Handover from IND to US Shift";
            }

            return buildHandoverMap(team, shiftStart, shiftEnd, heading);
        }
        
        // OPT Logic
        if ("OPT".equalsIgnoreCase(team)) {
            LocalDateTime shiftStart;
            LocalDateTime shiftEnd;
            String heading;

            ZoneId zone = ZoneId.of("America/New_York");
            ZonedDateTime nowET = ZonedDateTime.now(zone);
            int hour = nowET.getHour();
            int minute = nowET.getMinute();

            if ("IND".equalsIgnoreCase(location)) {
                // India 1st Shift: 8PM – 5AM ET (grace until 5:30AM)
                if ((hour >= 20) || (hour < 5) || (hour == 5 && minute < 30)) {
                    shiftStart = (hour < 5 || (hour == 5 && minute < 30))
                        ? nowET.minusDays(1).withHour(20).withMinute(0).withSecond(0).withNano(0).toLocalDateTime()
                        : nowET.withHour(20).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    shiftEnd = shiftStart.plusHours(9);
                    heading = "Handover from India 1st Shift to India 2nd Shift";

                // India 2nd Shift: 1AM – 10AM ET (grace until 10:30AM)
                } else if ((hour >= 1 && hour < 10) || (hour == 10 && minute < 30)) {
                    shiftStart = nowET.withHour(1).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    shiftEnd = shiftStart.plusHours(9);
                    heading = "Handover from India 2nd Shift to US Shift";

                // US Shift: 9:30AM – 8PM ET
                } else {
                    shiftStart = nowET.withHour(9).withMinute(30).withSecond(0).withNano(0).toLocalDateTime();
                    shiftEnd = nowET.withHour(20).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    heading = "Handover from US Shift to India 1st Shift";
                }
            }

            else if ("US".equalsIgnoreCase(location)) {
                // US Shift: 9:30AM – 8PM ET (grace until 8:30PM)
                if ((hour > 9 || (hour == 9 && minute >= 30)) && (hour < 20 || (hour == 20 && minute < 30))) {
                    shiftStart = nowET.withHour(9).withMinute(30).withSecond(0).withNano(0).toLocalDateTime();
                    shiftEnd = nowET.withHour(20).withMinute(0).withSecond(0).withNano(0).toLocalDateTime();
                    heading = "Handover from US Shift to India 1st Shift";
                } else {
                    shiftStart = nowET.toLocalDateTime();
                    shiftEnd = shiftStart.plusHours(1);
                    heading = "Handover Time Unknown (Outside Shift)";
                }
            }

            else {
                // fallback if location is missing
                shiftStart = nowET.toLocalDateTime();
                shiftEnd = shiftStart.plusHours(1);
                heading = "Handover Time Unknown (Check Location)";
            }

            return buildHandoverMapOPT(team, shiftStart, shiftEnd, heading);
        }


        // 3. Default OPT or Others (Old logic)
        LocalDateTime shiftStart, shiftEnd, prevShiftStart, prevShiftEnd;
        boolean isUS = "US".equalsIgnoreCase(location);
        boolean isSG = "SG".equalsIgnoreCase(location);

        if (isUS) {
            shiftStart = now.withHour(7).withMinute(30);
            shiftEnd = now.withHour(19).withMinute(30);
            if (now.getHour() >= 3 && now.getHour() < 9) {
                prevShiftStart = now.minusDays(1).withHour(19).withMinute(30);
                prevShiftEnd = now.withHour(7).withMinute(30);
            } else {
                prevShiftStart = shiftStart;
                prevShiftEnd = shiftEnd;
            }
        } else {
            if (now.getHour() < 9) {
                shiftStart = now.minusDays(1).withHour(19).withMinute(30);
                shiftEnd = now.withHour(7).withMinute(30);
            } else {
                shiftStart = now.withHour(19).withMinute(30);
                shiftEnd = now.plusDays(1).withHour(7).withMinute(30);
            }
            prevShiftStart = now.withHour(7).withMinute(30);
            prevShiftEnd = now.withHour(19).withMinute(30);
        }

        Optional<HandoverTracker> optionalHandover =
            (isUS && now.getHour() < 9) || (isSG && now.getHour() < 20)
                ? handoverService.getHandoverByShift(team, prevShiftStart, prevShiftEnd)
                : handoverService.getHandoverByShift(team, shiftStart, shiftEnd);

        HandoverTracker handover = optionalHandover.orElseGet(() -> {
            HandoverTracker newHO = new HandoverTracker();
            newHO.setStartDate(shiftStart);
            newHO.setEndDate(shiftEnd);
            newHO.setHoItem("");
            return newHO;
        });

        String heading = handoverService.getHandoverHeading(location);
        return Map.of("heading", heading, "handover", handover);
    	
    }
    
    private Map<String, Object> buildHandoverMap(String team, LocalDateTime shiftStart, LocalDateTime shiftEnd, String heading) {
        final LocalDateTime finalShiftStart = shiftStart;
        final LocalDateTime finalShiftEnd = shiftEnd;

        String hoItem = "";
        if ("DMC".equalsIgnoreCase(team) || "CCC".equalsIgnoreCase(team)) {
            ZoneId zone = ZoneId.of("America/New_York");
            int currentHour = LocalDateTime.now(zone).getHour();

            boolean isIndiaMorningShift = currentHour >= 5 && currentHour < 9;
            boolean isIndia = heading.contains("IND to US");

            if (isIndiaMorningShift && isIndia) {
                // Fetch SG → IND handover first (7PM previous day → 5AM)
                LocalDateTime sgStart = finalShiftStart.minusDays(1).withHour(19).withMinute(0).withSecond(0).withNano(0);
                LocalDateTime sgEnd = sgStart.plusHours(10);

                Optional<HandoverTracker> sgHO = handoverService.getHandoverByShift(team, sgStart, sgEnd);
                if (sgHO.isPresent() && sgHO.get().getHoItem() != null) {
                    hoItem = sgHO.get().getHoItem();  // preload SG notes
                }
            }
        }

        Optional<HandoverTracker> handoverOptional = handoverService.getHandoverByShift(team, finalShiftStart, finalShiftEnd);

        HandoverTracker handover = handoverOptional.orElseGet(() -> {
            // Fallback: fetch latest handover for same team and date if shift HO not found
            LocalDate date = finalShiftStart.toLocalDate();
            Optional<HandoverTracker> fallback = handoverService.getLatestHandoverByTeamAndDate(team, date);
            if (fallback.isPresent()) {
                return fallback.get();  // Return latest HO for the same date
            }

            HandoverTracker newHandover = new HandoverTracker();
            newHandover.setStartDate(finalShiftStart);
            newHandover.setEndDate(finalShiftEnd);
            newHandover.setHoItem("");  // Initially empty
            return newHandover;
        });

        //  Apply merged hoItem only if present
        if (!hoItem.isBlank()) {
            String existing = handover.getHoItem();
            String merged = hoItem + (existing != null && !existing.isBlank() ? "\n" + existing : "");
            handover.setHoItem(merged);
        }

        return Map.of("heading", heading, "handover", handover);
    }
    
    private Map<String, Object> buildHandoverMapHalt(String team, LocalDateTime shiftStart, LocalDateTime shiftEnd, String heading) {
        final LocalDateTime finalShiftStart = shiftStart;
        final LocalDateTime finalShiftEnd = shiftEnd;

        Optional<HandoverTracker> handoverOptional = handoverService.getHandoverByShift(team, finalShiftStart, finalShiftEnd);

        HandoverTracker handover = handoverOptional.orElseGet(() -> {
            HandoverTracker newHandover = new HandoverTracker();
            newHandover.setStartDate(finalShiftStart);
            newHandover.setEndDate(finalShiftEnd);
            newHandover.setHoItem(""); // Initially empty
            return newHandover;
        });

        // Fallback logic: show latest HO for that date even if outside shift time
        if (handoverOptional.isEmpty() || handover.getHoItem() == null || handover.getHoItem().isBlank()) {
            Optional<HandoverTracker> fallbackHO = handoverService.getLatestHandoverByTeamAndDate(team, finalShiftStart.toLocalDate());
            fallbackHO.ifPresent(fb -> {
                if (fb.getHoItem() != null && !fb.getHoItem().isBlank()) {
                    handover.setHoItem(fb.getHoItem());
                }
            });
        }

        return Map.of("heading", heading, "handover", handover);
    }


    
    private Map<String, Object> buildHandoverMapOPT(String team, LocalDateTime shiftStart, LocalDateTime shiftEnd, String heading) {
        final LocalDateTime finalShiftStart = shiftStart;
        final LocalDateTime finalShiftEnd = shiftEnd;

        Optional<HandoverTracker> handoverOptional = handoverService.getHandoverByShift(team, finalShiftStart, finalShiftEnd);

        HandoverTracker handover = handoverOptional.orElseGet(() -> {
            HandoverTracker newHandover = new HandoverTracker();
            newHandover.setStartDate(finalShiftStart);
            newHandover.setEndDate(finalShiftEnd);
            newHandover.setHoItem(""); // Initially empty
            return newHandover;
        });

        // Fallback to latest HO for the day if shift record is not present
        if (handoverOptional.isEmpty() || handover.getHoItem() == null || handover.getHoItem().isBlank()) {
            Optional<HandoverTracker> fallbackHO = handoverService.getLatestHandoverByTeamAndDate(team, finalShiftStart.toLocalDate());
            fallbackHO.ifPresent(fb -> {
                if (fb.getHoItem() != null && !fb.getHoItem().isBlank()) {
                    handover.setHoItem(fb.getHoItem());
                }
            });
        }

        return Map.of("heading", heading, "handover", handover);
    }







     // Save or update handover
    @PostMapping("/save")
    public ResponseEntity<String> saveHandover(
            @RequestParam LocalDateTime startDate,
            @RequestParam LocalDateTime endDate,
            @RequestParam String hoItem,
            Principal principal) {

        String username = principal.getName();
        User user = userService.getUserByUsername(username);

        // Call the saveOrUpdateHandover method
        handoverService.saveOrUpdateHandover(user.getTeam(), startDate, endDate, hoItem, username);

        return ResponseEntity.ok("Handover saved successfully.");
    }
    
    @GetMapping("/retrieve")
    @ResponseBody
    public Map<String, Object> retrieveHandover(
            @RequestParam String team,
            @RequestParam LocalDateTime startDate,
            @RequestParam LocalDateTime endDate) {

        Optional<HandoverTracker> handover = handoverService.getHandoverByTeamAndDates(team, startDate, endDate);
        List<IncidentTracker> flaggedIncidents = handoverService.getFlaggedIncidentsForDateRange(team, startDate, endDate);   
        
        if (handover.isPresent()) {
            System.out.println("Handover Found:");
            System.out.println(" - Start: " + handover.get().getStartDate());
            System.out.println(" - End:   " + handover.get().getEndDate());
            System.out.println(" - Remarks: " + handover.get().getHoItem());
        } else {
            System.out.println("No Handover found for given window.");
        }

        
        System.out.println("Flagged Incidents Count: " + flaggedIncidents.size());
        
        for (IncidentTracker i : flaggedIncidents) {
            System.out.println(" - " + i.getIncidentNumber() +
                " | Team: " + i.getTeam() +
                " | UpdateTime: " + i.getUpdateDatetime());
        }

        Map<String, Object> result = new HashMap<>();
        result.put("handover", handover.orElse(null));
        result.put("flaggedIncidents", flaggedIncidents);  // ✅ this line is new
        return result;
    }
    
    
    
    
}
