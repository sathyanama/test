package com.example.demo.controller;

import com.example.demo.model.HandoverTracker;
import com.example.demo.model.IncidentTracker;
import com.example.demo.model.User;
import com.example.demo.service.HandoverService;
import com.example.demo.service.IncidentTrackerService;
import com.example.demo.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.security.Principal;
import java.time.Clock;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import org.springframework.security.test.context.support.WithMockUser;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.nullValue;




@AutoConfigureMockMvc(addFilters = false)
@WebMvcTest(HandoverController.class)
public class HandoverControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private HandoverService handoverService;
    
    @MockBean
    private IncidentTrackerService incidentTrackerService;

    @MockBean
    private UserService userService;

    @Autowired
    private ObjectMapper objectMapper;
    
    
    @Test
    public void testGetHandoverHeading() throws Exception {
        Principal mockPrincipal = () -> "testuser";

        User dummyUser = new User();
        dummyUser.setTeam("DMC");
        dummyUser.setLocation("SG");

        HandoverTracker dummyTracker = new HandoverTracker();
        dummyTracker.setHoItem(""); // match real returned values
        dummyTracker.setStartDate(LocalDateTime.of(2025, 3, 28, 19, 0));
        dummyTracker.setEndDate(LocalDateTime.of(2025, 3, 29, 11, 0));

        when(userService.getUserByUsername("testuser")).thenReturn(dummyUser);
        when(handoverService.getHandoverByCurrentTime(eq("DMC"), any())).thenReturn(Optional.of(dummyTracker));

        mockMvc.perform(get("/api/handover")
                .param("location", "SG")
                .principal(mockPrincipal))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.heading").value("Handover from SG to IND Shift"));  // ✅ Fix here
    }


    @Test
    public void testGetHandoverHeading_US() throws Exception {
        Principal mockPrincipal = () -> "testuser";

        User dummyUser = new User();
        dummyUser.setTeam("DMC");
        dummyUser.setLocation("US");

        HandoverTracker dummyTracker = new HandoverTracker();
        dummyTracker.setHoItem("");
        dummyTracker.setStartDate(ZonedDateTime.of(
            2025, 3, 28, 5, 0, 0, 0,
            ZoneId.of("America/New_York")
        ).toLocalDateTime());
        dummyTracker.setEndDate(ZonedDateTime.of(
            2025, 3, 28, 9, 0, 0, 0,
            ZoneId.of("America/New_York")
        ).toLocalDateTime());

        when(userService.getUserByUsername("testuser")).thenReturn(dummyUser);
        when(handoverService.getHandoverByCurrentTime(eq("DMC"), any())).thenReturn(Optional.of(dummyTracker));

        mockMvc.perform(get("/api/handover")
                .param("location", "US")
                .principal(mockPrincipal))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.heading").value("Handover from US to SG Shift"));
    }




    @Test
    public void testSaveOrUpdateHandover() throws Exception {
        Principal mockPrincipal = () -> "testuser";

        User mockUser = new User();
        mockUser.setTeam("DMC");
        mockUser.setLocation("SG");

        HandoverTracker tracker = new HandoverTracker();
        tracker.setHoItem("Update");

        when(userService.getUserByUsername("testuser")).thenReturn(mockUser);
        when(handoverService.saveOrUpdateHandover(eq("DMC"), any(), any(), eq("Test Item"), eq("testuser")))
            .thenReturn(tracker);

        mockMvc.perform(post("/api/handover/save")
                .param("team", "DMC")
                .param("startDate", LocalDateTime.now().toString())
                .param("endDate", LocalDateTime.now().plusHours(1).toString())
                .param("hoItem", "Test Item")
                .principal(mockPrincipal))
            .andDo(print())
            .andExpect(status().isOk())
            .andExpect(content().string("Handover saved successfully.")); // ✅ FINAL FIX
    }    

    
    @Test
    public void testRetrieveHandoverByTeamAndDates() throws Exception {
        HandoverTracker tracker = new HandoverTracker();
        tracker.setHoItem("Night Ops");

        when(handoverService.getHandoverByTeamAndDates(anyString(), any(), any()))
            .thenReturn(Optional.of(tracker)); // correct method here!

        mockMvc.perform(get("/api/handover/retrieve")
                .param("team", "DMC")
                .param("startDate", LocalDateTime.now().toString())
                .param("endDate", LocalDateTime.now().plusHours(1).toString()))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.handover.hoItem").value("Night Ops"));
    }
    
    
// new changes in this method on 1-5-2025
    
    @Test
    public void testRetrieveHandoverByShift() throws Exception {
        // Mock handover object
        HandoverTracker tracker = new HandoverTracker();
        tracker.setHoItem("Night Ops");

        // Mock flagged incidents
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INC123456");
        incident.setTeam("DMC");

        when(handoverService.getHandoverByTeamAndDates(anyString(), any(), any()))
            .thenReturn(Optional.of(tracker));

        when(handoverService.getFlaggedIncidentsForDateRange(anyString(), any(), any()))
            .thenReturn(List.of(incident));

        mockMvc.perform(get("/api/handover/retrieve")
                .param("team", "DMC")
                .param("startDate", LocalDateTime.now().toString())
                .param("endDate", LocalDateTime.now().plusHours(1).toString()))
            .andDo(print())
            .andExpect(status().isOk())
            .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.handover.hoItem").value("Night Ops"))
            .andExpect(jsonPath("$.flaggedIncidents").isArray())
            .andExpect(jsonPath("$.flaggedIncidents[0].incidentNumber").value("INC123456"))
            .andExpect(jsonPath("$.flaggedIncidents[0].team").value("DMC"));
    }
    
    
    @Test
    public void testRetrieveHandover_WhenHandoverIsEmpty() throws Exception {
        // Simulate empty handover
        when(handoverService.getHandoverByTeamAndDates(anyString(), any(), any()))
            .thenReturn(Optional.empty());

        // Simulate flagged incidents
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INC999999");
        incident.setTeam("DMC");

        when(handoverService.getFlaggedIncidentsForDateRange(anyString(), any(), any()))
            .thenReturn(List.of(incident));

        mockMvc.perform(get("/api/handover/retrieve")
                .param("team", "DMC")
                .param("startDate", LocalDateTime.now().toString())
                .param("endDate", LocalDateTime.now().plusHours(1).toString())
                .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isOk())
            .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.handover").value((Object) null))  // Correct way to check null in JSON
            .andExpect(jsonPath("$.flaggedIncidents").isArray())
            .andExpect(jsonPath("$.flaggedIncidents[0].incidentNumber").value("INC999999"));
    }

    // newly added on 14 Sep
    
    @Test
    public void testGetHandover_HALTFallbackShift() throws Exception {
        Principal mockPrincipal = () -> "haltuser";
        User user = new User();
        user.setTeam("HALT");
        user.setLocation("IND");

        when(userService.getUserByUsername("haltuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("HALT"), any())).thenReturn(Optional.empty());

        // 🔁 Mock time within 10:30 AM ET – US shift start
        ZonedDateTime fakeNowET = ZonedDateTime.of(
            2025, 10, 3, 10, 30, 0, 0,
            ZoneId.of("America/New_York")
        );

        try (MockedStatic<ZonedDateTime> mocked = mockStatic(ZonedDateTime.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> ZonedDateTime.now(ZoneId.of("America/New_York"))).thenReturn(fakeNowET);

            mockMvc.perform(get("/api/handover")
                    .param("location", "IND")
                    .principal(mockPrincipal))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.heading").value("Handover from India 2nd Shift to US Shift"));
        }
    }


    
    @Test
    public void testGetHandover_DMC_SGShift() throws Exception {
        Principal mockPrincipal = () -> "dmcuser";
        User user = new User();
        user.setTeam("DMC");
        user.setLocation("SG");

        when(userService.getUserByUsername("dmcuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("DMC"), any())).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/handover")
                .param("location", "SG")
                .principal(mockPrincipal))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.heading").value("Handover from SG to IND Shift"));
    }
    
    @Test
    public void testGetHandover_CCC_INDShift() throws Exception {
        Principal mockPrincipal = () -> "cccuser";
        User user = new User();
        user.setTeam("CCC");
        user.setLocation("IND");

        when(userService.getUserByUsername("cccuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("CCC"), any())).thenReturn(Optional.empty());

        // ✅ Simulate 6:00 AM ET = within IND → US Shift
        ZonedDateTime fakeNowET = ZonedDateTime.of(
            2025, 10, 3, 6, 0, 0, 0,
            ZoneId.of("America/New_York")
        );

        try (MockedStatic<ZonedDateTime> mocked = mockStatic(ZonedDateTime.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> ZonedDateTime.now(ZoneId.of("America/New_York"))).thenReturn(fakeNowET);

            mockMvc.perform(get("/api/handover")
                    .param("location", "IND")
                    .principal(mockPrincipal))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.heading").value("Handover from IND to US Shift"));
        }
    }

    
    
    @Test
    public void testGetHandover_OPT_IND2Shift() throws Exception {
        Principal mockPrincipal = () -> "optuser";
        User user = new User();
        user.setTeam("OPT");
        user.setLocation("IND");

        when(userService.getUserByUsername("optuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("OPT"), any()))
            .thenReturn(Optional.empty());

        // ✅ Simulate 8:00 AM ET to fall inside India 2nd shift
        ZonedDateTime fakeNowET = ZonedDateTime.of(
            2025, 10, 3, 8, 0, 0, 0,
            ZoneId.of("America/New_York")
        );

        try (MockedStatic<ZonedDateTime> mocked = mockStatic(ZonedDateTime.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> ZonedDateTime.now(ZoneId.of("America/New_York"))).thenReturn(fakeNowET);

            mockMvc.perform(get("/api/handover")
                    .param("location", "IND")
                    .principal(mockPrincipal))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.heading").value("Handover from India 2nd Shift to US Shift"));
        }
    }


    

    
    @Test
    public void testGetHandover_HALT_US_USToSGShift() throws Exception {
        Principal mockPrincipal = () -> "haltuser";
        User user = new User();
        user.setTeam("HALT");
        user.setLocation("US");

        when(userService.getUserByUsername("haltuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("HALT"), any())).thenReturn(Optional.empty());

        // ✅ Simulate 9:15 PM ET → falls under US shift
        ZonedDateTime fakeNowET = ZonedDateTime.of(
            2025, 10, 3, 21, 15, 0, 0,
            ZoneId.of("America/New_York")
        );

        try (MockedStatic<ZonedDateTime> mocked = mockStatic(ZonedDateTime.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> ZonedDateTime.now(ZoneId.of("America/New_York"))).thenReturn(fakeNowET);

            mockMvc.perform(get("/api/handover")
                    .param("location", "US")
                    .principal(mockPrincipal))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.heading").value("Handover from US Shift to India 1st Shift"));
        }
    }


    
    @Test
    public void testGetHandover_HALT_SG_USToSGShift() throws Exception {
        Principal mockPrincipal = () -> "haltuser";
        User user = new User();
        user.setTeam("HALT");
        user.setLocation("SG");

        when(userService.getUserByUsername("haltuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("HALT"), any())).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/handover")
                .param("location", "SG")
                .principal(mockPrincipal))
            .andExpect(status().isOk())
            // ✅ Match actual fallback from controller
            .andExpect(jsonPath("$.heading").value("Handover Time Unknown (Check Location)"));
    }


    
    @Test
    public void testGetHandover_HALT_SG_SGToINDShift() throws Exception {
        Principal mockPrincipal = () -> "haltuser";
        User user = new User();
        user.setTeam("HALT");
        user.setLocation("SG");

        when(userService.getUserByUsername("haltuser")).thenReturn(user);
        
        when(handoverService.getHandoverByCurrentTime(eq("HALT"), any())).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/handover")
                .param("location", "SG")
                .principal(mockPrincipal))
            .andExpect(status().isOk())
            // ✅ Match actual fallback from controller
            .andExpect(jsonPath("$.heading").value("Handover Time Unknown (Check Location)"));
    }
    
    @Test
    public void testGetHandover_HALT_IND_India1stTo2ndShift() throws Exception {
        Principal mockPrincipal = () -> "haltuser";
        User user = new User();
        user.setTeam("HALT");
        user.setLocation("IND");

        when(userService.getUserByUsername("haltuser")).thenReturn(user);

        // Simulate 2nd shift window
        HandoverTracker tracker = new HandoverTracker();
        tracker.setStartDate(ZonedDateTime.of(2025, 10, 5, 2, 0, 0, 0, ZoneId.of("America/New_York")).toLocalDateTime());
        tracker.setEndDate(ZonedDateTime.of(2025, 10, 5, 11, 0, 0, 0, ZoneId.of("America/New_York")).toLocalDateTime());

        when(handoverService.getHandoverByCurrentTime(eq("HALT"), any()))
                .thenReturn(Optional.of(tracker));

        mockMvc.perform(get("/api/handover")
                .param("location", "IND")
                .principal(mockPrincipal))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.heading").value("Handover from US Shift to India 1st Shift"));
    }



    
    @Test
    public void testGetHandover_HALT_IND_USToIndia1stShift() throws Exception {
        Principal mockPrincipal = () -> "haltuser";
        User user = new User();
        user.setTeam("HALT");
        user.setLocation("IND");

        when(userService.getUserByUsername("haltuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("HALT"), any()))
            .thenReturn(Optional.empty());

        // ✅ Simulate 7:30 AM ET (inside India 2nd Shift window)
        ZonedDateTime fakeNowET = ZonedDateTime.of(
            2025, 10, 3, 7, 30, 0, 0,
            ZoneId.of("America/New_York")
        );

        try (MockedStatic<ZonedDateTime> mocked = mockStatic(ZonedDateTime.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> ZonedDateTime.now(ZoneId.of("America/New_York"))).thenReturn(fakeNowET);

            mockMvc.perform(get("/api/handover")
                    .param("location", "IND")
                    .principal(mockPrincipal))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.heading").value("Handover from India 2nd Shift to US Shift"));
        }
    }



    
    // End
    
    // new HALT added on Oct
    
    @Test
    public void testGetHandover_HALT_IND_India1stTo2ndShift_1() throws Exception {
        Principal mockPrincipal = () -> "haltuser";
        User user = new User();
        user.setTeam("HALT");
        user.setLocation("IND");

        when(userService.getUserByUsername("haltuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("HALT"), any()))
            .thenReturn(Optional.empty());

        // Simulate 5:59AM ET = still within India 1st shift (grace period)
        ZonedDateTime fakeNowET = ZonedDateTime.of(
            2025, 10, 1, 5, 59, 0, 0,
            ZoneId.of("America/New_York")
        );

        try (MockedStatic<ZonedDateTime> mocked = mockStatic(ZonedDateTime.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> ZonedDateTime.now(ZoneId.of("America/New_York"))).thenReturn(fakeNowET);

            mockMvc.perform(get("/api/handover")
                    .param("location", "IND")
                    .principal(mockPrincipal))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.heading").value("Handover from India 1st Shift to India 2nd Shift"));
        }
    }
    
    
    @Test
    public void testGetHandover_HALT_IND_India2ndToUSShift() throws Exception {
        // Setup mock principal and user
        Principal mockPrincipal = () -> "haltuser";
        User user = new User();
        user.setTeam("HALT");
        user.setLocation("IND");

        when(userService.getUserByUsername("haltuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("HALT"), any()))
            .thenReturn(Optional.empty());

        // Simulate 10:30AM ET (India 2nd shift handing over to US)
        ZonedDateTime fakeNowET = ZonedDateTime.of(
            2025, 10, 1, 10, 30, 0, 0,
            ZoneId.of("America/New_York")
        );

        try (MockedStatic<ZonedDateTime> mocked = mockStatic(ZonedDateTime.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> ZonedDateTime.now(ZoneId.of("America/New_York"))).thenReturn(fakeNowET);

            mockMvc.perform(get("/api/handover")
                    .param("location", "IND")
                    .principal(mockPrincipal))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.heading").value("Handover from India 2nd Shift to US Shift"));
        }
    }
    
    @Test
    public void testGetHandover_HALT_IND_USShiftToIndia1st() throws Exception {
        // Setup mock principal and user
        Principal mockPrincipal = () -> "haltuser";
        User user = new User();
        user.setTeam("HALT");
        user.setLocation("IND");

        when(userService.getUserByUsername("haltuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("HALT"), any()))
            .thenReturn(Optional.empty());

        // Simulate 3:00PM ET (US shift handing to India 1st)
        ZonedDateTime fakeNowET = ZonedDateTime.of(
            2025, 10, 1, 15, 0, 0, 0,
            ZoneId.of("America/New_York")
        );

        try (MockedStatic<ZonedDateTime> mocked = mockStatic(ZonedDateTime.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> ZonedDateTime.now(ZoneId.of("America/New_York"))).thenReturn(fakeNowET);

            mockMvc.perform(get("/api/handover")
                    .param("location", "IND")
                    .principal(mockPrincipal))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.heading").value("Handover from US Shift to India 1st Shift"));
        }
    }
    
    @Test
    public void testGetHandover_HALT_IND_USShiftFallback() throws Exception {
        Principal mockPrincipal = () -> "haltuser";
        User user = new User();
        user.setTeam("HALT");
        user.setLocation("IND");

        when(userService.getUserByUsername("haltuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("HALT"), any()))
            .thenReturn(Optional.empty());

        // Simulate 12:00PM ET → After India 2nd shift, fallback to US shift
        ZonedDateTime fakeNowET = ZonedDateTime.of(2025, 10, 1, 12, 0, 0, 0,
            ZoneId.of("America/New_York"));

        try (MockedStatic<ZonedDateTime> mocked = mockStatic(ZonedDateTime.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> ZonedDateTime.now(ZoneId.of("America/New_York"))).thenReturn(fakeNowET);

            mockMvc.perform(get("/api/handover")
                    .param("location", "IND")
                    .principal(mockPrincipal))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.heading").value("Handover from US Shift to India 1st Shift"));
        }
    }
    
    @Test
    public void testGetHandover_HALT_US_UnknownShift() throws Exception {
        Principal mockPrincipal = () -> "haltuser";
        User user = new User();
        user.setTeam("HALT");
        user.setLocation("US");

        when(userService.getUserByUsername("haltuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("HALT"), any()))
            .thenReturn(Optional.empty());

        // Simulate 2:00AM ET — outside US shift range
        ZonedDateTime fakeNowET = ZonedDateTime.of(2025, 10, 1, 2, 0, 0, 0,
            ZoneId.of("America/New_York"));

        try (MockedStatic<ZonedDateTime> mocked = mockStatic(ZonedDateTime.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> ZonedDateTime.now(ZoneId.of("America/New_York"))).thenReturn(fakeNowET);

            mockMvc.perform(get("/api/handover")
                    .param("location", "US")
                    .principal(mockPrincipal))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.heading").value("Handover Time Unknown (Outside Shift Range)"));
        }
    }




    // new HALT added on Oct
    // New DMC Added on OCt
    
    @Test
    public void testGetHandover_DMC_US_Grace_IndiaToUS() throws Exception {
        Principal principal = () -> "dmcuser";
        User user = new User();
        user.setTeam("DMC");
        user.setLocation("US");

        when(userService.getUserByUsername("dmcuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("DMC"), any()))
            .thenReturn(Optional.empty());

        ZonedDateTime fakeNowET = ZonedDateTime.of(2025, 10, 2, 9, 15, 0, 0, ZoneId.of("America/New_York"));

        try (MockedStatic<ZonedDateTime> mocked = mockStatic(ZonedDateTime.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> ZonedDateTime.now(ZoneId.of("America/New_York"))).thenReturn(fakeNowET);

            mockMvc.perform(get("/api/handover")
                    .param("location", "US")
                    .principal(principal))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.heading").value("Handover from IND to US Shift (Grace Period)"));
        }
    }
    
    
    @Test
    public void testGetHandover_DMC_US_IndiaToUSStandard() throws Exception {
        Principal principal = () -> "dmcuser";
        User user = new User();
        user.setTeam("DMC");
        user.setLocation("US");

        when(userService.getUserByUsername("dmcuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("DMC"), any()))
            .thenReturn(Optional.empty());

        ZonedDateTime fakeNowET = ZonedDateTime.of(2025, 10, 2, 14, 0, 0, 0, ZoneId.of("America/New_York"));

        try (MockedStatic<ZonedDateTime> mocked = mockStatic(ZonedDateTime.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> ZonedDateTime.now(ZoneId.of("America/New_York"))).thenReturn(fakeNowET);

            mockMvc.perform(get("/api/handover")
                    .param("location", "US")
                    .principal(principal))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.heading").value("Handover from US to SG Shift"));
        }
    }

    @Test
    public void testGetHandover_DMC_US_US2SG() throws Exception {
        Principal principal = () -> "dmcuser";
        User user = new User();
        user.setTeam("DMC");
        user.setLocation("US");

        when(userService.getUserByUsername("dmcuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("DMC"), any()))
            .thenReturn(Optional.empty());

        // Simulate 7:45PM ET, which is standard (NOT grace) handover from US to SG
        ZonedDateTime fakeNowET = ZonedDateTime.of(2025, 10, 2, 19, 45, 0, 0, ZoneId.of("America/New_York"));

        try (MockedStatic<ZonedDateTime> mocked = mockStatic(ZonedDateTime.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> ZonedDateTime.now(ZoneId.of("America/New_York"))).thenReturn(fakeNowET);

            mockMvc.perform(get("/api/handover")
                    .param("location", "US")
                    .principal(principal))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.heading").value("Handover from US to SG Shift"));
        }
    }

    
    @Test
    public void testGetHandover_DMC_SG_Grace_SGToIND() throws Exception {
        Principal principal = () -> "dmcuser";
        User user = new User();
        user.setTeam("DMC");
        user.setLocation("SG");

        when(userService.getUserByUsername("dmcuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("DMC"), any()))
            .thenReturn(Optional.empty());

        ZonedDateTime fakeNowET = ZonedDateTime.of(2025, 10, 2, 5, 15, 0, 0, ZoneId.of("America/New_York"));

        try (MockedStatic<ZonedDateTime> mocked = mockStatic(ZonedDateTime.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> ZonedDateTime.now(ZoneId.of("America/New_York"))).thenReturn(fakeNowET);

            mockMvc.perform(get("/api/handover")
                    .param("location", "SG")
                    .principal(principal))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.heading").value("Handover from SG to IND Shift (Grace Period)"));
        }
    }

    @Test
    public void testGetHandover_DMC_SG_SGToIND() throws Exception {
        Principal principal = () -> "dmcuser";
        User user = new User();
        user.setTeam("DMC");
        user.setLocation("SG");

        when(userService.getUserByUsername("dmcuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("DMC"), any()))
            .thenReturn(Optional.empty());

        ZonedDateTime fakeNowET = ZonedDateTime.of(2025, 10, 2, 2, 0, 0, 0, ZoneId.of("America/New_York"));

        try (MockedStatic<ZonedDateTime> mocked = mockStatic(ZonedDateTime.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> ZonedDateTime.now(ZoneId.of("America/New_York"))).thenReturn(fakeNowET);

            mockMvc.perform(get("/api/handover")
                    .param("location", "SG")
                    .principal(principal))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.heading").value("Handover from SG to IND Shift"));
        }
    }

    @Test
    public void testGetHandover_DMC_IND_SGtoIND() throws Exception {
        Principal principal = () -> "dmcuser";
        User user = new User();
        user.setTeam("DMC");
        user.setLocation("IND");

        when(userService.getUserByUsername("dmcuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("DMC"), any()))
            .thenReturn(Optional.empty());

        // 8:00PM ET falls into SG → IND shift for IND location
        ZonedDateTime fakeNowET = ZonedDateTime.of(2025, 10, 2, 20, 0, 0, 0, ZoneId.of("America/New_York"));

        try (MockedStatic<ZonedDateTime> mocked = mockStatic(ZonedDateTime.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> ZonedDateTime.now(ZoneId.of("America/New_York"))).thenReturn(fakeNowET);

            mockMvc.perform(get("/api/handover")
                    .param("location", "IND")
                    .principal(principal))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.heading").value("Handover from SG to IND Shift"));
        }
    }
    
    @Test
    public void testGetHandover_DMC_IND_SGtoIND_EarlyMorning() throws Exception {
        Principal principal = () -> "dmcuser";
        User user = new User();
        user.setTeam("DMC");
        user.setLocation("IND");

        when(userService.getUserByUsername("dmcuser")).thenReturn(user);
        when(handoverService.getHandoverByCurrentTime(eq("DMC"), any()))
            .thenReturn(Optional.empty());

        // 3:00AM ET → shiftStart = previous day 7PM
        ZonedDateTime fakeNowET = ZonedDateTime.of(2025, 10, 2, 3, 0, 0, 0, ZoneId.of("America/New_York"));

        try (MockedStatic<ZonedDateTime> mocked = mockStatic(ZonedDateTime.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> ZonedDateTime.now(ZoneId.of("America/New_York"))).thenReturn(fakeNowET);

            mockMvc.perform(get("/api/handover")
                    .param("location", "IND")
                    .principal(principal))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.heading").value("Handover from SG to IND Shift"));
        }
    }    
}

