package com.example.demo.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

import com.example.demo.controller.UserController;
import com.example.demo.model.User;
import com.example.demo.service.LogInfoService;
import com.example.demo.service.ThemeService;
import com.example.demo.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Component
public class CommonUtil {
	
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private ThemeService themeService;
	
	@Autowired
	private LogInfoService logInfoService;
	
	public CommonUtil (LogInfoService logInfoService, UserService userService, ThemeService themeService)
	{
		this.logInfoService = logInfoService;
		this.userService = userService;
		this.themeService = themeService;
	}
	
	 public void addUserDetailsToModel(Model model, String screenId,String returnPage,HttpServletRequest request) {
			
	    	try {
	    		
	    		HttpSession session = request.getSession();
	    		
	    		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	            String username = authentication.getName();
	            
	            if (username == null) {
	                logger.warn("Unauthorized access. Redirecting to login.");                
	            }
	            
	                                        
	            
	            User user = userService.getUserByUsername(username);
	            model.addAttribute("username", username);
	            model.addAttribute("role", user.getRole());
	            model.addAttribute("team", user.getTeam());
	            model.addAttribute("location", user.getLocation());
	            //return "success";
	            
	            String userTeam = user.getTeam();
	            String userLocation = user.getLocation();
	            logInfoService.logActivity(session.getId(), screenId, username,userTeam,userLocation); 
	            
	         // Add attributes to the Session
	            session.setAttribute("username", username);
	            session.setAttribute("role", user.getRole());
	            session.setAttribute("team", user.getTeam());
	            session.setAttribute("location", user.getLocation());
	            
	            
	            String backgroundColor = themeService.getBackgroundColor(username);
	            String textColor = themeService.getTextColor(username);
	            session.setAttribute("backgroundColor", backgroundColor);
	            session.setAttribute("textColor", textColor);
	            
	            
	            
	            System.out.println("addUserDetailsToModel UserName: " + username);
		        //System.out.println("addUserDetailsToModel Http Session Id: " + session);
	            System.out.println("addUserDetailsToModel Http Session Id (Object): " + session.getId());
		        System.out.println("addUserDetailsToModel Session Id: " + request.getSession().getId());        
		        System.out.println("addUserDetailsToModel Team Name: " + user.getTeam());
		        System.out.println("addUserDetailsToModel Location: " + user.getLocation());
		        	        
	    		
	    	}catch (Exception ex)
	    	{
	    		logInfoService.logActivity(request.getSession().getId(), screenId, "unknown", ex.getMessage(), "500");
	            //return "error";
	    	}    	
			
		}

}
