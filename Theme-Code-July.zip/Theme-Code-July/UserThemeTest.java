package com.example.demo.model;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

public class UserThemeTest {

    @Test
    void testUserThemeGettersAndSetters() {
        UserTheme theme = new UserTheme();

        theme.setId(1L);
        theme.setUsername("john");
        theme.setBackgroundColor("#121212");
        theme.setTextColor("#E0E0E0");

        LocalDateTime now = LocalDateTime.of(2025, 7, 6, 12, 30);
        theme.setUpdateDatetime(now);

        assertEquals(1L, theme.getId());
        assertEquals("john", theme.getUsername());
        assertEquals("#121212", theme.getBackgroundColor());
        assertEquals("#E0E0E0", theme.getTextColor());
        assertEquals(now, theme.getUpdateDatetime());
    }
}

