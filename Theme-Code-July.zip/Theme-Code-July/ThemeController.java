package com.example.demo.controller;

import com.example.demo.service.ThemeService;
import com.example.demo.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/theme")
public class ThemeController {

    private final ThemeService themeService;
    private final CommonUtil commonUtil;

    @Autowired
    public ThemeController(ThemeService themeService, CommonUtil commonUtil) {
        this.themeService = themeService;
        this.commonUtil = commonUtil;
    }

    @GetMapping
    public String showThemeForm(@RequestParam(required = false) String message,
                                Model model,
                                HttpServletRequest request) {

        commonUtil.addUserDetailsToModel(model, "THEME_PAGE", "themePreference", request);

        String username = (String) request.getSession().getAttribute("username");

        String backgroundColor = themeService.getBackgroundColor(username);
        String textColor = themeService.getTextColor(username);

        request.getSession().setAttribute("backgroundColor", backgroundColor);
        request.getSession().setAttribute("textColor", textColor);

        model.addAttribute("backgroundColor", backgroundColor);
        model.addAttribute("textColor", textColor);

        if (message != null) {
            model.addAttribute("message", message);
        }

        return "themePreference";
    }
    
    
    @PostMapping("/reset")
    public String resetTheme(HttpServletRequest request) {
        String username = (String) request.getSession().getAttribute("username");

        // Set default theme values
        String defaultBg = "#121212";
        String defaultText = "#E0E0E0";

        themeService.saveCustomTheme(username, defaultBg, defaultText);

        request.getSession().setAttribute("backgroundColor", defaultBg);
        request.getSession().setAttribute("textColor", defaultText);

        return "redirect:/theme?message=Theme reset to default";
    }




    @PostMapping("/save-custom")
    public String saveCustomTheme(@RequestParam String backgroundColor,
                                  @RequestParam String textColor,
                                  HttpServletRequest request,
                                  RedirectAttributes redirectAttributes) {
        String username = (String) request.getSession().getAttribute("username");
        
        System.out.println("Background Color: " + backgroundColor);  //
        System.out.println("Text Color: " + textColor);
        
        
        themeService.saveCustomTheme(username, backgroundColor, textColor);
        request.getSession().setAttribute("backgroundColor", backgroundColor);
        request.getSession().setAttribute("textColor", textColor);
        
        return "redirect:/theme?message=Custom theme saved!";
    }
}
