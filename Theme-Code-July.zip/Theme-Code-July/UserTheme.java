package com.example.demo.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "user_theme")
public class UserTheme {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "username")
    private String username;

	public Long getId() {
		return id;
	}
	
	@Column(name = "background_color")
	private String backgroundColor;

	@Column(name = "text_color")
	private String textColor;

	@Column(name = "update_datetime")
    private LocalDateTime updateDatetime;

	
	public String getUsername() {
		return username;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getBackgroundColor() {
		return backgroundColor;
	}

	public String getTextColor() {
		return textColor;
	}

	public void setBackgroundColor(String backgroundColor) {
		this.backgroundColor = backgroundColor;
	}

	public void setTextColor(String textColor) {
		this.textColor = textColor;
	}
	
	public LocalDateTime getUpdateDatetime() {
	    return updateDatetime;
	}

	public void setUpdateDatetime(LocalDateTime updateDatetime) {
	    this.updateDatetime = updateDatetime;
	}	    
}