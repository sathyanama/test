package com.example.demo.service;

import com.example.demo.model.UserTheme;
import java.time.ZonedDateTime;
import java.time.ZoneId;
import com.example.demo.repository.UserThemeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ThemeService {

    private final UserThemeRepository repository;

    @Autowired
    public ThemeService(UserThemeRepository repository) {
        this.repository = repository;
    }
       
    public void saveCustomTheme(String username, String backgroundColor, String textColor) {
        UserTheme userTheme = repository.findByUsername(username).orElse(new UserTheme());
        userTheme.setUsername(username);
        userTheme.setBackgroundColor(backgroundColor);
        userTheme.setTextColor(textColor);
        
        ZonedDateTime estTime = ZonedDateTime.now(ZoneId.of("America/New_York"));
        userTheme.setUpdateDatetime(estTime.toLocalDateTime());
        
        repository.save(userTheme);
    }

    public String getBackgroundColor(String username) {
        return repository.findByUsername(username).map(UserTheme::getBackgroundColor).orElse("#121212");
    }

    public String getTextColor(String username) {
        return repository.findByUsername(username).map(UserTheme::getTextColor).orElse("#E0E0E0");
    }
}
