package com.example.demo.controller;

import com.example.demo.service.ThemeService;
import com.example.demo.util.CommonUtil;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ThemeController.class)
@AutoConfigureMockMvc(addFilters = false)
public class ThemeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ThemeService themeService;

    @MockBean
    private CommonUtil commonUtil;

    private MockHttpSession getSession() {
        MockHttpSession session = new MockHttpSession();
        session.setAttribute("username", "john");
        session.setAttribute("team", "DMC");
        session.setAttribute("role", "USER");
        session.setAttribute("location", "SG");
        return session;
    }

    @Test
    void testShowThemeForm_withMessage() throws Exception {
        when(themeService.getBackgroundColor("john")).thenReturn("#111111");
        when(themeService.getTextColor("john")).thenReturn("#CCCCCC");

        mockMvc.perform(get("/theme")
                .param("message", "Saved!")
                .session(getSession()))
                .andExpect(status().isOk())
                .andExpect(view().name("themePreference"))
                .andExpect(model().attribute("message", "Saved!"))
                .andExpect(model().attribute("backgroundColor", "#111111"))
                .andExpect(model().attribute("textColor", "#CCCCCC"));
    }
    
    @Test
    void testShowThemeForm_withoutMessage() throws Exception {
        when(themeService.getBackgroundColor("john")).thenReturn("#111111");
        when(themeService.getTextColor("john")).thenReturn("#CCCCCC");

        mockMvc.perform(get("/theme")
                .session(getSession()))
                .andExpect(status().isOk())
                .andExpect(view().name("themePreference"))
                .andExpect(model().attribute("backgroundColor", "#111111"))
                .andExpect(model().attribute("textColor", "#CCCCCC"))
                .andExpect(model().attributeDoesNotExist("message"));
    }


    @Test
    void testSaveCustomTheme() throws Exception {
        mockMvc.perform(post("/theme/save-custom")
                .param("backgroundColor", "#222222")
                .param("textColor", "#BBBBBB")
                .session(getSession()))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/theme?message=Custom theme saved!"));

        verify(themeService).saveCustomTheme("john", "#222222", "#BBBBBB");
    }

    @Test
    void testResetTheme() throws Exception {
        mockMvc.perform(post("/theme/reset")
                .session(getSession()))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/theme?message=Theme reset to default"));

        verify(themeService).saveCustomTheme("john", "#121212", "#E0E0E0");
    }
}

