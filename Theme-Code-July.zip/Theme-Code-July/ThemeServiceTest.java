package com.example.demo.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.Optional;

import com.example.demo.model.UserTheme;
import com.example.demo.repository.UserThemeRepository;
import com.example.demo.service.ThemeService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

@ExtendWith(MockitoExtension.class)
public class ThemeServiceTest {

    @Mock
    private UserThemeRepository userThemeRepository;

    @InjectMocks
    private ThemeService themeService;

    @Test
    void testGetBackgroundColor_found() {
        UserTheme theme = new UserTheme();
        theme.setBackgroundColor("#112233");

        when(userThemeRepository.findByUsername("john")).thenReturn(Optional.of(theme));

        String color = themeService.getBackgroundColor("john");

        assertEquals("#112233", color);
    }

    @Test
    void testGetBackgroundColor_notFound_returnsDefault() {
        when(userThemeRepository.findByUsername("unknown")).thenReturn(Optional.empty());

        String color = themeService.getBackgroundColor("unknown");

        assertEquals("#121212", color);
    }

    @Test
    void testGetTextColor_found() {
        UserTheme theme = new UserTheme();
        theme.setTextColor("#ABCDEF");

        when(userThemeRepository.findByUsername("john")).thenReturn(Optional.of(theme));

        String color = themeService.getTextColor("john");

        assertEquals("#ABCDEF", color);
    }

    @Test
    void testGetTextColor_notFound_returnsDefault() {
        when(userThemeRepository.findByUsername("unknown")).thenReturn(Optional.empty());

        String color = themeService.getTextColor("unknown");

        assertEquals("#E0E0E0", color);
    }

    @Test
    void testSaveCustomTheme_insertOrUpdate() {
        UserTheme existing = new UserTheme();
        existing.setUsername("john");

        when(userThemeRepository.findByUsername("john")).thenReturn(Optional.of(existing));

        themeService.saveCustomTheme("john", "#222222", "#CCCCCC");

        verify(userThemeRepository).save(argThat(theme ->
                theme.getUsername().equals("john") &&
                "#222222".equals(theme.getBackgroundColor()) &&
                "#CCCCCC".equals(theme.getTextColor()) &&
                theme.getUpdateDatetime() != null
        ));
    }
}

