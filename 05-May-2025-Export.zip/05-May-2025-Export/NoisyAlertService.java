package com.example.demo.service;

import com.example.demo.model.NoisyAlert;
import com.example.demo.repository.NoisyAlertRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class NoisyAlertService {

    private static final Logger logger = LoggerFactory.getLogger(NoisyAlertService.class);

    private final NoisyAlertRepository repository;

    public NoisyAlertService(NoisyAlertRepository repository) {
        this.repository = repository;
    }

    public List<NoisyAlert> findByTeam(String team) {
        List<NoisyAlert> list = repository.findByTeam(team);
        logger.info("Found {} noisy alerts for team {}", list.size(), team);
        return list;
    }

    public Optional<NoisyAlert> findById(Long id) {
        Optional<NoisyAlert> alert = repository.findById(id);
        logger.debug("Fetching noisy alert with ID {}: Found={}", id, alert.isPresent());
        return alert;
    }

    public void save(NoisyAlert alert, String username, String team) {
        ZonedDateTime nowEST = ZonedDateTime.now(ZoneId.of("America/New_York"));

        if (alert.getId() != null) {
            // Fetch existing alert to retain its createDatetime
            Optional<NoisyAlert> existingOpt = repository.findById(alert.getId());
            if (existingOpt.isPresent()) {
                NoisyAlert existing = existingOpt.get();
                if (existing.getCreateDatetime() != null) {
                    alert.setCreateDatetime(existing.getCreateDatetime());
                } else {
                    alert.setCreateDatetime(nowEST.toLocalDateTime());  // Fallback if DB value was null
                    logger.warn("Existing alert ID {} has null createDatetime, setting to now", alert.getId());
                }
            } else {
                // fallback if somehow not found
                alert.setCreateDatetime(nowEST.toLocalDateTime());
            }
            logger.info("Updating noisy alert ID {} by user {}", alert.getId(), username);
        } else {
            alert.setCreateDatetime(nowEST.toLocalDateTime());
            logger.info("Creating new noisy alert for team {} by user {}", team, username);
        }

        if (!"Y".equalsIgnoreCase(alert.getBlackout())) {
            alert.setBlackout("N");
        }

        alert.setUpdateUserName(username);
        alert.setTeam(team);
        alert.setUpdateUserDatetime(nowEST.toLocalDateTime());
        logger.debug("Final createDatetime before save: {}", alert.getCreateDatetime());
        repository.save(alert);
    }


    public void delete(Long id) {
        logger.warn("Deleting noisy alert with ID {}", id);
        repository.deleteById(id);
    }       
}