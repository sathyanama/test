package com.example.demo.controller;

import com.example.demo.model.NoisyAlert;
import com.example.demo.service.NoisyAlertService;
import com.example.demo.util.CommonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.http.MediaType;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;



import static org.hamcrest.Matchers.containsString;

@WebMvcTest(NoisyAlertController.class)
@AutoConfigureMockMvc(addFilters = false)
class NoisyAlertControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private NoisyAlertService noisyAlertService;

    @MockBean
    private CommonUtil commonUtil;

    private MockHttpSession session;

    @BeforeEach
    void setup() {
        session = new MockHttpSession();
        session.setAttribute("username", "tester");
        session.setAttribute("team", "DMC");
        session.setAttribute("role", "USER");
    }

    @Test
    void testViewAlerts() throws Exception {
        List<NoisyAlert> alerts = new ArrayList<>();
        when(noisyAlertService.findByTeam("DMC")).thenReturn(alerts);

        mockMvc.perform(get("/noisy/view")
                .param("message", "Success")
                .session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("noisyView"))
                .andExpect(model().attributeExists("records"))
                .andExpect(model().attribute("message", "Success"));
    }

    @Test
    void testCreateAlert() throws Exception {
        mockMvc.perform(get("/noisy/create")
                .session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("noisyForm"))
                .andExpect(model().attributeExists("noisyAlert"));
    }

    @Test
    void testEditAlertFound() throws Exception {
        NoisyAlert alert = new NoisyAlert();
        when(noisyAlertService.findById(1L)).thenReturn(Optional.of(alert));

        mockMvc.perform(get("/noisy/edit/1")
                .session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("noisyForm"))
                .andExpect(model().attributeExists("noisyAlert"));
    }

    @Test
    void testEditAlertNotFound() throws Exception {
        when(noisyAlertService.findById(99L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/noisy/edit/99")
                .session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("noisyForm"))
                .andExpect(model().attributeExists("noisyAlert"));
    }

    @Test
    void testSaveAlert() throws Exception {
        mockMvc.perform(post("/noisy/save")
                .session(session)
                .param("summary", "test summary")
                .param("alertType", "Splunk")
                .param("blackout", "Y"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/noisy/view?message=Noisy Alert saved successfully"));
    }

    @Test
    void testDeleteAlert() throws Exception {
        mockMvc.perform(get("/noisy/delete/10")
                .session(session))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/noisy/view?message=Noisy Alert deleted"));
    }
    
    //new test case
    
    @Test
    void testExportToCsv_shouldReturnCsvFile() throws Exception {
    	NoisyAlert alert = new NoisyAlert();
    	alert.setId(1L);
    	alert.setCreateDatetime(LocalDateTime.now());
    	alert.setAlertType("Splunk");
    	alert.setSummary("Sample summary text");
    	alert.setSealId("SEAL123");
    	alert.setType("Infra");
    	alert.setProduct("App1");
    	alert.setStatus("Open");
    	alert.setRunbookReference("Runbook steps...");
    	alert.setContact("RE");
    	alert.setDmcAssignee("Sathya");
    	alert.setNotes("Root cause investigation ongoing.");
    	alert.setBlackout("Y");
    	alert.setProductJira("JIRA-123");
    	alert.setTargetDate(LocalDate.now());
    	alert.setTeam("DMC");
    	alert.setUpdateUserName("tester");
    	alert.setUpdateUserDatetime(LocalDateTime.now());

        when(noisyAlertService.findByTeam("DMC")).thenReturn(List.of(alert));

        mockMvc.perform(get("/noisy/export").sessionAttr("team", "DMC"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("text/csv"))
                .andExpect(header().string("Content-Disposition", containsString("filename=noisy_alerts.csv")));
    }
    
    @Test
    void testExportToCsv_shouldCleanSpecialCharacters() throws Exception {
        NoisyAlert alert = new NoisyAlert();
        alert.setId(1L);
        alert.setCreateDatetime(LocalDateTime.of(2025, 5, 5, 10, 0));
        alert.setAlertType("Splunk");
        alert.setSummary("Line1,\nLine2"); //  triggers clean()
        alert.setSealId("SEAL123");
        alert.setType("Infra");
        alert.setProduct("App1");
        alert.setStatus("Open");
        alert.setRunbookReference("Steps\nNext");
        alert.setContact("RE");
        alert.setDmcAssignee("Sathya");
        alert.setNotes("Note,with,comma\nand newline");
        alert.setBlackout("Y");
        alert.setProductJira("JIRA-123");
        alert.setTargetDate(LocalDate.of(2025, 5, 6));
        alert.setTeam("DMC");
        alert.setUpdateUserName("tester");
        alert.setUpdateUserDatetime(LocalDateTime.of(2025, 5, 5, 12, 0));

        when(noisyAlertService.findByTeam("DMC")).thenReturn(List.of(alert));

        MvcResult result = mockMvc.perform(get("/noisy/export").sessionAttr("team", "DMC"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("text/csv"))
                .andReturn();

        String csv = result.getResponse().getContentAsString();

        //  Validate clean() was applied
        assertTrue(csv.contains("Line1  Line2"));
        assertFalse(csv.contains("\nLine2"));
        assertFalse(csv.contains(",with,comma"));
    }
    
    @Test
    void testExportToCsv_shouldHandleNullFields() throws Exception {
        NoisyAlert alert = new NoisyAlert();
        alert.setId(2L);
        alert.setCreateDatetime(LocalDateTime.now());
        alert.setAlertType(null); // this triggers `text == null` in clean()
        alert.setSummary(null);
        alert.setNotes(null);
        alert.setTeam("DMC");
        alert.setUpdateUserName("tester");
        alert.setUpdateUserDatetime(LocalDateTime.now());

        when(noisyAlertService.findByTeam("DMC")).thenReturn(List.of(alert));

        mockMvc.perform(get("/noisy/export").sessionAttr("team", "DMC"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("text/csv"));
    }



}