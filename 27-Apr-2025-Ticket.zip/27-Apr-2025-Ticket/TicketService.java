import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

@Service
public class TicketService {

    private static final Logger logger = LoggerFactory.getLogger(TicketService.class);

    private final AdfsProperties adfsProperties;

    public TicketService(AdfsProperties adfsProperties) {
        this.adfsProperties = adfsProperties;
    }

    public List<TicketDetails> getT3IncidentDetails(String incidentNumber) throws InterruptedException {
        RestTemplate restTemplate = new RestTemplate();
        String externalApiUrl = adfsProperties.getExternalT3URL() + incidentNumber;

        ResponseEntity<String> response = restTemplate.getForEntity(externalApiUrl, String.class);
        List<TicketDetails> ticketDetailsList = new ArrayList<>();

        if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
            ObjectMapper objectMapper = new ObjectMapper();
            try {
                JsonNode rootNode = objectMapper.readTree(response.getBody());

                if (rootNode != null && rootNode.isArray() && rootNode.size() > 0) {
                    for (JsonNode element : rootNode) {
                        if (element.isObject()) {
                            TicketDetails ticketDetails = extractTicketDetails(element);
                            ticketDetailsList.add(ticketDetails);
                        } else {
                            logger.info("Element is not a JSON object, skipping.");
                        }
                    }
                } else {
                    logger.info("Root JSON node is empty or not an array.");
                }
            } catch (JsonProcessingException e) {
                logger.error("Error parsing JSON response", e);
            }
        } else {
            logger.error("Error fetching ticket details from external system. Status: {}", response.getStatusCode());
            Thread.sleep(10000);
        }

        return ticketDetailsList;
    }

    private TicketDetails extractTicketDetails(JsonNode element) {
        TicketDetails ticketDetails = new TicketDetails();
        Iterator<Entry<String, JsonNode>> fields = element.fields();

        while (fields.hasNext()) {
            Entry<String, JsonNode> field = fields.next();
            String key = field.getKey().toLowerCase();
            String value = field.getValue().asText();

            switch (key) {
                case "cgsincident.incident_numner":
                    ticketDetails.setIncidentNumber(value);
                    break;
                case "cgsincident.short_description":
                    ticketDetails.setShortDescription(value);
                    break;
                case "cgsincident.state":
                    ticketDetails.setState(value);
                    break;
                case "cgsincident.assignment_group":
                    ticketDetails.setAssignmentGroup(value);
                    break;
                case "cgsincident.assignment_to":
                    ticketDetails.setAssignmentTo(value);
                    break;
                case "cgsincident.opened_time_est":
                    ticketDetails.setOpenedTime(value);
                    break;
                case "cgsincident.closed_time_est":
                    ticketDetails.setClosedTime(value);
                    break;
                case "cgsincident.mi_started_est":
                    ticketDetails.setMiStarted(value);
                    break;
                case "cgsincident.mi_diagonosed_est":
                    ticketDetails.setMiDiagonosed(value);
                    break;
                case "cgsincident.mi_detected_est":
                    ticketDetails.setMiDetected(value);
                    break;
                case "cgsincident.mi_mitigated_est":
                    ticketDetails.setMiMitigated(value);
                    break;
                case "cgsincident.mi_resolved_est":
                    ticketDetails.setMiResolved(value);
                    break;
                case "cgsincident.impact":
                    ticketDetails.setImpact(value);
                    break;
                case "cgsincident.urgency":
                    ticketDetails.setUrgency(value);
                    break;
                case "cgsincident.priority":
                    ticketDetails.setPriority(value);
                    break;
                case "cgsincident.actual_impact_classification":
                    ticketDetails.setActImpactClassification(value);
                    break;
                case "cgsincident.classification":
                    ticketDetails.setClassification(value);
                    break;
                case "cgsincident.impacted_lob":
                    ticketDetails.setImpactedLob(value);
                    break;
                case "cgsincident.parent_incident":
                    ticketDetails.setParentIncident(value);
                    break;
                case "cgsincident.category":
                    ticketDetails.setCategory(value);
                    break;
                case "cgsincident.sub_category":
                    ticketDetails.setSubCategory(value);
                    break;
                case "cgsincident.owning_lob_level4":
                    ticketDetails.setOwningLobLevel4(value);
                    break;
                case "cgsincident.change_request":
                    ticketDetails.setChangeRequest(value);
                    break;
                case "cgsincident.external_vendor":
                    ticketDetails.setExternalVendor(value);
                    break;
                case "cgsincident.opened_by":
                    ticketDetails.setCreateBy(value);
                    break;
                default:
                    logger.debug("Unexpected field: {}", key);
            }
        }

        return ticketDetails;
    }
}
