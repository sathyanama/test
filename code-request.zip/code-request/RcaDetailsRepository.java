package com.example.demo.repository;

import com.example.demo.model.RcaDetails;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RcaDetailsRepository extends JpaRepository<RcaDetails, Long> {
    List<RcaDetails> findByRcaFolder_Id(Long folderId);
    
    Page<RcaDetails> findByRcaFolderId(Long folderId, Pageable pageable);

}
