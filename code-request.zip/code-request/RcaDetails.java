package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class RcaDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String incidentNumber;
    private String priority;
    private String impactedLobs;

    @Lob
    private String incidentDescription;

    @Lob
    private String sharepointDescription;
    
    @Lob
    private String rcaSharepointLink;
    
    private String rcaSharepointFolder;
    private String team;
    private String updateUser;
    private LocalDateTime updateDate;

    @ManyToOne
    @JoinColumn(name = "rca_folder_id")
    private RcaFolder rcaFolder;

	public Long getId() {
		return id;
	}

	public String getIncidentNumber() {
		return incidentNumber;
	}

	public String getPriority() {
		return priority;
	}

	public String getImpactedLobs() {
		return impactedLobs;
	}

	public String getIncidentDescription() {
		return incidentDescription;
	}

	public String getSharepointDescription() {
		return sharepointDescription;
	}

	public String getRcaSharepointLink() {
		return rcaSharepointLink;
	}

	public String getRcaSharepointFolder() {
		return rcaSharepointFolder;
	}

	public String getTeam() {
		return team;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public LocalDateTime getUpdateDate() {
		return updateDate;
	}

	public RcaFolder getRcaFolder() {
		return rcaFolder;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setIncidentNumber(String incidentNumber) {
		this.incidentNumber = incidentNumber;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public void setImpactedLobs(String impactedLobs) {
		this.impactedLobs = impactedLobs;
	}

	public void setIncidentDescription(String incidentDescription) {
		this.incidentDescription = incidentDescription;
	}


	public void setSharepointDescription(String sharepointDescription) {
		this.sharepointDescription = sharepointDescription;
	}

	public void setRcaSharepointLink(String rcaSharepointLink) {
		this.rcaSharepointLink = rcaSharepointLink;
	}

	public void setRcaSharepointFolder(String rcaSharepointFolder) {
		this.rcaSharepointFolder = rcaSharepointFolder;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public void setUpdateDate(LocalDateTime updateDate) {
		this.updateDate = updateDate;
	}

	public void setRcaFolder(RcaFolder rcaFolder) {
		this.rcaFolder = rcaFolder;
	}

    // Getters and Setters
    
}
