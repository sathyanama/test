
package com.example.demo.controller;

import com.example.demo.model.RcaDetails;
import com.example.demo.model.RcaFolder;
import com.example.demo.model.User;
import com.example.demo.service.LogInfoService;
import com.example.demo.service.RcaService;
import com.example.demo.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import java.time.ZoneId;
import java.time.ZonedDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/rca")
public class RcaController {

    @Autowired
    private RcaService rcaService;
    
    @Autowired
    private LogInfoService logInfoService;
    
    @Autowired
    private UserService userService;
    
    private static final Logger logger = LoggerFactory.getLogger(RcaController.class);

    @GetMapping
    public String showFolders(Model model, HttpServletRequest request, @ModelAttribute("message") String message) {
		
		HttpSession session = request.getSession();
	    model.addAttribute("username", session.getAttribute("username"));
	    model.addAttribute("team", session.getAttribute("team"));
	    model.addAttribute("role", session.getAttribute("role"));
	    
	    System.out.println(" ShowFolder username:" + session.getAttribute("username"));
	    System.out.println(" ShowFolder team:" + session.getAttribute("team"));
	    System.out.println(" ShowFolder role:" + session.getAttribute("role"));

	    model.addAttribute("folders", rcaService.getAllFolders());
	    model.addAttribute("message", message);
	    return "rcaFolderList";
    }


    @GetMapping("/view")
    public String viewByFolder(@RequestParam Long folderId,
                               @RequestParam(defaultValue = "0") int page,
                               Model model,
                               HttpServletRequest request) {
        HttpSession session = request.getSession();
        model.addAttribute("username", session.getAttribute("username"));
        model.addAttribute("team", session.getAttribute("team"));
        model.addAttribute("role", session.getAttribute("role"));

        Page<RcaDetails> pagedRecords = rcaService.getDetailsByFolder(folderId, page, 10);

        model.addAttribute("records", pagedRecords.getContent()); // only current page's records
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", pagedRecords.getTotalPages());
        model.addAttribute("folderId", folderId);

        rcaService.getFolderById(folderId).ifPresent(folder ->
            model.addAttribute("folderName", folder.getFolderName())
        );

        return "rcaView";
    }



    @GetMapping("/create")
    public String createForm(@RequestParam Long folderId, Model model, HttpServletRequest request) {
        RcaDetails rca = new RcaDetails();
        RcaFolder folder = new RcaFolder();
        folder.setId(folderId);
        rca.setRcaFolder(folder);

        model.addAttribute("rca", rca);
        model.addAttribute("folders", rcaService.getAllFolders());

        HttpSession session = request.getSession();
        model.addAttribute("username", session.getAttribute("username"));
        model.addAttribute("team", session.getAttribute("team"));
        model.addAttribute("role", session.getAttribute("role"));

        return "rcaForm";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model, HttpServletRequest request) {
        RcaDetails rca = rcaService.getById(id).orElseThrow();
        
        HttpSession session = request.getSession();
        model.addAttribute("username", session.getAttribute("username"));
        model.addAttribute("team", session.getAttribute("team"));
        model.addAttribute("role", session.getAttribute("role"));
        
        model.addAttribute("rca", rca);
        model.addAttribute("folders", rcaService.getAllFolders());
        return "rcaForm";
    }

    @PostMapping("/save")
    public String saveRca(@ModelAttribute RcaDetails rca, HttpServletRequest request, RedirectAttributes redirectAttributes) {
        HttpSession session = request.getSession();
        rca.setTeam((String) session.getAttribute("team"));
        rca.setUpdateUser((String) session.getAttribute("username"));
        
        ZonedDateTime estTime = ZonedDateTime.now(ZoneId.of("America/New_York"));
        rca.setUpdateDate(estTime.toLocalDateTime());

        rcaService.save(rca);
        redirectAttributes.addFlashAttribute("message", "RCA record saved successfully.");

        return "redirect:/rca/view?folderId=" + rca.getRcaFolder().getId();
    }


    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        Long folderId = rcaService.getById(id).map(rca -> rca.getRcaFolder().getId()).orElse(null);

        rcaService.delete(id);
        redirectAttributes.addFlashAttribute("message", "RCA record deleted successfully.");

        if (folderId != null) {
            return "redirect:/rca/view?folderId=" + folderId;
        } else {
            return "redirect:/rca";
        }
    }


    @PostMapping("/create-folder")
    public String createFolder(@RequestParam String folderName, HttpServletRequest request, RedirectAttributes redirectAttributes) {
        String user = (String) request.getSession().getAttribute("username");
        rcaService.createFolder(folderName, user);
        redirectAttributes.addFlashAttribute("message", "Folder created successfully.");
        return "redirect:/rca";
    }
}
