package com.example.demo.repository;

import com.example.demo.model.RcaFolder;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RcaFolderRepository extends JpaRepository<RcaFolder, Long> {
}
