package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class RcaFolder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String folderName;

    private String updateUser;
    private LocalDateTime updateDate;
    
    private LocalDateTime folderCreatedOn;
    private String folderCreatedBy;
    

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getFolderName() { return folderName; }
    public void setFolderName(String folderName) { this.folderName = folderName; }

    public String getUpdateUser() { return updateUser; }
    public void setUpdateUser(String updateUser) { this.updateUser = updateUser; }

    public LocalDateTime getUpdateDate() { return updateDate; }
    public void setUpdateDate(LocalDateTime updateDate) { this.updateDate = updateDate; }
	public LocalDateTime getFolderCreatedOn() {
		return folderCreatedOn;
	}
	public String getFolderCreatedBy() {
		return folderCreatedBy;
	}
	public void setFolderCreatedOn(LocalDateTime folderCreatedOn) {
		this.folderCreatedOn = folderCreatedOn;
	}
	public void setFolderCreatedBy(String folderCreatedBy) {
		this.folderCreatedBy = folderCreatedBy;
	}
    
    
}
