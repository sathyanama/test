package com.example.demo.service;

import com.example.demo.model.RcaDetails;
import com.example.demo.model.RcaFolder;
import com.example.demo.repository.RcaDetailsRepository;
import com.example.demo.repository.RcaFolderRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class RcaService {

    @Autowired
    private RcaDetailsRepository rcaRepo;

    @Autowired
    private RcaFolderRepository folderRepo;

    public List<RcaFolder> getAllFolders() {
        return folderRepo.findAll();
    }

    public List<RcaDetails> getDetailsByFolder(Long folderId) {
        return rcaRepo.findByRcaFolder_Id(folderId);
    }

    public RcaDetails save(RcaDetails rca) {
        rca.setUpdateDate(LocalDateTime.now());
        return rcaRepo.save(rca);
    }

    public void delete(Long id) {
        rcaRepo.deleteById(id);
    }

    public Optional<RcaDetails> getById(Long id) {
        return rcaRepo.findById(id);
    }

    public RcaFolder createFolder(String folderName, String user) {
        RcaFolder folder = new RcaFolder();
        folder.setFolderName(folderName);
        folder.setUpdateUser(user);
        folder.setUpdateDate(LocalDateTime.now());
        return folderRepo.save(folder);
    }
    
    public Optional<RcaFolder> getFolderById(Long folderId) {
        return folderRepo.findById(folderId);
    }
    
    public Page<RcaDetails> getDetailsByFolder(Long folderId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("updateDate").descending());
        return rcaRepo.findByRcaFolderId(folderId, pageable);
    }

}
