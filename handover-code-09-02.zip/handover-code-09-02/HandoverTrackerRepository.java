package com.example.demo.repository;

import com.example.demo.model.HandoverTracker;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.time.LocalDateTime;

public interface HandoverTrackerRepository extends JpaRepository<HandoverTracker, Long> {
    Optional<HandoverTracker> findByTeam(String team);
    
 //  Find handover by team, startDate, and endDate (single-day validation is handled in service)
    Optional<HandoverTracker> findByTeamAndStartDateAndEndDate(String team, LocalDateTime startDate, LocalDateTime endDate);
    
    
    @Query("SELECT h FROM HandoverTracker h WHERE h.team = :team ORDER BY h.startDate DESC LIMIT 1")
    Optional<HandoverTracker> findLatestHandoverByTeam(@Param("team") String team);

    @Query("SELECT h FROM HandoverTracker h WHERE h.team = :team AND h.startDate <= :now AND h.endDate >= :now")
    Optional<HandoverTracker> findHandoverByTeamAndCurrentTime(@Param("team") String team, @Param("now") LocalDateTime now);
    
    /*@Query("SELECT h FROM HandoverTracker h WHERE h.team = :team AND h.startDate = :shiftStart AND h.endDate = :shiftEnd")
    Optional<HandoverTracker> findHandoverByTeamAndShiftTime(@Param("team") String team, 
                                                             @Param("shiftStart") LocalDateTime shiftStart, 
                                                             @Param("shiftEnd") LocalDateTime shiftEnd);*/
   
    
    @Query("SELECT h FROM HandoverTracker h WHERE h.team = :team AND h.startDate = :shiftStart AND h.endDate = :shiftEnd ORDER BY h.updateDatetime DESC")
    List<HandoverTracker> findHandoverByTeamAndShiftTime(@Param("team") String team, 
                                                         @Param("shiftStart") LocalDateTime shiftStart, 
                                                         @Param("shiftEnd") LocalDateTime shiftEnd);
}
