package com.example.demo.controller;

import com.example.demo.model.HandoverTracker;
import com.example.demo.model.User;
import com.example.demo.service.HandoverService;
import com.example.demo.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/handover")
@CrossOrigin(origins = "*")
public class HandoverController {

    @Autowired
    private HandoverService handoverService;
    
    @Autowired
    private UserService userService;

    // Fetch handover details    
    
    @GetMapping
    public Map<String, Object> getHandover(Principal principal) {
        String username = principal.getName();
        User user = userService.getUserByUsername(username);

        LocalDateTime now = LocalDateTime.now(ZoneId.of("America/New_York"));
        LocalDateTime shiftStart, shiftEnd, prevShiftStart, prevShiftEnd;

        boolean isUSUser = "US".equalsIgnoreCase(user.getLocation());
        boolean isSGUser = "SG".equalsIgnoreCase(user.getLocation());

        if (isUSUser) {
            boolean isAfter0750AM = now.getHour() >= 7 && now.getMinute() >= 50;

            // ✅ US Shift: 07:30 AM - 19:30 PM (Same Day)
            shiftStart = now.withHour(7).withMinute(30).withSecond(0).withNano(0);
            shiftEnd = now.withHour(19).withMinute(30).withSecond(0).withNano(0);
            if (isAfter0750AM) {
                shiftStart = shiftStart.plusDays(1);
                shiftEnd = shiftEnd.plusDays(1);
            }

            // ✅ Previous Shift: SG Shift (19:30 PM - 07:30 AM)
            prevShiftStart = shiftStart.minusDays(1).withHour(19).withMinute(30).withSecond(0).withNano(0);
            prevShiftEnd = prevShiftStart.plusHours(12);
        } else { // SG User
            boolean isAfter1950PM = now.getHour() >= 19 && now.getMinute() >= 50;

            // ✅ SG Shift: 19:30 PM - 07:30 AM (Next Day)
            shiftStart = now.withHour(19).withMinute(30).withSecond(0).withNano(0);
            shiftEnd = now.plusDays(1).withHour(7).withMinute(30).withSecond(0).withNano(0);
            if (isAfter1950PM) {
                shiftStart = shiftStart.plusDays(1);
                shiftEnd = shiftEnd.plusDays(1);
            }

            // ✅ Previous Shift: US Shift (07:30 AM - 19:30 PM, Same Day)
            prevShiftStart = shiftStart.withHour(7).withMinute(30).withSecond(0).withNano(0);
            prevShiftEnd = prevShiftStart.plusHours(12);
        }

        // ✅ NEW CONDITION: Only allow previous shift retrieval within the correct time window
        boolean shouldCheckPreviousShift = (isUSUser && now.getHour() >= 7 && now.getHour() < 8) ||
                                           (isSGUser && now.getHour() >= 19 && now.getHour() < 20);

        // ✅ Convert to final variables before passing to lambda
        final LocalDateTime finalShiftStart = shiftStart;
        final LocalDateTime finalShiftEnd = shiftEnd;

        System.out.println("🔍 Checking Handover for Team: " + user.getTeam());
        System.out.println("🔍 Current Shift Start: " + finalShiftStart);
        System.out.println("🔍 Current Shift End: " + finalShiftEnd);
        
        if (shouldCheckPreviousShift) {
            System.out.println("🔍 Previous Shift Start: " + prevShiftStart);
            System.out.println("🔍 Previous Shift End: " + prevShiftEnd);
        } else {
            System.out.println("🚫 Skipping previous shift check after cutoff time.");
        }

        // ✅ Fetch handover for the current shift
        Optional<HandoverTracker> handoverOptional = handoverService.getHandoverByShift(user.getTeam(), finalShiftStart, finalShiftEnd);

        // ✅ Fetch previous shift only if within the allowed time window
        if (handoverOptional.isEmpty() && shouldCheckPreviousShift) {
            System.out.println("❌ No handover found for current shift. Checking previous shift...");
            handoverOptional = handoverService.getHandoverByShift(user.getTeam(), prevShiftStart, prevShiftEnd);
        }

        // ✅ FIXED: Using `finalShiftStart` and `finalShiftEnd`
        HandoverTracker handover = handoverOptional.orElseGet(() -> {
            HandoverTracker newHandover = new HandoverTracker();
            newHandover.setStartDate(finalShiftStart);
            newHandover.setEndDate(finalShiftEnd);
            newHandover.setHoItem(""); // Empty remarks since no handover exists
            return newHandover;
        });

        String heading = handoverService.getHandoverHeading(user.getLocation());

        return Map.of(
                "heading", heading,
                "handover", handover
        );
    }



    // Save or update handover
    @PostMapping("/save")
    public ResponseEntity<String> saveHandover(
            @RequestParam LocalDateTime startDate,
            @RequestParam LocalDateTime endDate,
            @RequestParam String hoItem,
            Principal principal) {

        String username = principal.getName();
        User user = userService.getUserByUsername(username);

        // Call the saveOrUpdateHandover method
        handoverService.saveOrUpdateHandover(user.getTeam(), startDate, endDate, hoItem, username);

        return ResponseEntity.ok("Handover saved successfully.");
    }
    
    @GetMapping("/retrieve")
    public Map<String, Object> retrieveHandover(
            @RequestParam String team,
            @RequestParam LocalDateTime startDate,
            @RequestParam LocalDateTime endDate) {

        Optional<HandoverTracker> handover = handoverService.getHandoverByTeamAndDates(team, startDate, endDate);

        // Handle empty response by returning null safely
        if (handover.isEmpty()) {
            return Collections.emptyMap(); // Prevents NullPointerException
        }

        return Map.of("handover", handover.get());
    }
}
