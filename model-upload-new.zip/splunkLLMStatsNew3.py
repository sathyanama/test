import time
import re
import openai
import os

openai.api_key = "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"  # or replace with actual key for testing

# Dummy context and prompts for demonstration (replace with your actual logic)
context = {'time_range': '15m'}

def openai_generate(prompt, max_tokens=512):
    print("Calling OpenAI GPT-4...")
    start_time = time.time()
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a Splunk expert. Only return the generated Splunk query."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=max_tokens,
        temperature=0.2,
    )
    duration = time.time() - start_time
    print(f"OpenAI Response received in {duration:.2f} seconds.")
    return response['choices'][0]['message']['content'].strip()

def is_time_update(text):
    return "last" in text.lower() and any(unit in text.lower() for unit in ["min", "hour", "hr", "h", "m"])

def extract_time_range(text):
    match = re.search(r'last\s+(\d+)\s*(m|min|mins|minute|minutes|h|hr|hrs|hour|hours)', text.lower())
    if match:
        val, unit = match.groups()
        return f"{val}{'h' if 'h' in unit else 'm'}"
    return "15m"

def generate_query_prompt(user_input, query_type):
    
        query_1_prompt = f'''
        You are a Splunk expert.

        From the user input, extract the relevant keyword or phrase (e.g., "/app/data", "payment", etc.). Identify if the user is asking about success (httpCode=200 or 302) or failure (4xx or 5xx).

        Now construct a Splunk query using the following rules:
        - index=abc_digital_19022
        - sourcetype=*httpd*
        - urlPath should use wildcard: urlPath="*<extracted>*"
        - Add: earliest=-{context['time_range']} in the main search clause
        - If user asks about:
          - Success: httpCode=200 or httpCode=302
          - 4xx Failure: httpCode >= 400 AND httpCode < 500
          - 5xx Failure: httpCode >= 500
        - Then:
          | eval urlPath=replace(urlPath, "/?!v|1[^/]*\\d[^/]*", "/X")
          | eval urlPath=replace(urlPath, "::[a-zA-Z0-9]*","::*")
          | eval urlPath=replace(urlPath, "\\/\\d+","/*")
          | stats count as Volume,
                  count(eval(httpCode<=299)) as "Success",
                  count(eval(httpCode=302)) as "302",
                  count(eval(httpCode=304)) as "304",
                  count(eval(httpCode>=400 AND httpCode<500)) as "4XX",
                  count(eval(httpCode>=500)) as "5XX",
                  count(eval(httpCode=400)) as "400",
                  count(eval(httpCode=401)) as "401",
                  count(eval(httpCode=403)) as "403",
                  count(eval(httpCode=404)) as "404",
                  count(eval(httpCode=409)) as "409",
                  count(eval(httpCode=412)) as "412",
                  count(eval(httpCode=500)) as "500",
                  count(eval(httpCode=502)) as "502",
                  count(eval(httpCode=503)) as "503",
                  count(eval(httpCode=504)) as "504",
                  count(eval(httpCode=512)) as "512",
                  count(eval(httpCode>=400)) as Fail,
                  avg(responseTimeMs) as avgResponseTime,
                  perc50(responseTimeMs) as Percentile50,
                  perc95(responseTimeMs) as Percentile95,
                  perc99(responseTimeMs) as Percentile99
                  by urlPath podId
          | eval FP=round(Fail*100/Volume, 2)
          | eval AR=round(avgResponseTime, 0)
          | eval P50=round(Percentile50, 0)
          | eval P95=round(Percentile95, 0)
          | eval P99=round(Percentile99, 0)
          | fields podId* urlPath* Volume* Success* Fail* FP* AR* P95* 4* 5*

        Return only the query and nothing else.
        ### User Input: {user_input}
        ### Splunk Query:
        '''

        query_2_prompt = f'''
        You are a Splunk expert.

        From the user input, extract the relevant keyword or phrase (e.g., "payment", "login", etc.). Identify if the user is asking about success (httpCode=200 or 302) or failure (4xx or 5xx).

        Construct a Splunk query using these rules:
        - index=abc_digital_19022
        - sourcetype=*svc*_st
        - requestUrl="*<extracted>*"
        - loglevel=ERROR and status
        - Add: earliest=-{context['time_range']}
        - If user asks about:
            - Success: httpCode=200 or httpCode=302
            - 4xx Failure: httpCode >= 400 AND httpCode < 500
            - 5xx Failure: httpCode >= 500
        - Then:
          | eval message=substr(message, 1, 210)
          | stats count by message

        Return only the query and nothing else.
        ### User Input: {user_input}
        ### Splunk Query:
        '''

        query_3_prompt = f'''
        You are a Splunk expert.

        Extract the URL keyword and whether it's a success or failure-based query.

        Then build a Splunk query:
        - index=abc_digital_19022
        - sourcetype=*httpd*
        - Use wildcard match on urlPath: *<extracted>*
        - Add: earliest=-{context['time_range']}
        - If user asks about:
            - Success: httpCode=200 or httpCode=302
            - 4xx Failure: httpCode >= 400 AND httpCode < 500
            - 5xx Failure: httpCode >= 500        
        - Then:
          | timechart count by httpCode

        Return only the query and nothing else.
        ### User Input: {user_input}
        ### Splunk Query:
        '''

        query_4_prompt = f'''
        You are a Splunk expert.

        From the user input, extract channelId and determine if the query is about failures.

        Build the query:
        - index=abc_digital_19022
        - sourcetype=*httpd*
        - Use wildcard match on urlPath: *<extracted>*
        - Add: earliest=-{context['time_range']}
        - If user asks about:
            - Success: httpCode=200 or httpCode=302
            - 4xx Failure: httpCode >= 400 AND httpCode < 500
            - 5xx Failure: httpCode >= 500        
        - Then:
          | stats count by channelId, httpCode

        Return only the query and nothing else.
        ### User Input: {user_input}
        ### Splunk Query:
        '''

        query_5_prompt = f'''
        You are a Splunk expert.

        Extract Env keyword and determine if the query is about success/failure.

        Build the query:
        - index=abc_digital_19022
        - sourcetype=*svc*_st
        - Match extracted Env as wildcard
        - Add: earliest=-{context['time_range']}
        - If user asks about:
            - Success: httpCode=200 or httpCode=302
            - 4xx Failure: httpCode >= 400 AND httpCode < 500
            - 5xx Failure: httpCode >= 500        
        - Then:
          | stats count by Env, httpCode

        Return only the query and nothing else.
        ### User Input: {user_input}
        ### Splunk Query:
        '''

        query_6_prompt = f'''
        You are a Splunk expert.

        Build a query that maps IPs to regions and counts HTTP code results.
        - index=abc_digital_19022
        - sourcetype=*httpd*
        - Add: earliest=-{context['time_range']}
        - If user asks about:
            - Success: httpCode=200 or httpCode=302
            - 4xx Failure: httpCode >= 400 AND httpCode < 500
            - 5xx Failure: httpCode >= 500        
        - Then:
          | lookup IPtoASN CIDR as xForwardfor OUTPUT ASN as ASN, ISP as ISP
          | iplocation allfields=true xForwardfor
          | stats count by Aggregator, ASN, ISP, Region, Country, httpCode

        Return only the query and nothing else.
        ### User Input: {user_input}
        ### Splunk Query:
        '''

        query_7_prompt = f'''
        You are a Splunk expert.

        From the user input, extract the relevant keyword or phrase (e.g., "app data", "payment", etc.). Identify if the user is asking about success or failure.

        Now construct a Splunk query using these rules:
        - index=abc_digital_19022
        - Use wildcard match on the extracted keyword: *<extracted>*
        - Add: message.sc > 499 (or httpCode >= 500 based on failure intent)
        - Add: earliest=-{context['time_range']} in the main search clause
        - If user asks about:
            - Success: httpCode=200 or httpCode=302
            - 4xx Failure: httpCode >= 400 AND httpCode < 500
            - 5xx Failure: httpCode >= 500        
        - Then:
          | stats count by message.seg

        Return only the query and nothing else.
        ### User Input: {user_input}
        ### Splunk Query:
        '''
        
        if query_type == 1:
            return f"""{query_1_prompt.strip()}\n### User Input: {user_input}\n### Splunk Query:"""
        elif query_type == 2:
            return f"""{query_2_prompt.strip()}\n### User Input: {user_input}\n### Splunk Query:"""
        elif query_type == 3:
            return f"""{query_3_prompt.strip()}\n### User Input: {user_input}\n### Splunk Query:"""
        elif query_type == 4:
            return f"""{query_4_prompt.strip()}\n### User Input: {user_input}\n### Splunk Query:"""
        elif query_type == 5:
            return f"""{query_5_prompt.strip()}\n### User Input: {user_input}\n### Splunk Query:"""
        elif query_type == 6:
            return f"""{query_6_prompt.strip()}\n### User Input: {user_input}\n### Splunk Query:"""
        elif query_type == 7:
            return f"""{query_7_prompt.strip()}\n### User Input: {user_input}\n### Splunk Query:"""
        else:
            raise ValueError("Invalid query type. Please use a number between 1 and 7.")


def run_all_queries(user_input):
    prompt = generate_query_prompt(user_input,4)
    response_text = openai_generate(prompt, max_tokens=256).strip()
    print(f"[Query Output]:\n{response_text}")

# MAIN
if __name__ == "__main__":
    while True:
        user_input = input("\nYour request (type 'quit' to exit): ").strip()
        if user_input.lower() == 'quit':
            break
        if is_time_update(user_input):
            context['time_range'] = extract_time_range(user_input)
            print(f"Time range updated to: {context['time_range']}")
            run_all_queries(user_input)
        else:
            run_all_queries(user_input)
