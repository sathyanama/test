package com.example.demo.controller;

import com.example.demo.dto.IncidentTrackerDTO;
import com.example.demo.model.IncidentTracker;
import com.example.demo.model.PullIncident;
import com.example.demo.service.IncidentTrackerService;
import com.example.demo.service.PullIncidentService;
import com.example.demo.model.User;
import com.example.demo.service.LogInfoService;
import com.example.demo.service.UserService;
import com.example.demo.model.ChatIncident;
import com.example.demo.service.ChatIncidentService;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.Principal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.security.crypto.password.PasswordEncoder;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.WebAttributes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class UserController {
	
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;
    
    @Autowired
    private PasswordEncoder passwordEncoder; // Inject the PasswordEncoder bean
    
    @Autowired
    private LogInfoService logInfoService;

    @Autowired
    private IncidentTrackerService incidentTrackerService;
    
    @Autowired
    private PullIncidentService pullIncidentService;
    
    @Autowired
    private ChatIncidentService chatIncidentService;
    
    @GetMapping("/")
    public String rootRedirect(HttpServletRequest request) {
        // Check if the user is already logged in
        
        if (request.getUserPrincipal() != null) {
            return "redirect:/dashboard"; // Redirect logged-in users to the dashboard
        }
        return "redirect:/login"; // Redirect unauthenticated users to the login page
    }

    @GetMapping("/login")
    public String login(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession(false); // Get the session if it exists

        if (session != null) {
            // Check if an authentication exception exists
            AuthenticationException authException = 
                (AuthenticationException) session.getAttribute(WebAttributes.AUTHENTICATION_EXCEPTION);

            if (authException != null) {
                model.addAttribute("errorMessage", authException.getMessage()); // Add custom error message to the model
            }
        }

        return "login"; // Redirect to login.html
    }
    
    

    @GetMapping("/register")
    public String showRegisterPage() {
        return "register"; // Thymeleaf template for the register page
    }
    
    @PostMapping("/register")
    public String register(@RequestParam String uName, 
                           @RequestParam String emailid,                            
                           @RequestParam String username, 
                           @RequestParam String password,
                           @RequestParam String location
                           ) {
        // Debugging log
        System.out.println("Received Registration Data: ");
        System.out.println("Name: " + uName);
        System.out.println("Email ID: " + emailid);        
        System.out.println("Username: " + username);
        System.out.println("Location: " + location);  
        

        // Save user to the database
        userService.registerUser(uName, emailid,  username, password,location);

        return "redirect:/login?success=true";
    }
    
    
    @PostMapping("/registerAdmin")
    public String registerAdmin(@RequestParam String uName, 
                           @RequestParam String emailid, 
                           @RequestParam String team, 
                           @RequestParam String username, 
                           @RequestParam String password, 
                           @RequestParam String role,
                           @RequestParam String location) {
        // Debugging log
        System.out.println("Received Registration Data: ");
        System.out.println("Name: " + uName);
        System.out.println("Email ID: " + emailid);
        System.out.println("Team: " + team);
        System.out.println("Username: " + username);        
        System.out.println("Role: " + role);
        System.out.println("Location: " + location);

        // Save user to the database
        userService.registerUserAdminRole(uName, emailid, team, username, password, role,location);

        return "redirect:/login?success=true";
    }
    
    @GetMapping("/forgot-password")
    public String showForgotPasswordPage() {
        return "forgot"; // Thymeleaf will render the forgot.html template
    }
    
    @PostMapping("/forgot-password")
    public String forgotPassword(@RequestParam String username, @RequestParam String password) {
        // Check if the user exists
        Optional<User> userOptional = userService.findByUsername(username);

        if (userOptional.isPresent()) {
            // User exists, update the password
            User user = userOptional.get();
            user.setPassword(passwordEncoder.encode(password)); // Hash the password
            userService.updateUser(user); // Update the user in the database
            return "redirect:/login?successReset=true"; // Redirect to login with success message
        } else {
            // User not found
            return "redirect:/forgot-password?error=true"; // Redirect to forgot page with error message
        }
    }
    
    @GetMapping("/dashboard")
    public String dashboard(Model model, HttpServletRequest request) {
    	
    	System.out.println("Working Directory = " + System.getProperty("user.dir"));
    	
    	addUserDetailsToModel(model,"Dashboard","dashboard",request);
    	
    	 // Retrieve the team from the session or request
        String team = (String) request.getSession().getAttribute("team");
        System.out.println("Dashboard Team:" + team);
        if (team == null) {
            team = "default-team"; // Provide a default value if team is not set
        }
        
        List<IncidentTracker> incidents = incidentTrackerService.findLast20ByTeam(team);

        // Add the incidents to the model
        model.addAttribute("incidents", incidents);
        
    	return "dashboard";
    	
    }
    
        
    @GetMapping("/registerUserSetup")
    public String showApprovalPage(Model model, HttpServletRequest request) {
    	System.out.println("showApprovalPage = " + System.getProperty("user.dir"));
    	
    	List<User> users = userService.getUsersForApproval();
    	
    	model.addAttribute("users", users);
    	
    	System.out.println("Users in showApprovalPage: " + users);
       
    	addUserDetailsToModel(model,"Approval_page","registerApprove",request);    
    	
        return "registerApprove";
    }
    
    
    
    // Approve or delete logic
    @PostMapping("/approveDeleteUsers")
    public String approveOrDeleteUsers(@RequestParam List<Long> selectedIds,
                                       @RequestParam String action,
                                       @RequestParam Map<Long, String> roles,
                                       @RequestParam Map<Long, String> teams,
                                       Principal principal) {
        // Get the currently logged-in username from the Principal
        String loggedInUser = principal.getName();
        
        System.out.println("Selected IDs: " + selectedIds);
        System.out.println("Roles Map: " + roles);
        System.out.println("Teams Map: " + teams);

        if ("approve".equals(action)) {
            userService.approveUsers(selectedIds, roles, teams, loggedInUser);
        } else if ("delete".equals(action)) {
            userService.deleteUsers(selectedIds);
        }
        return "redirect:/registerUserSetup";
    }
    
    // New endpoint to serve incidents dynamically as JSON
    @GetMapping("/api/incidents")
    @ResponseBody
    public List<IncidentTracker> getIncidents(HttpServletRequest request) {
    	
    	System.out.println("Inside /api/incidents dashboard = " + System.getProperty("user.dir"));
    	
    	//addUserDetailsToModel(model,"Dashboard","dashboard",request);
    	
        String team = (String) request.getSession().getAttribute("team");
        if (team == null) {
            team = "default-team"; // Provide a default value if team is not set
        }

        // Return the last 20 incidents as JSON
        return incidentTrackerService.findLast20ByTeam(team);
    }
    
    @GetMapping("/pullRequest")
    public String pullRequestPage(Model model,HttpServletRequest request) {
        addUserDetailsToModel(model,"PULL_REQUEST","pullRequest",request);
        //return "pullRequest";
        return "pullIncident";
    }
    
    @PostMapping("/pull-request")
    public String handlePullRequest(@RequestParam String incidentNumber, Model model, HttpServletRequest request) {
        addUserDetailsToModel(model, "PULL_REQUEST", "pullRequest", request);

                
        try {
        	
        	// Fetch from pull_request table
            Optional<PullIncident> pullRequestOpt = pullIncidentService.getIncidentByNumber(incidentNumber);
            if (pullRequestOpt.isEmpty()) {
                model.addAttribute("errorMessage", "Incident not found in pull_request table.");
                return "pullRequest";
            }
            
            
            PullIncident pullRequest = pullRequestOpt.get();
            
            String team = (String) request.getSession().getAttribute("team");
            String username = (String) request.getSession().getAttribute("username");
            String location = (String) request.getSession().getAttribute("location");
            

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm").withZone(ZoneId.of("America/New_York"));
            
            // Fetch from incident_tracker table
            Optional<IncidentTracker> incidentTrackerOpt = incidentTrackerService.getIncidentByNumberAndTeam(incidentNumber,team);

            // Add pull_request fields to the model
            /*model.addAttribute("incidentNumber", pullRequest.getIncidentNumber());
            model.addAttribute("createBy", pullRequest.getCreateBy());                       
            model.addAttribute("customerExp", pullRequest.getCustomerExp());*/
            
            String formattedCreateDatetime = isNullDateCheck(pullRequest.getCreateDatetime(),formatter);  
            String formattedOpendDatetime = isNullDateCheck(pullRequest.getOpenedTime(),formatter);
            String formattedClosedDatetime = isNullDateCheck(pullRequest.getClosedTime(),formatter);            
            String formattedStartDatetime = isNullDateCheck(pullRequest.getStartDatetime(),formatter);
            String formattedDeductDatetime = isNullDateCheck(pullRequest.getDeductDatetime(),formatter);
            String formattedDiagnoseDatetime = isNullDateCheck(pullRequest.getDiagnoseDatetime(),formatter);
            String formattedMitigateDatetime = isNullDateCheck(pullRequest.getMitigateDatetime(),formatter);
            String formattedResolveDatetime = isNullDateCheck(pullRequest.getResolveDatetime(),formatter);
            
            //String formattedUpdateDatetime = incident.getUpdateDatetime().format(formatter);
            
            model.addAttribute("createDatetime", formattedCreateDatetime);
            model.addAttribute("openedTimeEst", formattedOpendDatetime);
            model.addAttribute("closedTimeEst", formattedClosedDatetime);
            model.addAttribute("startDatetime", formattedStartDatetime);
            model.addAttribute("deductDatetime", formattedDeductDatetime);
            model.addAttribute("diagnoseDatetime", formattedDiagnoseDatetime);
            model.addAttribute("mitigateDatetime", formattedMitigateDatetime);
            model.addAttribute("resolveDatetime", formattedResolveDatetime);
            
            //model.addAttribute("team", team);
            
            // Add incident_tracker fields if available
            if (incidentTrackerOpt.isPresent()) {
            	System.out.println("incidentTrackerOpt.isPresent() Inside if");
            	
                IncidentTracker incidentTracker = incidentTrackerOpt.get();
               
                String formattedMcEngageDatetime = isNullDateCheck(incidentTracker.getMcEngageDatetime(),formatter);
                String formattedUpdateDatetime = incidentTracker.getUpdateDatetime().format(formatter);
                
               
                model.addAttribute("mcEngageDatetime", formattedMcEngageDatetime);
                
                /*model.addAttribute("analysis", incidentTracker.getAnalysis());
                model.addAttribute("impactCount", incidentTracker.getImpactCount());
                model.addAttribute("flow", incidentTracker.getFlow());
                model.addAttribute("alertName", incidentTracker.getAlertName());
                model.addAttribute("flagItem", incidentTracker.getFlagItem()); */
                
                model.addAttribute("currentTag", incidentTracker.getTag());                
                System.out.println("currentTag: " + model.getAttribute("currentTag"));
                
                model.addAttribute("updateDatetime", formattedUpdateDatetime);
                model.addAttribute("incident", incidentTracker);
            }
            else {
            	
            	System.out.println("incidentTrackerOpt.isPresent() Inside else ");
            	
            	System.out.println("model incidentNumber: " + model.getAttribute("incidentNumber"));
            	System.out.println("model customerExp: " + model.getAttribute("customerExp"));
            	System.out.println("model team: " + model.getAttribute("team"));
            	
            	//String formattedMcEngageDatetime = isNullDateCheck(incidentTracker.getMcEngageDatetime(),formatter);
            	
            	
            	
            	IncidentTracker incident = new IncidentTracker();
            	incident.setIncidentNumber(pullRequest.getIncidentNumber());
            	incident.setCreateBy(pullRequest.getCreateBy());
            	incident.setCustomerExp(pullRequest.getCustomerExp());
            	incident.setTeam(team);
            	incident.setUpdateUser(username);
            	incident.setState(pullRequest.getState());
            	incident.setAssignmentGroup(pullRequest.getAssignmentGroup());
            	incident.setAssignedTo(pullRequest.getAssignedTo());            	            	
            	incident.setActImpClassification(pullRequest.getActImpactClassification());            	
            	incident.setClassification(pullRequest.getClassification());
            	incident.setImpact(pullRequest.getImpact());
            	incident.setUrgency(pullRequest.getUrgency());
            	incident.setPriority(pullRequest.getPriority());
            	incident.setImpactedLob(pullRequest.getImpactedLob());
            	incident.setParentIncident(pullRequest.getParentIncident());
            	incident.setCategory(pullRequest.getCategory());
            	incident.setSubcategory(pullRequest.getSubCategory());
            	incident.setOwningLobLevel4(pullRequest.getOwningLobLevel4());
            	
            	// needs to pull from SNOW
            	/*incident.setImpactedSeal(pullRequest.getImpactedSeal());
            	incident.setAccountableSeal(pullRequest.getAccountableSeal());
            	incident.setChangeNumber(pullRequest.getChangeNumber());
            	incident.setVendorDetails(pullRequest.getVendorDetails());
            	incident.setCausedByChange(pullRequest.getCausedByChange());
            	incident.setCausedByVendor(pullRequest.getCausedByVendor());*/
            	
            	/*model.addAttribute("impactedSeal", null);
            	model.addAttribute("accountableSeal", null);
            	model.addAttribute("causedByChange", "N");
            	model.addAttribute("changeNumber", null);
            	model.addAttribute("causedByVendor", "N");
            	model.addAttribute("vendorDetails", null);
            	
            	
            	 model.addAttribute("mcEngageDatetime", null);
                 model.addAttribute("analysis", "");
                 model.addAttribute("impactCount", 0);
                 model.addAttribute("flow", "");
                 model.addAttribute("alertName", "");
                 model.addAttribute("flagItem", false);  
                 
                 model.addAttribute("customerImpact",null);
                 model.addAttribute("splunkQueries", null);
                 model.addAttribute("followUpItems", null);
                 model.addAttribute("dashboard", null);
                 model.addAttribute("teamsEngaged",null);
                 model.addAttribute("smtSplitDarkCanaryAtc", null);
                 model.addAttribute("customerUserJourney",'N');
                 model.addAttribute("apptel", null);
                 model.addAttribute("raisedBy", null);
                 model.addAttribute("currentTag", null);*/
                 
                 model.addAttribute("updateDatetime", LocalDateTime.now().format(formatter));


            	model.addAttribute("incident", incident);

            	//PullIncident pullTracker = pullRequestOpt.get();
                //model.addAttribute("incident", pullTracker); 
                
               
                //return "pullRequestCreate"; // Redirect to pullRequestCreate.html
            	return "PullCreateIncident";
            }
            

        	
        } catch (Exception e) {
            model.addAttribute("errorMessage", "Error retrieving incident: " + e.getMessage());
        }
        
        
        //return "pullRequestEdit";
        
        return "PullUpdateIncident";
    }
   
	private String isNullDateCheck(LocalDateTime converDateTime, DateTimeFormatter formatter) {	
		
		return  converDateTime != null
	        	    ? converDateTime.format(formatter)
	        	    : "N/A";  // Use "N/A" or an empty string as a default
		
	}

	@GetMapping("/fileUpload")
    public String fileUploadPage(Model model,HttpServletRequest request) {
        addUserDetailsToModel(model,"File Upload","fileUpload",request);
        return "fileUpload";
    }
	
	
	@PostMapping("/submitPullRequest")
	public String submitPullRequest(@RequestParam String incidentNumber, Model model,HttpServletRequest request) {
		addUserDetailsToModel(model,"Pull Request Result","pullRequestResult",request);        
		model.addAttribute("incidentNumber", incidentNumber);
	    return "pullRequestResult"; // Return a results page
	}

    @GetMapping("/search")
    public String searchPage(Model model, HttpServletRequest request) {
    	
    	addUserDetailsToModel(model,"SEARCH_PAGE","detail",request); 
    	return "search";       
    }
    
    @PostMapping("/landingSearch")
    public String handleLandingSearch(
            @RequestParam("query") String query,
            Model model,
            HttpServletRequest request) {
    	
    	addUserDetailsToModel(model,"LandingSearch","dashboard",request);
    	
        // Get the current team from the session
        HttpSession session = request.getSession();
        String team = (String) session.getAttribute("team");

        // Fetch search results from the service
        List<IncidentTracker> incidents = incidentTrackerService.findIncidentsBySearchCriteria(query, team);

        // Add attributes to the model
        model.addAttribute("incidents", incidents);
        model.addAttribute("team", team);

        return "dashboard"; // Return the dashboard view with search results
    }
    
    @GetMapping("/databaseOperation")
    public String databaseOperationPage(Model model,HttpServletRequest request) {
        addUserDetailsToModel(model,"DB Operation","dataBaseOperation",request);
        return "databaseOperation";
    }
    
    @GetMapping("/perform-logout")
    public String logout(HttpServletRequest request) {
    	 System.out.println("Logging logout for before session: ");
        try {
            HttpSession session = request.getSession(false);
            if (session != null) {
                String sessionId = session.getId();
                String username = SecurityContextHolder.getContext().getAuthentication().getName();

                System.out.println("Logging logout for session: " + sessionId + " and username: " + username);

                // Log logout action
                logInfoService.logActivity(sessionId, "LOGOUT", username);
                session.invalidate();
                // Clear security context
                SecurityContextHolder.clearContext();
            }
            return "redirect:/login?logout=true";
        } catch (Exception ex) {
            logInfoService.logActivity(request.getSession().getId(), "LOGOUT", "unknown", ex.getMessage(), "500");
            return "error";
        }
    }
    
    
    @PostMapping("/uploadFile")
    public String uploadFile(@RequestParam("file") MultipartFile file, Model model,HttpServletRequest request) {
        try {
            // Add user details to the model
            //addUserDetailsToModel(model);
        	
        	addUserDetailsToModel(model,"upload_file","fileUpload",request);

            // Read the file and parse the CSV data
        	 // Read the file and parse the CSV data
            List<IncidentTracker> incidents = new ArrayList<>();
            BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8));

            String line;
            int lineNumber = 0;
            while ((line = br.readLine()) != null) {
                lineNumber++;
                if (lineNumber == 1) continue; // Skip header row

                String[] fields = line.split(",");
                if (fields.length < 17) {
                    throw new IllegalArgumentException("Invalid CSV format. Missing columns.");
                }

                IncidentTracker incident = new IncidentTracker();
                incident.setIncidentNumber(fields[1].trim()); // Always a string
                incident.setCreateBy(fields[2].trim()); // Always a string
                incident.setCreateDatetime(parseDateTime(fields[3])); // Parse date
                incident.setTeam(fields[4].trim()); // Always a string
                incident.setStartDatetime(parseDateTime(fields[5])); // Parse date
                incident.setDeductDatetime(parseDateTime(fields[6])); // Parse date
                incident.setDiagnoseDatetime(parseDateTime(fields[7])); // Parse date
                incident.setMitigateDatetime(parseDateTime(fields[8])); // Parse date
                incident.setResolveDatetime(parseDateTime(fields[9])); // Parse date
                incident.setMcEngageDatetime(parseDateTime(fields[10])); // Parse date
                incident.setCustomerExp(fields[11].trim()); // Always a string
                incident.setAnalysis(fields[12].trim()); // Always a string (optional, could be large text)
                incident.setImpactCount(fields[13].isEmpty() ? null : Integer.parseInt(fields[13].trim())); // Parse integer
                incident.setFlow(fields[14].trim()); // Always a string
                incident.setUpdateUser(fields[15].trim()); // Always a string
                incident.setUpdateDatetime(parseDateTime(fields[16])); // Parse date

                incidents.add(incident);
            }

            // Save all incidents to the database
            incidentTrackerService.saveAll(incidents);

            // Add success message to model
            model.addAttribute("message", "Data got imported successfully");
        } catch (Exception e) {
            // Add failure message to model
            model.addAttribute("message", "Failed to import data: " + e.getMessage());
        }

        return "fileUpload";
    }
    
 // Helper method to parse date
    private LocalDateTime parseDateTime(String dateTimeString) {
        if (dateTimeString == null || dateTimeString.isEmpty()) {
            return null; // Return null for empty fields
        }
        try {
        	 // Define the custom date format for single and double-digit hours
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy H:mm");
            return LocalDateTime.parse(dateTimeString.trim(), formatter);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Invalid date format: " + dateTimeString + ". Expected format: dd/MM/yyyy HH:mm");
        }
    }
    
    
    @GetMapping("/incident/create")
    public String createIncidentPage(Model model, HttpServletRequest request) {
        addUserDetailsToModel(model, "CREATE_INCIDENT", "createIncident", request);
        model.addAttribute("incident", new IncidentTracker());
        return "createIncident"; // Thymeleaf template for creating incidents
    }

    @PostMapping("/incident/create")
    public String createIncident(@ModelAttribute IncidentTracker incident, HttpServletRequest request, Model model, RedirectAttributes redirectAttributes) {
        try {
            String username = SecurityContextHolder.getContext().getAuthentication().getName();
            //incident.setCreateBy(username);
            //incident.setCreateDatetime(LocalDateTime.now()); // Set the current time
            
            logger.info("Received customer experience from form: {}", incident.getCustomerExp());
            logger.info("Received analysis  from form: {}", incident.getAnalysis());
            
            System.out.println("Received incident number: " +incident.getIncidentNumber());
            System.out.println("Received customer experience: " +incident.getCustomerExp());
            System.out.println("Received analysis : " +incident.getAnalysis());
            
            
            incident.setUpdateUser(username);
            incident.setUpdateDatetime(LocalDateTime.now());
            incidentTrackerService.createIncident(incident);
            redirectAttributes.addFlashAttribute("message", "Incident created successfully");            
        } catch (Exception e) {
        	redirectAttributes.addFlashAttribute("errorMessage", "Failed to update incident: " + e.getMessage());
            
        }
        return "redirect:/dashboard";
        
        
    }

    @GetMapping("/incident/edit/{id}/{incidentNumber}")
    public String editIncidentPage(@PathVariable Long id, @PathVariable String incidentNumber, Model model, HttpServletRequest request) {
        addUserDetailsToModel(model, "EDIT_INCIDENT", "editIncident", request);
        
        String team=getTeamDetails(request, "Edit");
        //DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(ZoneId.of("America/New_York"));
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm").withZone(ZoneId.of("America/New_York"));
        
        /*IncidentTracker incident = incidentTrackerService.getIncidentByNumberAndTeam(incidentNumber,team)
                .orElseThrow(() -> new IllegalArgumentException("Invalid Incident Number: " + incidentNumber)); */
        
        IncidentTracker incident = incidentTrackerService.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid Incident ID: " + id));
               
        String formattedCreateDatetime = isNullDateCheck(incident.getCreateDatetime(),formatter);  
        String formattedOpendDatetime = isNullDateCheck(incident.getOpenedTimeEst(),formatter);
        String formattedClosedDatetime = isNullDateCheck(incident.getClosedTimeEst(),formatter);   
        String formattedStartDatetime = isNullDateCheck(incident.getStartDatetime(),formatter);
        String formattedDeductDatetime = isNullDateCheck(incident.getDeductDatetime(),formatter);
        String formattedDiagnoseDatetime = isNullDateCheck(incident.getDiagnoseDatetime(),formatter);
        String formattedMitigateDatetime = isNullDateCheck(incident.getMitigateDatetime(),formatter);
        String formattedResolveDatetime = isNullDateCheck(incident.getResolveDatetime(),formatter);
        String formattedMcEngageDatetime = isNullDateCheck(incident.getMcEngageDatetime(),formatter);
        String formattedUpdateDatetime = incident.getUpdateDatetime().format(formatter);
        
                       
        model.addAttribute("createDatetime", formattedCreateDatetime);
        model.addAttribute("openedTimeEst", formattedOpendDatetime);
        model.addAttribute("closedTimeEst", formattedClosedDatetime);
        model.addAttribute("startDatetime", formattedStartDatetime);
        model.addAttribute("deductDatetime", formattedDeductDatetime);
        model.addAttribute("diagnoseDatetime", formattedDiagnoseDatetime);
        model.addAttribute("mitigateDatetime", formattedMitigateDatetime);
        model.addAttribute("resolveDatetime", formattedResolveDatetime);
        model.addAttribute("mcEngageDatetime", formattedMcEngageDatetime);
        model.addAttribute("updateDatetime", formattedUpdateDatetime);
        model.addAttribute("currentTag", incident.getTag());                
        System.out.println("currentTag: " + model.getAttribute("currentTag"));
        
        model.addAttribute("incident", incident);
        
        //return "editIncident"; // Thymeleaf template for editing incidents
        
        return "UpdateIncidentForm";
    }
    
    
       
    @PostMapping("/incident/edit")
    public String editIncident(@ModelAttribute IncidentTracker incident, HttpServletRequest request, Model model,RedirectAttributes redirectAttributes) {
        try {
        	
            String username = SecurityContextHolder.getContext().getAuthentication().getName();
            incident.setUpdateUser(username);
            incident.setUpdateDatetime(LocalDateTime.now());
            
            logger.info("Received customer experience from form: {}", incident.getCustomerExp());
            logger.info("Received analysis  from form: {}", incident.getAnalysis());
            
            System.out.println("Received customer experience: " +incident.getCustomerExp());
            System.out.println("Received analysis : " +incident.getAnalysis());
            
            
            incidentTrackerService.updateIncident(incident);
            
            redirectAttributes.addFlashAttribute("message", "Incident updated successfully");
            //return "redirect:/dashboard";
        } catch (Exception e) {
        	redirectAttributes.addFlashAttribute("errorMessage", "Failed to update incident: " + e.getMessage());
            //return "editIncident";
        }
        
        return "redirect:/dashboard";
    }
    
       
    private String convertToEST(LocalDateTime dateTime) {
        if (dateTime == null) {
            return null;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(ZoneId.of("America/New_York"));
        return dateTime.atZone(ZoneId.systemDefault()).withZoneSameInstant(ZoneId.of("America/New_York")).format(formatter);
    }
    
    private String formatDateTime(LocalDateTime dateTime, DateTimeFormatter formatter) {
        if (dateTime == null) {
            return ""; // Return an empty string for null dates
        }
        return ZonedDateTime.of(dateTime, ZoneId.systemDefault()) // Convert from system default timezone
                            .withZoneSameInstant(ZoneId.of("America/New_York")) // Convert to EST
                            .format(formatter);
    }
    
    private String getTeamDetails(HttpServletRequest request, String screenId) {
    	
    	// Get team from user 
    	HttpSession session = request.getSession();
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        
        User user = userService.getUserByUsername(username);
        
        System.out.println("User Controller UserName: " + username);
        System.out.println("User Controller Http Session Id: " + session);
        System.out.println("User Controller Session Id: " + request.getSession().getId());        
        System.out.println("User Controller  Team Name: " + user.getTeam());
        	        
        String team = user.getTeam();	                 
        
		return team;
	}

   
    
    @GetMapping("/incident/delete/{incidentNumber}")
    public String deleteIncident(@PathVariable String incidentNumber, Model model, HttpServletRequest request) {
        try {
            incidentTrackerService.deleteIncident(incidentNumber);
            model.addAttribute("message", "Incident deleted successfully");
            return "redirect:/dashboard";
        } catch (Exception e) {
            model.addAttribute("errorMessage", "Failed to delete incident: " + e.getMessage());
            return "search";
        }
    }

    @GetMapping("/chat-service")
    public String chatServicePage(Model model, HttpServletRequest request) {
        // Add user details to the model
        addUserDetailsToModel(model, "CHAT_SERVICE", "chatService", request);
        return "chatService"; // Render the chat service page
    }

    /*@PostMapping("/chat-service")
    public String handleChatServiceSearch(@RequestParam String query, Model model, HttpServletRequest request) {
        // Add user details to the model
        addUserDetailsToModel(model, "CHAT_SERVICE", "chatService", request);

        // Retrieve team details
        String team = getTeamDetails(request, "ChatService");

        // Fetch the top 5 incidents from the service
        List<ChatIncident> incidents = chatIncidentService.searchIncidents(query, team);

        // Add the incidents and user details to the model
       
        model.addAttribute("incidents", incidents);

        return "chatService"; // Re-render the page with the search results
    }*/

    //Hand Over
    @GetMapping("/handover")
    public String getHandoverPage(Model model, HttpServletRequest request) {
    	addUserDetailsToModel(model, "HO_SERVICE", "handover", request);
        return "handover";
    }
    
    //Hand Over
    @GetMapping("/comms-service")
    public String getCommunicationPage(Model model, HttpServletRequest request) {
    	addUserDetailsToModel(model, "COMMS_SERVICE", "handover", request);
        return "grammar_correction";
    }
    
    private void addUserDetailsToModel(Model model, String screenId,String returnPage,HttpServletRequest request) {
		
    	try {
    		
    		HttpSession session = request.getSession();
    		
    		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String username = authentication.getName();
            
            if (username == null) {
                logger.warn("Unauthorized access. Redirecting to login.");                
            }
            
            logInfoService.logActivity(session.getId(), screenId, username);                             
            
            User user = userService.getUserByUsername(username);
            model.addAttribute("username", username);
            model.addAttribute("role", user.getRole());
            model.addAttribute("team", user.getTeam());
            model.addAttribute("location", user.getLocation());
            //return "success";
            
         // Add attributes to the Session
            session.setAttribute("username", username);
            session.setAttribute("role", user.getRole());
            session.setAttribute("team", user.getTeam());
            session.setAttribute("location", user.getLocation());
            
            System.out.println("addUserDetailsToModel UserName: " + username);
	        //System.out.println("addUserDetailsToModel Http Session Id: " + session);
            System.out.println("addUserDetailsToModel Http Session Id (Object): " + session.getId());
	        System.out.println("addUserDetailsToModel Session Id: " + request.getSession().getId());        
	        System.out.println("addUserDetailsToModel Team Name: " + user.getTeam());
	        System.out.println("addUserDetailsToModel Location: " + user.getLocation());
	        	        
    		
    	}catch (Exception ex)
    	{
    		logInfoService.logActivity(request.getSession().getId(), screenId, "unknown", ex.getMessage(), "500");
            //return "error";
    	}    	
		
	}

}
