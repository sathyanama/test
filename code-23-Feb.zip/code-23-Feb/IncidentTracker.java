package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(
    name = "incident_tracker",
    uniqueConstraints = {@UniqueConstraint(columnNames = {"incident_number", "team"})}
)
public class IncidentTracker {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "incident_number", nullable = false)
    private String incidentNumber;

    @Column(name = "create_by", nullable = false)
    private String createBy;

    @Column(name = "create_datetime", nullable = false)
    private LocalDateTime createDatetime;

    @Column(name = "team", nullable = false)
    private String team;

    @Column(name = "start_datetime")
    private LocalDateTime startDatetime;

    @Column(name = "deduct_datetime")
    private LocalDateTime deductDatetime;

    @Column(name = "diagnose_datetime")
    private LocalDateTime diagnoseDatetime;

    @Column(name = "mitigate_datetime")
    private LocalDateTime mitigateDatetime;

    @Column(name = "resolve_datetime")
    private LocalDateTime resolveDatetime;

    @Column(name = "mc_engage_datetime")
    private LocalDateTime mcEngageDatetime;

    @Column(name = "customer_exp", nullable = false, length = 1000)
    private String customerExp;

    @Lob
    @Column(name = "analysis")
    private String analysis;

    @Column(name = "impact_count")
    private Integer impactCount;

    @Column(name = "flow", length = 500)
    private String flow;

    @Column(name = "update_user", nullable = false)
    private String updateUser;

    @Column(name = "update_datetime", nullable = false)
    private LocalDateTime updateDatetime;
    
    @Column(name = "alert_name", length = 500)
    private String alertName;

    @Column(name = "flag_item", nullable = false)
    private Boolean flagItem;

    // New Fields
    @Column(name = "parent_incident", length = 50)
    private String parentIncident;

    @Column(name = "assignment_group", length = 500)
    private String assignmentGroup;

    @Column(name = "assigned_to", length = 500)
    private String assignedTo;

    @Column(name = "opened_time_est")
    private LocalDateTime openedTimeEst;

    @Column(name = "closed_time_est")
    private LocalDateTime closedTimeEst;

    @Lob
    @Column(name = "customer_impact")
    private String customerImpact;

    @Column(name = "smt_split_dark_canary_atc", length = 2000)
    private String smtSplitDarkCanaryAtc;

    @Lob
    @Column(name = "follow_up_items")
    private String followUpItems;

    @Column(name = "teams_engaged", length = 2000)
    private String teamsEngaged;

    @Lob
    @Column(name = "splunk_queries")
    private String splunkQueries;

    @Column(name = "customer_user_journey", length = 1)
    private String customerUserJourney;

    @Lob
    @Column(name = "dashboard")
    private String dashboard;

    @Column(name = "owning_lob_level_4", length = 1000)
    private String owningLobLevel4;

    @Column(name = "category", length = 500)
    private String category;

    @Column(name = "subcategory", length = 500)
    private String subcategory;

    @Column(name = "tag", length = 200)
    private String tag;

    @Column(name = "act_imp_classification", length = 500)
    private String actImpClassification;

    @Column(name = "classification", length = 500)
    private String classification;

    @Column(name = "impact", length = 100)
    private String impact;

    @Column(name = "urgency", length = 100)
    private String urgency;

    @Column(name = "priority", length = 100)
    private String priority;

    @Column(name = "impacted_lob", length = 500)
    private String impactedLob;

    @Column(name = "impacted_seal", length = 500)
    private String impactedSeal;

    @Column(name = "accountable_seal", length = 100)
    private String accountableSeal;

    @Column(name = "apptel", length = 50)
    private String apptel;

    @Column(name = "raised_by", length = 20)
    private String raisedBy;

    @Column(name = "state", length = 20)
    private String state;
       
    
    @Column(name = "change_caused", length = 1)
    private String causedByChange;
    
    @Column(name = "change_number", length = 20)
    private String changeNumber;
    
    @Column(name = "change_vendor", length = 1)
    private String causedByVendor;
    
    @Column(name = "vendor_details", length = 500)
    private String vendorDetails;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getIncidentNumber() {
		return incidentNumber;
	}

	public void setIncidentNumber(String incidentNumber) {
		this.incidentNumber = incidentNumber;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public LocalDateTime getCreateDatetime() {
		return createDatetime;
	}

	public void setCreateDatetime(LocalDateTime createDatetime) {
		this.createDatetime = createDatetime;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public LocalDateTime getStartDatetime() {
		return startDatetime;
	}

	public void setStartDatetime(LocalDateTime startDatetime) {
		this.startDatetime = startDatetime;
	}

	public LocalDateTime getDeductDatetime() {
		return deductDatetime;
	}

	public void setDeductDatetime(LocalDateTime deductDatetime) {
		this.deductDatetime = deductDatetime;
	}

	public LocalDateTime getDiagnoseDatetime() {
		return diagnoseDatetime;
	}

	public void setDiagnoseDatetime(LocalDateTime diagnoseDatetime) {
		this.diagnoseDatetime = diagnoseDatetime;
	}

	public LocalDateTime getMitigateDatetime() {
		return mitigateDatetime;
	}

	public void setMitigateDatetime(LocalDateTime mitigateDatetime) {
		this.mitigateDatetime = mitigateDatetime;
	}

	public LocalDateTime getResolveDatetime() {
		return resolveDatetime;
	}

	public void setResolveDatetime(LocalDateTime resolveDatetime) {
		this.resolveDatetime = resolveDatetime;
	}

	public LocalDateTime getMcEngageDatetime() {
		return mcEngageDatetime;
	}

	public void setMcEngageDatetime(LocalDateTime mcEngageDatetime) {
		this.mcEngageDatetime = mcEngageDatetime;
	}

	public String getCustomerExp() {
		return customerExp;
	}

	public void setCustomerExp(String customerExp) {
		this.customerExp = customerExp;
	}

	public String getAnalysis() {
		return analysis;
	}

	public void setAnalysis(String analysis) {
		this.analysis = analysis;
	}

	public Integer getImpactCount() {
		return impactCount;
	}

	public void setImpactCount(Integer impactCount) {
		this.impactCount = impactCount;
	}

	public String getFlow() {
		return flow;
	}

	public void setFlow(String flow) {
		this.flow = flow;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public LocalDateTime getUpdateDatetime() {
		return updateDatetime;
	}

	public void setUpdateDatetime(LocalDateTime updateDatetime) {
		this.updateDatetime = updateDatetime;
	}

	public String getAlertName() {
		return alertName;
	}

	public void setAlertName(String alertName) {
		this.alertName = alertName;
	}

	public Boolean getFlagItem() {
		return flagItem;
	}

	public void setFlagItem(Boolean flagItem) {
		this.flagItem = flagItem;
	}

	public String getParentIncident() {
		return parentIncident;
	}

	public void setParentIncident(String parentIncident) {
		this.parentIncident = parentIncident;
	}

	public String getAssignmentGroup() {
		return assignmentGroup;
	}

	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}

	public String getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public LocalDateTime getOpenedTimeEst() {
		return openedTimeEst;
	}

	public void setOpenedTimeEst(LocalDateTime openedTimeEst) {
		this.openedTimeEst = openedTimeEst;
	}

	public LocalDateTime getClosedTimeEst() {
		return closedTimeEst;
	}

	public void setClosedTimeEst(LocalDateTime closedTimeEst) {
		this.closedTimeEst = closedTimeEst;
	}

	public String getCustomerImpact() {
		return customerImpact;
	}

	public void setCustomerImpact(String customerImpact) {
		this.customerImpact = customerImpact;
	}

	public String getSmtSplitDarkCanaryAtc() {
		return smtSplitDarkCanaryAtc;
	}

	public void setSmtSplitDarkCanaryAtc(String smtSplitDarkCanaryAtc) {
		this.smtSplitDarkCanaryAtc = smtSplitDarkCanaryAtc;
	}

	public String getFollowUpItems() {
		return followUpItems;
	}

	public void setFollowUpItems(String followUpItems) {
		this.followUpItems = followUpItems;
	}

	public String getTeamsEngaged() {
		return teamsEngaged;
	}

	public void setTeamsEngaged(String teamsEngaged) {
		this.teamsEngaged = teamsEngaged;
	}

	public String getSplunkQueries() {
		return splunkQueries;
	}

	public void setSplunkQueries(String splunkQueries) {
		this.splunkQueries = splunkQueries;
	}

	public String getCustomerUserJourney() {
		return customerUserJourney;
	}

	public void setCustomerUserJourney(String customerUserJourney) {
		this.customerUserJourney = customerUserJourney;
	}

	public String getDashboard() {
		return dashboard;
	}

	public void setDashboard(String dashboard) {
		this.dashboard = dashboard;
	}

	public String getOwningLobLevel4() {
		return owningLobLevel4;
	}

	public void setOwningLobLevel4(String owningLobLevel4) {
		this.owningLobLevel4 = owningLobLevel4;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSubcategory() {
		return subcategory;
	}

	public void setSubcategory(String subcategory) {
		this.subcategory = subcategory;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getActImpClassification() {
		return actImpClassification;
	}

	public void setActImpClassification(String actImpClassification) {
		this.actImpClassification = actImpClassification;
	}

	public String getClassification() {
		return classification;
	}

	public void setClassification(String classification) {
		this.classification = classification;
	}

	public String getImpact() {
		return impact;
	}

	public void setImpact(String impact) {
		this.impact = impact;
	}

	public String getUrgency() {
		return urgency;
	}

	public void setUrgency(String urgency) {
		this.urgency = urgency;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getImpactedLob() {
		return impactedLob;
	}

	public void setImpactedLob(String impactedLob) {
		this.impactedLob = impactedLob;
	}

	public String getImpactedSeal() {
		return impactedSeal;
	}

	public void setImpactedSeal(String impactedSeal) {
		this.impactedSeal = impactedSeal;
	}

	public String getAccountableSeal() {
		return accountableSeal;
	}

	public void setAccountableSeal(String accountableSeal) {
		this.accountableSeal = accountableSeal;
	}

	public String getApptel() {
		return apptel;
	}

	public void setApptel(String apptel) {
		this.apptel = apptel;
	}

	public String getRaisedBy() {
		return raisedBy;
	}

	public void setRaisedBy(String raisedBy) {
		this.raisedBy = raisedBy;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCausedByChange() {
		return causedByChange;
	}

	public String getChangeNumber() {
		return changeNumber;
	}

	public String getCausedByVendor() {
		return causedByVendor;
	}

	public String getVendorDetails() {
		return vendorDetails;
	}

	public void setCausedByChange(String causedByChange) {
		this.causedByChange = causedByChange;
	}

	public void setChangeNumber(String changeNumber) {
		this.changeNumber = changeNumber;
	}

	public void setCausedByVendor(String causedByVendor) {
		this.causedByVendor = causedByVendor;
	}

	public void setVendorDetails(String vendorDetails) {
		this.vendorDetails = vendorDetails;
	}
    
}
