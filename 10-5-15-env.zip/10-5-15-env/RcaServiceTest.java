package com.example.demo.service;

import com.example.demo.model.RcaDetails;
import com.example.demo.model.RcaFolder;
import com.example.demo.repository.RcaDetailsRepository;
import com.example.demo.repository.RcaFolderRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.data.domain.*;

import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RcaServiceTest {

    @InjectMocks
    private RcaService rcaService;

    @Mock
    private RcaDetailsRepository rcaRepo;

    @Mock
    private RcaFolderRepository folderRepo;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllFolders() {
        List<RcaFolder> folders = List.of(new RcaFolder(), new RcaFolder());
        when(folderRepo.findAll()).thenReturn(folders);

        List<RcaFolder> result = rcaService.getAllFolders();

        assertEquals(2, result.size());
        verify(folderRepo).findAll();
    }

    @Test
    void testGetDetailsByFolder() {
        List<RcaDetails> details = List.of(new RcaDetails());
        when(rcaRepo.findByRcaFolder_Id(1L)).thenReturn(details);

        List<RcaDetails> result = rcaService.getDetailsByFolder(1L);

        assertEquals(1, result.size());
        verify(rcaRepo).findByRcaFolder_Id(1L);
    }

    @Test
    void testSave() {
        RcaDetails rca = new RcaDetails();
        when(rcaRepo.save(any())).thenAnswer(invocation -> invocation.getArgument(0));

        RcaDetails result = rcaService.save(rca);

        assertNotNull(result.getUpdateDate());
        verify(rcaRepo).save(rca);
    }

    @Test
    void testDelete() {
        rcaService.delete(5L);
        verify(rcaRepo).deleteById(5L);
    }

    @Test
    void testGetById() {
        RcaDetails rca = new RcaDetails();
        when(rcaRepo.findById(10L)).thenReturn(Optional.of(rca));

        Optional<RcaDetails> result = rcaService.getById(10L);

        assertTrue(result.isPresent());
        verify(rcaRepo).findById(10L);
    }

    @Test
    void testCreateFolder() {
        when(folderRepo.save(any())).thenAnswer(invocation -> invocation.getArgument(0));

        RcaFolder result = rcaService.createFolder("Test Folder", "testuser");

        assertEquals("Test Folder", result.getFolderName());
        assertEquals("testuser", result.getUpdateUser());
        assertNotNull(result.getUpdateDate());
        verify(folderRepo).save(any());
    }

    @Test
    void testGetFolderById() {
        RcaFolder folder = new RcaFolder();
        when(folderRepo.findById(3L)).thenReturn(Optional.of(folder));

        Optional<RcaFolder> result = rcaService.getFolderById(3L);

        assertTrue(result.isPresent());
        verify(folderRepo).findById(3L);
    }

    @Test
    void testGetDetailsByFolderWithPagination() {
        Page<RcaDetails> mockPage = new PageImpl<>(List.of(new RcaDetails(), new RcaDetails()));
        when(rcaRepo.findByRcaFolderId(eq(7L), any(Pageable.class))).thenReturn(mockPage);

        Page<RcaDetails> result = rcaService.getDetailsByFolder(7L, 0, 10);

        assertEquals(2, result.getContent().size());
        verify(rcaRepo).findByRcaFolderId(eq(7L), any(Pageable.class));
    }
}
