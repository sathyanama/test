package com.example.demo.controller;

import com.example.demo.model.IncidentTracker;
import com.example.demo.service.IncidentTrackerService;
import com.example.demo.util.CommonUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

@Controller
public class IncidentUploadController {

    private static final Logger logger = LoggerFactory.getLogger(IncidentUploadController.class);

    private final IncidentTrackerService incidentTrackerService;
    private final CommonUtil commonUtil;

    private final DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("M/d/yyyy HH:mm");
    private static final String UPLOAD_CSV = "UPLOAD_CSV";
    private static final String RETURN_FILE_UPLOAD = "fileUploadIncident";
    private static final String REDIRECT_FILE_UPLOAD = "redirect:/incident/upload";

    @Autowired
    public IncidentUploadController(CommonUtil commonUtil, IncidentTrackerService incidentTrackerService) {
        this.commonUtil = commonUtil;
        this.incidentTrackerService = incidentTrackerService;
    }

    @GetMapping("/incident/upload")
    public String openUploadPage(Model model, HttpServletRequest request) {
        commonUtil.addUserDetailsToModel(model, UPLOAD_CSV, UPLOAD_CSV, request);
        return RETURN_FILE_UPLOAD;
    }

    @PostMapping("/incident/upload")
    public String handleFileUpload(@RequestParam("file") MultipartFile file,
                                   HttpServletRequest request,
                                   RedirectAttributes redirectAttributes) {
        if (file.isEmpty() || !file.getOriginalFilename().endsWith(".csv")) {
            redirectAttributes.addFlashAttribute("errorMessage", "Only CSV files are supported.");
            return REDIRECT_FILE_UPLOAD;
        }

        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");
        String team = (String) session.getAttribute("team");
        ZoneId estZoneId = ZoneId.of("America/New_York");

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()));
             CSVParser parser = CSVFormat.DEFAULT.withFirstRecordAsHeader().parse(reader)) {

            for (CSVRecord record : parser) {
                String incidentNumber = record.get("incident_number").trim();
                logger.info("Processing incident: {}", incidentNumber);

                Optional<IncidentTracker> optional = incidentTrackerService.getIncidentByNumberAndTeam(incidentNumber, team);
                IncidentTracker incident = optional.orElse(new IncidentTracker());

                incident.setIncidentNumber(incidentNumber);
                incident.setTeam(team);
                incident.setUpdateUser(username);
                incident.setUpdateDatetime(LocalDateTime.now());
                incident.setCreateBy(username);
                incident.setCreateDatetime(LocalDateTime.now());

                incident.setOpenedTimeEst(parseDate(record.get("opened_at")));
                incident.setActImpClassification(record.get("u_high_classification"));
                incident.setTag(record.get("sys_tags"));
                incident.setCustomerExp(record.get("short_description"));
                incident.setPriority(record.get("priority"));
                incident.setAssignmentGroup(record.get("assigment_group"));
                incident.setImpact(record.get("impact"));
                incident.setStartDatetime(parseDate(record.get("u_mi_started")));
                incident.setDeductDatetime(parseDate(record.get("u_mi_detected")));
                incident.setDiagnoseDatetime(parseDate(record.get("u_mi_diagnosed")));
                incident.setMitigateDatetime(parseDate(record.get("u_mi_mitigated")));
                incident.setResolveDatetime(parseDate(record.get("u_mi_resolved")));
                incident.setAnalysis(record.get("analysis"));
                incident.setCustomerImpact(record.get("impact_count"));
                incident.setFlow(record.get("flow"));
                incident.setSplunkQueries(record.get("splunk queries"));
                incident.setFlagItem(false);

                incident.calculateTimes();

                if (incident.getTtm() != null)
                    incident.setFormattedTTM(formatDuration(incident.getTtm()));
                if (incident.getMttr() != null)
                    incident.setFormattedMTTR(formatDuration(incident.getMttr()));

                incident.setUpdateDatetime(convertToEST(LocalDateTime.now(), estZoneId));

                if (optional.isPresent()) {
                    incident.setId(optional.get().getId());
                    logger.info("Updating existing incident: {}", incidentNumber);
                } else {
                    logger.info("Inserting new incident: {}", incidentNumber);
                }

                incidentTrackerService.saveIncident(incident);
                logger.info("Saved incident: {}", incidentNumber);
            }

            logger.info("File Upload Ends");
            redirectAttributes.addFlashAttribute("successMessage", "File Upload Success");
        } catch (Exception e) {
            logger.error("File Upload Failed", e);
            redirectAttributes.addFlashAttribute("errorMessage", "File Upload Failed: " + e.getMessage());
        }

        return REDIRECT_FILE_UPLOAD;
    }

    private LocalDateTime parseDate(String input) {
        try {
            return (input == null || input.isEmpty()) ? null : LocalDateTime.parse(input.trim(), inputFormatter);
        } catch (Exception e) {
            return null;
        }
    }

    private String formatDuration(Long minutes) {
        long hrs = minutes / 60;
        long min = minutes % 60;
        return hrs + "h " + min + "m";
    }

    private LocalDateTime convertToEST(LocalDateTime dateTime, ZoneId estZoneId) {
        return ZonedDateTime.of(dateTime, ZoneId.systemDefault()).withZoneSameInstant(estZoneId).toLocalDateTime();
    }
}
