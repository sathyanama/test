package com.example.demo.controller;

import com.example.demo.service.IncidentTrackerService;
import com.example.demo.util.CommonUtil;
import com.example.demo.model.IncidentTracker;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.Arrays;
import java.util.Optional;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;

@WebMvcTest(IncidentUploadController.class)
@AutoConfigureMockMvc(addFilters = false)
public class IncidentUploadControllerLocalTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CommonUtil commonUtil;

    @MockBean
    private IncidentTrackerService incidentTrackerService;

    @Test
    void testOpenUploadPage() throws Exception {
        mockMvc.perform(get("/incident/upload")
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
                .andExpect(status().isOk())
                .andExpect(view().name("fileUploadIncident"));

        verify(commonUtil).addUserDetailsToModel(any(), eq("UPLOAD_CSV"), eq("UPLOAD_CSV"), any());
    }

    @Test
    void testHandleValidCsvUpload_shouldRedirectWithSuccess() throws Exception {
        String sampleCsv = "incident^^blank^^class^^tag^^cust^^prio^^group^^impact^^2024-01-01 10:00:00^^2024-01-01 12:00:00^^2024-01-01 12:30:00^^2024-01-01 13:00:00^^2024-01-01 14:00:00^^analysis^^3^^flow^^splunk";

        MockMultipartFile mockFile = new MockMultipartFile(
                "file", "sample.csv", "text/csv", sampleCsv.getBytes());

        mockMvc.perform(multipart("/incident/upload")
                .file(mockFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/incident/upload"));
    }

    @Test
    void testHandleInvalidFileExtension_shouldRedirectWithError() throws Exception {
        MockMultipartFile invalidFile = new MockMultipartFile(
                "file", "test.exe", "application/octet-stream", "dummy data".getBytes());

        mockMvc.perform(multipart("/incident/upload")
                .file(invalidFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/incident/upload"));
    }

    @Test
    void testHandleUploadWithMissingSessionAttributes_shouldRedirect() throws Exception {
        MockMultipartFile mockFile = new MockMultipartFile(
                "file", "sample.csv", "text/csv", "some^^dummy^^content".getBytes());

        mockMvc.perform(multipart("/incident/upload")
                .file(mockFile)) // no sessionAttr
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/incident/upload"));
    }
    
   

    
    @Test
    void testHandleUpload_throwsException_shouldSetErrorMessage() throws Exception {
        // Mock a file that causes an exception during processing
        String invalidLine = "INC123^^only^^5^^fields"; // < 17 fields triggers IndexOutOfBoundsException

        MockMultipartFile mockFile = new MockMultipartFile(
            "file", "invalid.csv", "text/csv", ("header\n" + invalidLine).getBytes()
        );

        mockMvc.perform(multipart("/incident/upload")
                .file(mockFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
            .andExpect(status().is3xxRedirection())
            .andExpect(redirectedUrl("/incident/upload"));
    }

    @Test
    void testHandleUpload_withInvalidDate_shouldFallbackToNullDate() throws Exception {
        String invalidDateLine =
            "INC123^^blank^^class^^tag^^cust^^P1^^group^^High^^invalid-date^^...^^...^^...^^...^^analysis^^3^^flow^^splunk";

        // Ensure the line has at least 17 fields, even if some are placeholders
        while (invalidDateLine.split("\\^\\^").length < 17) {
            invalidDateLine += "^^...";
        }

        MockMultipartFile mockFile = new MockMultipartFile(
            "file", "invalid_date.csv", "text/csv", ("header\n" + invalidDateLine).getBytes()
        );

        when(incidentTrackerService.getIncidentByNumberAndTeam(eq("INC123"), eq("DMC")))
            .thenReturn(Optional.empty());

        mockMvc.perform(multipart("/incident/upload")
                .file(mockFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
            .andExpect(status().is3xxRedirection());
    }
    
    @Test
    void testHandleUpload_triggersFormatDuration() throws Exception {
        String line =
            "INC123^^blank^^classification^^tag1^^customerExp^^P1^^group1^^High^^2024-01-01 10:00:00^^2024-01-01 11:00:00" +
            "^^2024-01-01 11:30:00^^2024-01-01 12:00:00^^2024-01-01 13:00:00^^analysis^^120^^flow123^^splunk";

        MockMultipartFile mockFile = new MockMultipartFile(
            "file", "incident.csv", "text/csv", ("header\n" + line).getBytes()
        );

        // Return custom incident with a fake TTM
        IncidentTracker incident = new IncidentTracker() {
            @Override
            public void calculateTimes() {
                this.setTtm(120L);
                this.setMttr(90L);
            }
        };

        when(incidentTrackerService.getIncidentByNumberAndTeam(eq("INC123"), eq("DMC")))
            .thenReturn(Optional.of(incident));

        mockMvc.perform(multipart("/incident/upload")
                .file(mockFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
            .andExpect(status().is3xxRedirection());
    }

    @Test
    void testHandleUpload_withEmptyFile_shouldRedirectWithError() throws Exception {
        MockMultipartFile emptyFile = new MockMultipartFile("file", "empty.csv", "text/csv", new byte[0]);

        mockMvc.perform(multipart("/incident/upload")
                .file(emptyFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
            .andExpect(status().is3xxRedirection())
            .andExpect(redirectedUrl("/incident/upload"));
    }
    
    @Test
    void testHandleUpload_withEmptyAnalysis_shouldUseCustomerExp() throws Exception {
        String line =
            "INC456^^blank^^classification^^tag1^^customerExperience^^P2^^group1^^Medium^^2024-01-01 10:00:00" +
            "^^2024-01-01 11:00:00^^2024-01-01 11:30:00^^2024-01-01 12:00:00^^2024-01-01 13:00:00^^^^4^^flow^^splunk";

        MockMultipartFile mockFile = new MockMultipartFile(
            "file", "incident.csv", "text/csv", ("header\n" + line).getBytes()
        );

        mockMvc.perform(multipart("/incident/upload")
                .file(mockFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
            .andExpect(status().is3xxRedirection());
    }

    @Test
    void testHandleUpload_withEmptyImpactCount_shouldSetNull() throws Exception {
        String line =
            "INC789^^blank^^classification^^tag1^^cust^^P3^^group^^Low^^2024-01-01 10:00:00^^2024-01-01 11:00:00" +
            "^^2024-01-01 11:30:00^^2024-01-01 12:00:00^^2024-01-01 13:00:00^^analysis^^^^flow^^splunk";

        MockMultipartFile mockFile = new MockMultipartFile(
            "file", "incident.csv", "text/csv", ("header\n" + line).getBytes()
        );

        mockMvc.perform(multipart("/incident/upload")
                .file(mockFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
            .andExpect(status().is3xxRedirection());
    }

    @Test
    void testHandleUpload_withMissingDate_shouldSkipDateParsing() throws Exception {
        // Build exactly 17 fields
        String[] fields = new String[17];
        fields[0] = "INC999";
        fields[1] = "blank";
        fields[2] = "class";
        fields[3] = "tag";
        fields[4] = "cust";
        fields[5] = "P1";
        fields[6] = "group";
        fields[7] = "High";
        fields[8] = ""; // StartDatetime - left empty to test parseDate(null)
        fields[9] = ""; // DeductDatetime - left empty
        fields[10] = ""; // DiagnoseDatetime
        fields[11] = ""; // MitigateDatetime
        fields[12] = ""; // ResolveDatetime
        fields[13] = ""; // Analysis - triggers fallback to customerExp
        fields[14] = "5"; // Impact count
        fields[15] = "flow";
        fields[16] = "splunk";

        String line = String.join("^^", fields);

        // Confirm defensive check
        assertEquals(17, line.split("\\^\\^", -1).length, "CSV should have 17 fields");

        MockMultipartFile mockFile = new MockMultipartFile(
            "file", "incident.csv", "text/csv", ("header\n" + line).getBytes()
        );

        mockMvc.perform(multipart("/incident/upload")
                .file(mockFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
            .andExpect(status().is3xxRedirection());
    }

    @Test
    void testHandleUpload_invalidExtensionOnly_shouldRedirect() throws Exception {
        MockMultipartFile invalidFile = new MockMultipartFile(
            "file", "invalid.pdf", "application/pdf", "dummy content".getBytes()
        );

        mockMvc.perform(multipart("/incident/upload")
                .file(invalidFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
            .andExpect(status().is3xxRedirection())
            .andExpect(redirectedUrl("/incident/upload"));
    }
    
    @Test
    void testHandleUpload_analysisEmpty_shouldFallbackToCustomerExp() throws Exception {
        String[] fields = new String[17];
        fields[0] = "INC777";
        fields[4] = "CustomerExpContent";  // this will be used as analysis
        fields[14] = "2";
        fields[15] = "flow";
        fields[16] = "splunk";
        // fields[13] left null/empty → triggers the condition

        String line = String.join("^^", fields);

        // Confirm 17 fields
        assertEquals(17, line.split("\\^\\^", -1).length);

        MockMultipartFile mockFile = new MockMultipartFile(
            "file", "incident.csv", "text/csv", ("header\n" + line).getBytes()
        );

        mockMvc.perform(multipart("/incident/upload")
                .file(mockFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
            .andExpect(status().is3xxRedirection());
    }
    
    @Test
    void testHandleUpload_allDatesMissing_shouldTriggerParseDateNull() throws Exception {
        String[] fields = new String[17];
        fields[0] = "INC888";
        fields[4] = "CX message";
        fields[14] = "1";
        fields[15] = "flow";
        fields[16] = "splunk";
        // leave fields[8] to [12] empty (date fields)

        String line = String.join("^^", fields);

        assertEquals(17, line.split("\\^\\^", -1).length);

        MockMultipartFile mockFile = new MockMultipartFile(
            "file", "incident.csv", "text/csv", ("header\n" + line).getBytes()
        );

        mockMvc.perform(multipart("/incident/upload")
                .file(mockFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
            .andExpect(status().is3xxRedirection());
    }

    @Test
    void testHandleUpload_emptyFileValidExtension_shouldRedirect() throws Exception {
        MockMultipartFile emptyCsv = new MockMultipartFile(
            "file", "empty.csv", "text/csv", new byte[0]  // empty content
        );

        mockMvc.perform(multipart("/incident/upload")
                .file(emptyCsv)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
            .andExpect(status().is3xxRedirection())
            .andExpect(redirectedUrl("/incident/upload"));
    }

    @Test
    void testHandleUpload_fileEmptyAndInvalidExtension() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
            "file", "emptyfile.exe", "application/octet-stream", new byte[0]
        );

        mockMvc.perform(multipart("/incident/upload")
                .file(file)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
            .andExpect(status().is3xxRedirection())
            .andExpect(redirectedUrl("/incident/upload"));
    }
    
    @Test
    void testHandleUpload_analysisFieldNull_shouldTriggerFallback() throws Exception {
        String[] fields = new String[17];
        fields[0] = "INC001";
        fields[4] = "CX fallback";
        // Skip fields[13] = null
        fields[14] = "1";
        fields[15] = "flow";
        fields[16] = "splunk";

        StringBuilder line = new StringBuilder();
        for (int i = 0; i < fields.length; i++) {
            if (i > 0) line.append("^^");
            line.append(fields[i] != null ? fields[i] : "");
        }

        assertEquals(17, line.toString().split("\\^\\^", -1).length);

        MockMultipartFile mockFile = new MockMultipartFile(
            "file", "incident.csv", "text/csv", ("header\n" + line).toString().getBytes()
        );

        mockMvc.perform(multipart("/incident/upload")
                .file(mockFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
            .andExpect(status().is3xxRedirection());
    }
    
    @Test
    void testHandleUpload_missingFieldShouldPassNullToParseDate() throws Exception {
        String[] fields = new String[17];
        fields[0] = "INC002";
        fields[4] = "CX";
        fields[13] = "analysis";
        fields[14] = "1";
        fields[15] = "flow";
        fields[16] = "splunk";
        // field[8] (startDatetime) left null intentionally

        StringBuilder line = new StringBuilder();
        for (int i = 0; i < fields.length; i++) {
            if (i > 0) line.append("^^");
            line.append(fields[i] != null ? fields[i] : "");
        }

        assertEquals(17, line.toString().split("\\^\\^", -1).length);

        MockMultipartFile mockFile = new MockMultipartFile(
            "file", "incident.csv", "text/csv", ("header\n" + line).toString().getBytes()
        );

        mockMvc.perform(multipart("/incident/upload")
                .file(mockFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
            .andExpect(status().is3xxRedirection());
    }

    @Test
    void testHandleUpload_validTxtExtension_shouldPass() throws Exception {
        String sampleTxt = "incident^^blank^^class^^tag^^cust^^prio^^group^^impact^^2024-01-01 10:00:00^^2024-01-01 12:00:00^^2024-01-01 12:30:00^^2024-01-01 13:00:00^^2024-01-01 14:00:00^^analysis^^3^^flow^^splunk";

        MockMultipartFile mockFile = new MockMultipartFile(
            "file", "sample.txt", "text/plain", sampleTxt.getBytes()
        );

        mockMvc.perform(multipart("/incident/upload")
                .file(mockFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/incident/upload"));
    }

    @Test
    void testHandleUpload_analysisNull_shouldUseCustomerExp() throws Exception {
        String[] fields = new String[17];
        fields[0] = "INC1000";
        fields[4] = "fallback CX"; // will be copied into analysis
        fields[13] = null;         // triggers: analysis == null
        fields[14] = "2";
        fields[15] = "flow";
        fields[16] = "splunk";

        String line = String.join("^^", Arrays.stream(fields)
            .map(f -> f == null ? "" : f).toArray(String[]::new));
        assertEquals(17, line.split("\\^\\^", -1).length);

        MockMultipartFile file = new MockMultipartFile(
            "file", "incident.csv", "text/csv", ("header\n" + line).getBytes());

        mockMvc.perform(multipart("/incident/upload")
                .file(file)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
                .andExpect(status().is3xxRedirection());
    }

    @Test
    void testHandleUpload_withNullDate_shouldTriggerParseDateNull() throws Exception {
        String[] fields = new String[17];
        fields[0] = "INC1001";
        fields[13] = "analysis";
        fields[14] = "2";
        fields[15] = "flow";
        fields[16] = "splunk";
        fields[8] = null;  // startDatetime = null

        String line = String.join("^^", Arrays.stream(fields)
            .map(f -> f == null ? "" : f).toArray(String[]::new));
        assertEquals(17, line.split("\\^\\^", -1).length);

        MockMultipartFile file = new MockMultipartFile(
            "file", "incident.csv", "text/csv", ("header\n" + line).getBytes());

        mockMvc.perform(multipart("/incident/upload")
                .file(file)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
                .andExpect(status().is3xxRedirection());
    }

    @Test
    void test_analysisNull_shouldTriggerFallback() throws Exception {
        // 17 fields = 16 delimiters ("^^")
        String line =
            "INC_X^^blank^^class^^tag^^CustomerExp^^P1^^group^^impact^^2024-01-01 10:00:00" + // fields 0–8
            "^^2024-01-01 12:00:00^^2024-01-01 12:30:00^^2024-01-01 13:00:00^^2024-01-01 14:00:00" + // fields 9–13
            "^^^^2^^flow^^splunk"; // field 13 is empty, followed by fields 14, 15, 16

        assertEquals(17, line.split("\\^\\^", -1).length); // ✅ This will now pass

        MockMultipartFile mockFile = new MockMultipartFile(
            "file", "incident.csv", "text/csv", ("header\n" + line).getBytes());

        mockMvc.perform(multipart("/incident/upload")
                .file(mockFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
                .andExpect(status().is3xxRedirection());
    }

    // new cases
    
    @Test
    void testHandleCsvUpload_parsesAndSavesIncident() throws Exception {
        String csvHeader = String.join(",",
            "incident_number", "opened_at", "u_high_classification", "sys_tags", "short_description",
            "priority", "assigment_group", "impact", "u_mi_started", "u_mi_detected",
            "u_mi_diagnosed", "u_mi_mitigated", "u_mi_resolved", "analysis", "impact_count",
            "flow", "splunk queries"
        );

        String fullCsvLine =
            "INC123,2024-01-01 09:00,classification,tag1,customerExp,P1,group1,High," +
            "2024-01-01 10:00,2024-01-01 11:00,2024-01-01 11:30,2024-01-01 12:00,2024-01-01 13:00," +
            "\"analysis text with\nmultiline support\",3,\"flow123\",\"splunk query\"";

        MockMultipartFile mockFile = new MockMultipartFile(
            "file", "incident.csv", "text/csv", (csvHeader + "\n" + fullCsvLine).getBytes()
        );

        when(incidentTrackerService.getIncidentByNumberAndTeam(eq("INC123"), eq("DMC")))
            .thenReturn(Optional.empty());

        mockMvc.perform(multipart("/incident/upload")
                .file(mockFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
            .andExpect(status().is3xxRedirection())
            .andExpect(redirectedUrl("/incident/upload"));

        verify(incidentTrackerService).saveIncident(any(IncidentTracker.class));
    }
    
    
    @Test
    void testHandleCsvUpload_updatesExisting_withTtmAndMttr() throws Exception {
        String csvHeader = String.join(",", "incident_number", "opened_at", "u_high_classification", "sys_tags",
            "short_description", "priority", "assigment_group", "impact", "u_mi_started", "u_mi_detected",
            "u_mi_diagnosed", "u_mi_mitigated", "u_mi_resolved", "analysis", "impact_count", "flow", "splunk queries");

        String csvLine = "INC456,2024-01-01 09:00,classify,tag2,desc,P2,group2,Low," +
            "2024-01-01 10:00,2024-01-01 11:00,2024-01-01 11:30,2024-01-01 12:00,2024-01-01 13:00," +
            "analysis2,5,flowdata,splunkdata";

        MockMultipartFile mockFile = new MockMultipartFile(
            "file", "incident.csv", "text/csv", (csvHeader + "\n" + csvLine).getBytes()
        );

        IncidentTracker mockIncident = new IncidentTracker();
        mockIncident.setId(999L);
        mockIncident.setTtm(130L);  // Trigger formatDuration
        mockIncident.setMttr(62L);

        when(incidentTrackerService.getIncidentByNumberAndTeam(eq("INC456"), eq("DMC")))
            .thenReturn(Optional.of(mockIncident));

        mockMvc.perform(multipart("/incident/upload")
                .file(mockFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
            .andExpect(status().is3xxRedirection())
            .andExpect(redirectedUrl("/incident/upload"));

        verify(incidentTrackerService).saveIncident(any(IncidentTracker.class));
    }

    @Test
    void testHandleCsvUpload_handlesNullEmptyAndInvalidDates() throws Exception {
        String csvHeader = String.join(",", "incident_number", "opened_at", "u_high_classification", "sys_tags",
            "short_description", "priority", "assigment_group", "impact", "u_mi_started", "u_mi_detected",
            "u_mi_diagnosed", "u_mi_mitigated", "u_mi_resolved", "analysis", "impact_count", "flow", "splunk queries");

        String row1 = "INC100,nullDate,classify,tag,desc,P1,grp,High,2024-01-01 10:00,,,,,,,,";
        String row2 = "INC101,,classify,tag,desc,P1,grp,High,2024-01-01 10:00,,,,,,,,"; // empty date
        String row3 = "INC102,invalid-date,classify,tag,desc,P1,grp,High,2024-01-01 10:00,,,,,,,,";

        MockMultipartFile mockFile = new MockMultipartFile(
            "file", "incidents.csv", "text/csv",
            (csvHeader + "\n" + row1 + "\n" + row2 + "\n" + row3).getBytes()
        );

        when(incidentTrackerService.getIncidentByNumberAndTeam(anyString(), anyString()))
            .thenReturn(Optional.empty());

        mockMvc.perform(multipart("/incident/upload")
                .file(mockFile)
                .sessionAttr("username", "testuser")
                .sessionAttr("team", "DMC"))
            .andExpect(status().is3xxRedirection());

        verify(incidentTrackerService, times(3)).saveIncident(any(IncidentTracker.class));
    }


}

