import os
import pandas as pd

# Reuse your loader
from alert_rules_loader import load_alert_rules

def get_search_query_by_alert_name(alert_name: str) -> str:
    """
    Return search_query as a string if found, else return an error string.
    """
    df = load_alert_rules()

    # Case-insensitive match
    result = df[df["alert_name"].str.lower() == alert_name.lower()]

    if result.empty:
        return None  # cleaner: no match
    return result.iloc[0]["search_query"]


def splunk_query_fetch(alert_name: str) -> dict:
    """
    Return JSON: either {status: success, data: {search_query: ...}}
    or {status: error, message: "..."}.
    """
    try:
        query = get_search_query_by_alert_name(alert_name)

        if query is None:
            return {
                "status": "error",
                "message": f"[alert_rules_loader] Alert '{alert_name}' not found."
            }

        return {
            "status": "success",
            "data": {"search_query": query}
        }

    except Exception as e:
        error_msg = f"Error reading alert rules: {str(e)}"
        return {
            "status": "error",
            "message": error_msg
        }


# Example integration with LLMAgent (unchanged from your office pattern)
splunk_query_fetcher = LLMAgent(
    system_message="Analyze and return Splunk search queries",
    tool=[splunk_query_fetch],
    model=model,
    config=AuthConfig(output_key="splunk_query_fetcher")
)
