import pandas as pd
import os

# Base folder = one level up from current file
BASE_DIR = os.path.dirname(os.path.dirname(__file__))

CSV_FILE_PATH = os.path.join(BASE_DIR, "alert.csv")
PARQUET_FILE_PATH = os.path.join(BASE_DIR, "alert_rules.parquet")

# Internal cache
_parquet_df = None
load_count = 0  # For debugging how many times file is loaded

def load_alert_rules():
    global _parquet_df, load_count

    if _parquet_df is not None:
        print("[alert_rules_loader] ⚡ DataFrame already loaded in memory")
        return _parquet_df

    # Step 1: Check if Parquet file exists
    if not os.path.exists(PARQUET_FILE_PATH):
        print(f"[alert_rules_loader] Converting CSV → Parquet: {CSV_FILE_PATH}")
        df = pd.read_csv(CSV_FILE_PATH)
        df.to_parquet(PARQUET_FILE_PATH, index=False)  # engine="pyarrow" optional
    else:
        print(f"[alert_rules_loader] Parquet file found: {PARQUET_FILE_PATH}")

    # Step 2: Load Parquet into memory (only once)
    _parquet_df = pd.read_parquet(PARQUET_FILE_PATH)  # engine="pyarrow" optional
    load_count += 1
    print(f"[alert_rules_loader] 📦 Parquet loaded into memory — load count = {load_count}")

    return _parquet_df		