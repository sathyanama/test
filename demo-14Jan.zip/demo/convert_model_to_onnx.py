from transformers import AutoTokenizer, AutoModel
import torch

# Load the model and tokenizer
model_name = "sentence-transformers/all-MiniLM-L6-v2"  # Pretrained model
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModel.from_pretrained(model_name)

# Prepare dummy input
dummy_input = tokenizer(
    "This is a sample input",
    return_tensors="pt",
    padding=True,
    truncation=True,
    max_length=128
)

# Export the model to ONNX with Opset version 14
torch.onnx.export(
    model,
    (dummy_input["input_ids"], dummy_input["attention_mask"]),
    "sentence_transformer.onnx",
    input_names=["input_ids", "attention_mask"],
    output_names=["output"],
    dynamic_axes={
        "input_ids": {0: "batch_size", 1: "sequence_length"},
        "attention_mask": {0: "batch_size", 1: "sequence_length"}
    },
    opset_version=14  # Updated Opset version
)

print("Model successfully converted to ONNX format!")
