import numpy as np
import onnxruntime as ort

# Load model
session = ort.InferenceSession("C:/Users/sathy/Downloads/personal/SpringBoot/demo/demo/src/main/resources/models/sentence_transformer.onnx")

# Define inputs
input_ids = np.array([[21, 14, 1, 2, 12, 5, 0, 20, 15, 0, 12, 15, 7, 9, 14]], dtype=np.int64)
attention_mask = np.array([[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]], dtype=np.int64)


# Run inference
outputs = session.run(None, {"input_ids": input_ids, "attention_mask": attention_mask})
print("Embedding vector:", outputs[0])
