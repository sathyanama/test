import onnx

model = onnx.load("C:/Users/sathy/Downloads/personal/SpringBoot/demo/demo/src/main/resources/models/sentence_transformer.onnx")
print("Model Inputs:")
for input in model.graph.input:
    print(f"Name: {input.name}, Type: {input.type.tensor_type.elem_type}, Shape: {[dim.dim_value for dim in input.type.tensor_type.shape.dim]}")
