import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from splunklib.client import Service
from splunklib.results import ResultsReader
import re
import json
import time
from datetime import datetime

# ========== SPLUNK CONFIG ==========
with open("splunk_config.json") as f:
    SPLUNK_CONFIG = json.load(f)

# ========== CONTEXT MEMORY ==========
context = {
    "last_intent": "",
    "time_range": "15m",
    "last_query": ""
}

# ========== SPLUNK QUERY RUNNER ==========
def run_splunk_query(query):
    service = Service(**SPLUNK_CONFIG)
    service.login()
    job = service.jobs.create(query)

    timeout = 60
    start_time = time.time()
    while not job.is_done():
        if time.time() - start_time > timeout:
            print("Timeout: Splunk job took too long.")
            return []
        time.sleep(1)

    rr = ResultsReader(job.results(output_mode="json"))
    logs = [result for result in rr if isinstance(result, dict)]
    return logs

# ========== MISTRAL LOADER ==========
print("Loading Mistral...")
model_path = "./models/mistral-7b-instruct"
tokenizer = AutoTokenizer.from_pretrained(model_path, use_fast=False, trust_remote_code=True)
model = AutoModelForCausalLM.from_pretrained(model_path, torch_dtype=torch.float16, trust_remote_code=True).eval()
device = "cuda" if torch.cuda.is_available() else "cpu"
model.to(device)

# ========== TIME UTILS ==========
def is_time_update(user_input):
    return bool(re.match(r'^(now\s*)?(make it|try|do)\s*\d+\s*(m|mins|minutes|h|hrs|hours)$', user_input.lower()))

def extract_time_range(text):
    match = re.search(r'(\d+)\s*(m|mins|minutes|h|hrs|hours)', text.lower())
    if match:
        val, unit = match.groups()
        return f"{val}{'m' if 'm' in unit else 'h'}"
    return "15m"

# ========== MISTRAL CHAT ==========
def mistral_generate(prompt, max_tokens=400):
    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    start_time = time.time()
    outputs = model.generate(**inputs, max_new_tokens=max_tokens)
    duration = time.time() - start_time
    print(f"\nResponse generated in {duration:.2f} seconds.")
    return tokenizer.decode(outputs[0], skip_special_tokens=True).strip()

# ========== CHAT LOOP ==========
def chat_with_user():
    print("\nLogGPT Interactive CLI (type 'quit' to exit)")
    while True:
        user_input = input("\nYou: ")
        if user_input.lower() == "quit":
            break

        if is_time_update(user_input):
            context["time_range"] = extract_time_range(user_input)
            user_input = f"{context['last_intent']} for last {context['time_range']}"
            print(f"Time range updated. Reusing: \"{user_input}\"")

        context["last_intent"] = user_input

        # Generate Splunk Query
        query_prompt = f"""
[INST]
You are a Splunk assistant.

Use the following field mapping rules:
- index = "{SPLUNK_CONFIG['index']}"
- sourcetype = "{SPLUNK_CONFIG['sourcetype']}"
- source = "{SPLUNK_CONFIG['source']}"

How to interpret user requests:
- If the user mentions a service like "payment", "bill pay", "user login", or "app/data", map it to:
  urlPath="*payment*", urlPath="*bill*pay*", urlPath="*user*login*", urlPath="*app/data*"
- If the user mentions "failure", "error", "5xx", or says "httpCode 50*", treat it as: httpCode >= 500
- If the user says "success", "httpCode 200", or "302", use: httpCode=200 OR httpCode=302
- Use: earliest=-{context['time_range']} for time filtering
- Always end the query with: | stats count by urlPath, httpCode, b3TraceId

Important constraints:
- Only use these fields: index, sourcetype, source, urlPath, httpCode, earliest
- Do not use any other fields like message, _raw, _time, logtext, or responseText
- Do not use `| where message=...` or any similar clauses

Examples:
- "payment failure for 50*" → search index=... urlPath="*payment*" httpCode>=500 earliest=-15m | stats count by urlPath, httpCode, b3TraceId
- "check bill pay error for 2h" → search index=... urlPath="*bill*pay*" httpCode>=500 earliest=-2h | stats count by urlPath, httpCode, b3TraceId

Now convert the user’s request into a valid Splunk query using these rules.
Return only the query string.
User: "{user_input}"
[/INST]
"""
        start_time = time.time()
        raw_response = mistral_generate(query_prompt, max_tokens=200)
        raw_response = raw_response.replace("[INST]", "").replace("[/INST]", "").strip()
        generation_time = time.time() - start_time

        splunk_query = ""
        for line in raw_response.splitlines():
            if line.strip().lower().startswith("search"):
                splunk_query = line.strip()
                break

        splunk_query = splunk_query \
            .replace('“', '"').replace('”', '"') \
            .replace('‘', '"').replace('’', '"') \
            .replace('–', '-') \
            .replace('`', '"')

        if not splunk_query.lower().startswith("search"):
            splunk_query = "search " + splunk_query

        context["last_query"] = splunk_query

        print("\nSplunk Query:")
        print(splunk_query)

        print("\nFetching logs...")
        splunk_start = time.time()
        logs = run_splunk_query(splunk_query)
        splunk_duration = time.time() - splunk_start
        print(f"Splunk query executed in {splunk_duration:.2f} seconds.")

        if not logs:
            print("No logs found.")
            continue

        top_logs = logs[:10]
        print("\nLogs (Top 10):")
        trace_ids = []
        for i, log in enumerate(top_logs, 1):
            if isinstance(log, dict):
                uri_path = log.get("urlPath", "-")
                http_code = log.get("httpCode", "-")
                count = log.get("count", "-")
                print(f"{i}. urlPath: {uri_path}, httpCode: {http_code}, count: {count}")
                if "b3TraceId" in log and len(trace_ids) < 3:
                    trace_ids.append(log["b3TraceId"])

        if trace_ids:
            print("\nPerforming log trace analysis on top b3TraceId values...")
            for i, trace_id in enumerate(trace_ids, 1):
                print(f"\nTrace {i}: b3TraceId = {trace_id}")
                trace_query = f'search index="{SPLUNK_CONFIG["index"]}" b3TraceId="{trace_id}" | table _raw'
                trace_start = time.time()
                trace_logs = run_splunk_query(trace_query)
                trace_duration = time.time() - trace_start
                print(f"Trace query executed in {trace_duration:.2f} seconds. Rows: {len(trace_logs)}")
                for log in trace_logs[:50]:
                    print(log.get("_raw", "<no _raw field>"))
        else:
            print("\nNo b3TraceId found in top logs to trace.")

# ========== START ==========
if __name__ == "__main__":
    chat_with_user()
