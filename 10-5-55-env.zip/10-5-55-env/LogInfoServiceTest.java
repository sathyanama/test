package com.example.demo.service;

import com.example.demo.model.LogInfo;
import com.example.demo.repository.LogInfoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import java.time.LocalDateTime;
import java.time.ZoneId;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LogInfoServiceTest {

    @Mock
    private LogInfoRepository logInfoRepository;

    @InjectMocks
    private LogInfoService logInfoService;

    @Captor
    ArgumentCaptor<LogInfo> logCaptor;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testLogActivity_withAllParams_savesLogCorrectly() {
        logInfoService.logActivity("sess123", "dashboard", "testuser", "Error occurred", "500");

        verify(logInfoRepository).save(logCaptor.capture());
        LogInfo savedLog = logCaptor.getValue();

        assertEquals("sess123", savedLog.getSessionId());
        assertEquals("dashboard", savedLog.getScreenId());
        assertEquals("testuser", savedLog.getUsername());
        assertEquals("Error occurred", savedLog.getException());
        assertEquals("500", savedLog.getResponseCode());
        assertNotNull(savedLog.getLogDatetime());
    }

    @Test
    void testLogActivity_withDefaults_savesSuccessLog() {
        logInfoService.logActivity("sess456", "rca", "adminuser");

        verify(logInfoRepository).save(logCaptor.capture());
        LogInfo savedLog = logCaptor.getValue();

        assertEquals("sess456", savedLog.getSessionId());
        assertEquals("rca", savedLog.getScreenId());
        assertEquals("adminuser", savedLog.getUsername());
        assertEquals("Success", savedLog.getException());
        assertEquals("200", savedLog.getResponseCode());
        assertNotNull(savedLog.getLogDatetime());
    }
}
