package com.example.demo.controller;

import jakarta.servlet.RequestDispatcher;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.RequestPostProcessor;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CustomErrorController.class)
@AutoConfigureMockMvc(addFilters = false)
public class CustomErrorControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private RequestPostProcessor withErrorAttributes() {
        return request -> {
            request.setAttribute(RequestDispatcher.ERROR_STATUS_CODE, 404);
            request.setAttribute(RequestDispatcher.ERROR_MESSAGE, "Page not found");
            request.setAttribute(RequestDispatcher.ERROR_REQUEST_URI, "/invalid-page");
            return request;
        };
    }

    @Test
    void testHandleError_returnsErrorPage() throws Exception {
        mockMvc.perform(get("/error").with(withErrorAttributes()))
            .andExpect(status().isOk())
            .andExpect(view().name("error"))
            .andExpect(model().attribute("statusCode", 404))
            .andExpect(model().attribute("errorMessage", "Page not found"))
            .andExpect(model().attribute("requestUri", "/invalid-page"));
    }

    @Test
    void testHandleError_withMissingAttributes_defaultsTo500() throws Exception {
        mockMvc.perform(get("/error"))
            .andExpect(status().isOk())
            .andExpect(view().name("error"))
            .andExpect(model().attribute("statusCode", 500))
            .andExpect(model().attribute("errorMessage", "Unknown error occurred"))
            .andExpect(model().attribute("requestUri", "Unknown URI"));
    }
}
