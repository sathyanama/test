# fast_app.py
import os
import logging
from fastapi import FastAPI, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from starlette.middleware.wsgi import WSGIMiddleware
from flask import Flask, request, redirect

from idaCall import IDACALL, errors
from utils.logging_utils import setup_logging

# --- Logging ---
app_logger = setup_logging("app")
auth_logger = setup_logging("auth")

# Shared store between Flask & FastAPI
session_store = {}

# --- Flask app (handles ADFS only) ---
flask_app = Flask(__name__)
flask_app.secret_key = os.environ.get("SECRET_KEY") or os.urandom(24)

# IDA setup (Flask side)
config_data = {
    "client_id": os.getenv("IDA_CLIENT_ID"),
    "client_secret": os.getenv("IDA_CLIENT_SECRET"),
    "authority": os.getenv("IDA_AUTHORITY"),
    "redirect_uri": os.getenv("IDA_REDIRECT_URI"),
    "scope": ["openid", "profile", "email"],
}
idea_ida = IDACALL(config_data)
auth = idea_ida.auth()

# Helper: extract display_name + initials
def process_login(access_token):
    user = auth.auth_user(access_token=access_token)
    claims = user.get_claims()
    display_name = claims.get("DisplayName", "")
    parts = [p.strip() for p in display_name.split(",") if p.strip()]
    initial = "".join(part[0].upper() for part in reversed(parts)) if parts else ""
    return display_name, initial

# Flask login route
@flask_app.route("/user/login", methods=["GET"], strict_slashes=False)
def login():
    if "access_token" not in session_store:
        args = {"state": request.url}
        redirect_url = idea_ida.get_redirect_url(args)
        return redirect(redirect_url), 302
    else:
        # Already logged in → bounce to FastAPI index
        return redirect("/", code=302)

# Flask callback route
@flask_app.route("/ida_callback", methods=["POST"], strict_slashes=False)
def ida_callback():
    code = request.form.get("code")
    user = auth.auth_user(code=code)
    session_store["access_token"] = user.get_access_token()
    state = request.form.get("state") or "/"
    return redirect(state, 302)

# --- FastAPI app (main app) ---
fastapi_app = FastAPI(title="MAC Assistance")
fastapi_app.add_middleware(SessionMiddleware, secret_key=flask_app.secret_key)

# Jinja2 templates (shared with Flask)
templates = Jinja2Templates(directory="templates")

@fastapi_app.get("/")
async def index(request: Request):
    if "access_token" not in session_store:
        app_logger.debug("No token → redirecting to Flask login")
        return RedirectResponse(url="/flask/user/login?state=/", status_code=302)

    try:
        display_name, initial = process_login(session_store["access_token"])
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "display_name": display_name,
                "initial": initial,
            },
        )
    except errors.InvalidAccessTokenError:
        session_store.clear()
        return RedirectResponse(url="/flask/user/login?state=/", status_code=302)

# Mount Flask inside FastAPI under /flask
fastapi_app.mount("/flask", WSGIMiddleware(flask_app))

# Entrypoint
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("fast_app:fastapi_app", host="0.0.0.0", port=8000, reload=True)
