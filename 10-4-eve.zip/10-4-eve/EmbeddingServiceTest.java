package com.example.demo.service;

import ai.onnxruntime.OrtException;
import aj.org.objectweb.asm.commons.Method;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class EmbeddingServiceTest {

    @Test
    void testComputeEmbedding_validInput_returnsEmbedding() throws Exception {
        EmbeddingService spyService = spy(new EmbeddingService());

        // Simulate normal embedding output
        float[] expected = new float[]{0.1f, 0.2f, 0.3f};
        doReturn(expected).when(spyService).computeEmbeddingInternal("cpu failure");

        float[] result = spyService.computeEmbedding("cpu failure");

        assertNotNull(result);
        assertArrayEquals(expected, result);
    }
    


    @Test
    void testEmbeddingCache_isUsedAfterFirstCall() throws Exception {
        EmbeddingService spyService = spy(new EmbeddingService());

        float[] expected = new float[]{0.7f, 0.8f, 0.9f};
        doReturn(expected).when(spyService).computeEmbeddingInternal("disk full");

        // First call → triggers computation
        float[] result1 = spyService.computeEmbedding("disk full");
        assertNotNull(result1);

        // Second call → should hit cache, computeEmbeddingInternal not invoked again
        float[] result2 = spyService.computeEmbedding("disk full");
        assertNotNull(result2);

        verify(spyService, times(1)).computeEmbeddingInternal("disk full");
    }
    
    
    @Test
    public void testComputeEmbedding_withMockedProtectedMethods() throws Exception {
        // Subclass with overridden methods
        EmbeddingService spyService = new EmbeddingService() {
            @Override
            protected long[][] tokenize(String text) {
                return new long[][]{{1, 2, 3}};
            }

            @Override
            protected long[][] generateAttentionMask(long[][] inputIds) {
                return new long[][]{{1, 1, 1}};
            }

            @Override
            protected float[] meanPool(float[][] tokenEmbeddings) {
                return new float[]{0.1f, 0.2f};
            }

           
        };

        float[] result = spyService.computeEmbedding("disk failure");

        assertNotNull(result);
        assertEquals(2, result.length);
        assertEquals(0.1f, result[0]);
        assertEquals(0.2f, result[1]);
    }
    
    @Test
    public void testTokenize_basicInput() {
        EmbeddingService service = new EmbeddingService();
        long[][] result = service.tokenize("disk");
        assertNotNull(result);
        assertEquals(1, result.length);
        assertEquals(4, result[0].length); // "disk" has 4 characters
    }

    @Test
    public void testGenerateAttentionMask_basic() {
        EmbeddingService service = new EmbeddingService();
        long[][] inputIds = new long[][]{{1, 2, 3}};
        long[][] mask = service.generateAttentionMask(inputIds);
        assertEquals(1, mask.length);
        assertEquals(3, mask[0].length);
        for (long val : mask[0]) {
            assertEquals(1L, val);
        }
    }
    
    @Test
    public void testMeanPool_basic() {
        EmbeddingService service = new EmbeddingService();
        float[][] embeddings = {
            {1.0f, 2.0f},
            {3.0f, 4.0f},
            {5.0f, 6.0f}
        };
        float[] result = service.meanPool(embeddings);
        assertEquals(3.0f, result[0]);
        assertEquals(4.0f, result[1]);
    }



    
    
}
