package com.example.demo.controller;

import com.example.demo.model.HandoverTracker;
import com.example.demo.model.IncidentTracker;
import com.example.demo.model.User;
import com.example.demo.service.HandoverService;
import com.example.demo.service.IncidentTrackerService;
import com.example.demo.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import org.springframework.security.test.context.support.WithMockUser;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.nullValue;




@AutoConfigureMockMvc(addFilters = false)
@WebMvcTest(HandoverController.class)
public class HandoverControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private HandoverService handoverService;
    
    @MockBean
    private IncidentTrackerService incidentTrackerService;

    @MockBean
    private UserService userService;

    @Autowired
    private ObjectMapper objectMapper;
    
    

    @Test
    public void testGetHandoverHeading() throws Exception {
        Principal mockPrincipal = () -> "testuser";

        User dummyUser = new User();
        dummyUser.setTeam("DMC");
        dummyUser.setLocation("SG");

        HandoverTracker dummyTracker = new HandoverTracker();
        dummyTracker.setHoItem(""); // match real returned values
        dummyTracker.setStartDate(LocalDateTime.of(2025, 3, 28, 19, 30));
        dummyTracker.setEndDate(LocalDateTime.of(2025, 3, 29, 7, 30));

        when(userService.getUserByUsername("testuser")).thenReturn(dummyUser);
        when(handoverService.getHandoverByCurrentTime(eq("DMC"), any())).thenReturn(Optional.of(dummyTracker));
        when(handoverService.getHandoverHeading("SG")).thenReturn("Mock Handover");

        mockMvc.perform(get("/api/handover")
                .param("location", "SG")
                .principal(mockPrincipal))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.heading").value("Mock Handover")); // ✅ FIXED
    }

    @Test
    public void testGetHandoverHeading_US() throws Exception {
        Principal mockPrincipal = () -> "testuser";

        User dummyUser = new User();
        dummyUser.setTeam("DMC");
        dummyUser.setLocation("US");

        HandoverTracker dummyTracker = new HandoverTracker();
        dummyTracker.setHoItem(""); // match real returned values
        dummyTracker.setStartDate(LocalDateTime.of(2025, 3, 28, 7, 30));
        dummyTracker.setEndDate(LocalDateTime.of(2025, 3, 29, 19, 30));

        when(userService.getUserByUsername("testuser")).thenReturn(dummyUser);
        when(handoverService.getHandoverByCurrentTime(eq("DMC"), any())).thenReturn(Optional.of(dummyTracker));
        when(handoverService.getHandoverHeading("US")).thenReturn("Mock Handover");

        mockMvc.perform(get("/api/handover")
                .param("location", "US")
                .principal(mockPrincipal))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.heading").value("Mock Handover")); // ✅ FIXED
    }

    @Test
    public void testSaveOrUpdateHandover() throws Exception {
        Principal mockPrincipal = () -> "testuser";

        User mockUser = new User();
        mockUser.setTeam("DMC");
        mockUser.setLocation("SG");

        HandoverTracker tracker = new HandoverTracker();
        tracker.setHoItem("Update");

        when(userService.getUserByUsername("testuser")).thenReturn(mockUser);
        when(handoverService.saveOrUpdateHandover(eq("DMC"), any(), any(), eq("Test Item"), eq("testuser")))
            .thenReturn(tracker);

        mockMvc.perform(post("/api/handover/save")
                .param("team", "DMC")
                .param("startDate", LocalDateTime.now().toString())
                .param("endDate", LocalDateTime.now().plusHours(1).toString())
                .param("hoItem", "Test Item")
                .principal(mockPrincipal))
            .andDo(print())
            .andExpect(status().isOk())
            .andExpect(content().string("Handover saved successfully.")); // ✅ FINAL FIX
    }    

    
    @Test
    public void testRetrieveHandoverByTeamAndDates() throws Exception {
        HandoverTracker tracker = new HandoverTracker();
        tracker.setHoItem("Night Ops");

        when(handoverService.getHandoverByTeamAndDates(anyString(), any(), any()))
            .thenReturn(Optional.of(tracker)); // correct method here!

        mockMvc.perform(get("/api/handover/retrieve")
                .param("team", "DMC")
                .param("startDate", LocalDateTime.now().toString())
                .param("endDate", LocalDateTime.now().plusHours(1).toString()))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.handover.hoItem").value("Night Ops"));
    }
    
    
// new changes in this method on 1-5-2025
    
    @Test
    public void testRetrieveHandoverByShift() throws Exception {
        // Mock handover object
        HandoverTracker tracker = new HandoverTracker();
        tracker.setHoItem("Night Ops");

        // Mock flagged incidents
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INC123456");
        incident.setTeam("DMC");

        when(handoverService.getHandoverByTeamAndDates(anyString(), any(), any()))
            .thenReturn(Optional.of(tracker));

        when(handoverService.getFlaggedIncidentsForDateRange(anyString(), any(), any()))
            .thenReturn(List.of(incident));

        mockMvc.perform(get("/api/handover/retrieve")
                .param("team", "DMC")
                .param("startDate", LocalDateTime.now().toString())
                .param("endDate", LocalDateTime.now().plusHours(1).toString()))
            .andDo(print())
            .andExpect(status().isOk())
            .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.handover.hoItem").value("Night Ops"))
            .andExpect(jsonPath("$.flaggedIncidents").isArray())
            .andExpect(jsonPath("$.flaggedIncidents[0].incidentNumber").value("INC123456"))
            .andExpect(jsonPath("$.flaggedIncidents[0].team").value("DMC"));
    }
    
    
    @Test
    public void testRetrieveHandover_WhenHandoverIsEmpty() throws Exception {
        // Simulate empty handover
        when(handoverService.getHandoverByTeamAndDates(anyString(), any(), any()))
            .thenReturn(Optional.empty());

        // Simulate flagged incidents
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INC999999");
        incident.setTeam("DMC");

        when(handoverService.getFlaggedIncidentsForDateRange(anyString(), any(), any()))
            .thenReturn(List.of(incident));

        mockMvc.perform(get("/api/handover/retrieve")
                .param("team", "DMC")
                .param("startDate", LocalDateTime.now().toString())
                .param("endDate", LocalDateTime.now().plusHours(1).toString())
                .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isOk())
            .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.handover").value((Object) null))  // Correct way to check null in JSON
            .andExpect(jsonPath("$.flaggedIncidents").isArray())
            .andExpect(jsonPath("$.flaggedIncidents[0].incidentNumber").value("INC999999"));
    }




}

