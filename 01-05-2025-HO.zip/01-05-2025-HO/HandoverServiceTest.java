package com.example.demo;

import com.example.demo.model.HandoverTracker;
import com.example.demo.model.IncidentTracker;
import com.example.demo.model.User;
import com.example.demo.repository.HandoverTrackerRepository;
import com.example.demo.repository.IncidentTrackerRepository;
import com.example.demo.service.HandoverService;
import com.example.demo.service.UserService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Optional;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class HandoverServiceTest {

    @Mock
    private HandoverTrackerRepository handoverRepo;

    @Mock
    private UserService userService;
    
    @Mock
    private IncidentTrackerRepository incidentTrackerRepository;

    @InjectMocks
    private HandoverService handoverService;

    private User dummyUser;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        dummyUser = new User();
        dummyUser.setTeam("DMC");
        dummyUser.setLocation("SG");

        when(userService.getUserByUsername(anyString())).thenReturn(dummyUser);
    }

    // ✅ Already working tests

    @Test
    public void testGetHandoverHeading_USMorning() {
        String heading = handoverService.getHandoverHeading("SG");
        assertNotNull(heading);
        assertTrue(heading.contains("Handover"));
    }

    @Test
    public void testSaveOrUpdate_NewHandover() {
        LocalDateTime start = LocalDateTime.now().minusHours(1);
        LocalDateTime end = LocalDateTime.now().plusHours(1);
        String hoItem = "Test Handover Item";

        when(handoverRepo.findByTeamAndStartDateAndEndDate(any(), any(), any())).thenReturn(Optional.empty());
        when(handoverRepo.save(any())).thenAnswer(invocation -> invocation.getArgument(0));

        HandoverTracker saved = handoverService.saveOrUpdateHandover("DMC", start, end, hoItem, "tester");

        assertEquals("DMC", saved.getTeam());
        assertEquals(hoItem, saved.getHoItem());
        assertEquals("tester", saved.getUpdateUser());
    }

    @Test
    public void testGetHandoverByShift_ReturnsLatest() {
        LocalDateTime shiftStart = LocalDateTime.now().minusHours(1);
        LocalDateTime shiftEnd = LocalDateTime.now().plusHours(1);

        HandoverTracker h1 = new HandoverTracker();
        h1.setStartDate(shiftStart);
        h1.setEndDate(shiftEnd);

        when(handoverRepo.findHandoverByTeamAndShiftTime(eq("DMC"), any(), any()))
            .thenReturn(List.of(h1));

        Optional<HandoverTracker> result = handoverService.getHandoverByShift("DMC", shiftStart, shiftEnd);
        assertTrue(result.isPresent());
    }

    // ✅ NEW TESTS TO COVER RED METHODS

    @Test
    public void testGetLatestHandoverByUser() {
        HandoverTracker mockHandover = new HandoverTracker();
        mockHandover.setStartDate(LocalDateTime.now());

        when(handoverRepo.findLatestHandoverByTeam("DMC")).thenReturn(Optional.of(mockHandover));

        Optional<HandoverTracker> result = handoverService.getLatestHandoverByUser("testuser");

        assertTrue(result.isPresent());
    }

    @Test
    public void testGetHandoverByTeamAndDates_SameDay() {
        LocalDateTime start = LocalDateTime.now();
        LocalDateTime end = start.plusHours(1);
        HandoverTracker tracker = new HandoverTracker();

        when(handoverRepo.findByTeamAndStartDateAndEndDate("DMC", start, end))
            .thenReturn(Optional.of(tracker));

        Optional<HandoverTracker> result = handoverService.getHandoverByTeamAndDates("DMC", start, end);
        assertTrue(result.isPresent());
    }

    @Test
    public void testGetHandoverByTeamAndDates_InvalidRange() {
        LocalDateTime start = LocalDateTime.now();
        LocalDateTime end = start.plusDays(3); // Invalid (range too big)

        Optional<HandoverTracker> result = handoverService.getHandoverByTeamAndDates("DMC", start, end);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testGetHandoverByCurrentTime() {
        LocalDateTime now = LocalDateTime.now();
        HandoverTracker mock = new HandoverTracker();
        mock.setStartDate(now.minusHours(1));
        mock.setEndDate(now.plusHours(1));

        when(handoverRepo.findHandoverByTeamAndCurrentTime("DMC", now))
            .thenReturn(Optional.of(mock));

        Optional<HandoverTracker> result = handoverService.getHandoverByCurrentTime("DMC", now);
        assertTrue(result.isPresent());
    }

    @Test
    public void testSaveOrUpdateHandover_Overloaded() {
        LocalDateTime start = LocalDateTime.now();
        LocalDateTime end = start.plusHours(1);
        String hoItem = "Some Info";

        when(handoverRepo.findLatestHandoverByTeam("DMC")).thenReturn(Optional.empty());
        when(handoverRepo.save(any())).thenAnswer(inv -> inv.getArgument(0));

        HandoverTracker saved = handoverService.saveOrUpdateHandover("testuser", start, end, hoItem);
        assertNotNull(saved);
        assertEquals(hoItem, saved.getHoItem());
    }
    
    @Test
    public void testGetHandoverByShift_EmptyResult() {
        LocalDateTime start = LocalDateTime.now().minusHours(1);
        LocalDateTime end = LocalDateTime.now().plusHours(1);

        when(handoverRepo.findHandoverByTeamAndShiftTime(eq("DMC"), any(), any()))
            .thenReturn(List.of());

        Optional<HandoverTracker> result = handoverService.getHandoverByShift("DMC", start, end);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testGetHandoverByCurrentTime_NotFound() {
        LocalDateTime now = LocalDateTime.now();

        when(handoverRepo.findHandoverByTeamAndCurrentTime("DMC", now))
            .thenReturn(Optional.empty());

        Optional<HandoverTracker> result = handoverService.getHandoverByCurrentTime("DMC", now);
        assertTrue(result.isEmpty());
    }
    
    @Test
    public void testGetLatestHandoverByUser_NotFound() {
        when(handoverRepo.findLatestHandoverByTeam("DMC")).thenReturn(Optional.empty());

        Optional<HandoverTracker> result = handoverService.getLatestHandoverByUser("dummyuser");
        assertTrue(result.isEmpty());
    }

    @Test
    public void testGetHandoverHeading_OtherLocation() {
        String heading = handoverService.getHandoverHeading("IN");
        assertTrue(heading.toLowerCase().contains("handover"));
    }
    
    @Test
    public void testGetHandoverHeading_USLocation() {
        String heading = handoverService.getHandoverHeading("US");
        assertTrue(heading.toLowerCase().contains("handover"));
    }

    @Test
    public void testGetHandoverByTeamAndDates_NullTeam() {
        LocalDateTime start = LocalDateTime.now();
        LocalDateTime end = start.plusHours(1);

        Optional<HandoverTracker> result = handoverService.getHandoverByTeamAndDates(null, start, end);
        assertTrue(result.isEmpty());
    }
    
    
    @Test
    void testUpdateExistingHandover() {
        HandoverTracker existing = new HandoverTracker();
        existing.setId(1L);
        existing.setTeam("DMC");

        when(handoverRepo.findByTeamAndStartDateAndEndDate(anyString(), any(), any()))
        .thenReturn(Optional.of(existing));
        when(handoverRepo.save(any()))
        .thenAnswer(invocation -> invocation.getArgument(0));
               
        HandoverTracker updated = handoverService.saveOrUpdateHandover(
                "DMC",                
                LocalDateTime.now(),
                LocalDateTime.now().plusHours(12),
                "Handover update",
                "adminUser"
        );

        assertEquals("Handover update", updated.getHoItem());
        assertEquals("adminUser", updated.getUpdateUser());
        verify(handoverRepo).save(existing);
    }
    
    //new testing
    
    @Test
    public void testHandoverBetween0730And1930() {
        HandoverService service = new HandoverService();
        LocalTime time = LocalTime.of(10, 0); // between 7:30 and 19:30
        String heading = service.getHandoverHeading("US", time);
        assertEquals("Handover from US to SG", heading);
    }

    @Test
    public void testHandoverOutside0730And1930() {
        HandoverService service = new HandoverService();
        LocalTime time = LocalTime.of(22, 0); // outside window
        String heading = service.getHandoverHeading("US", time);
        assertEquals("Handover from SG to US", heading);
    }
    
    @Test
    void testGetHandoverHeading() {
        HandoverService service = new HandoverService();
        assertEquals("Handover from US to SG", service.getHandoverHeading("SG", LocalTime.of(10, 0)));
        assertEquals("Handover from SG to US", service.getHandoverHeading("SG", LocalTime.of(8, 0)));
    }
    
    //new test on 1st May 2025
    
    @Test
    void testGetFlaggedIncidentsForDateRange_shouldReturnIncidents() {
        // Arrange
        String team = "DMC";
        LocalDateTime startDate = LocalDateTime.now().minusHours(12);
        LocalDateTime endDate = LocalDateTime.now();

        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INC122221");
        incident.setTeam(team);
        incident.setFlagItem(true);

        List<IncidentTracker> expectedList = List.of(incident);

        when(incidentTrackerRepository.findFlaggedIncidentsByTeamAndDateRange(team, startDate, endDate))
            .thenReturn(expectedList);

        // Act
        List<IncidentTracker> result = handoverService.getFlaggedIncidentsForDateRange(team, startDate, endDate);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("INC122221", result.get(0).getIncidentNumber());

        // Verify interaction
        verify(incidentTrackerRepository, times(1))
            .findFlaggedIncidentsByTeamAndDateRange(team, startDate, endDate);
    }
    
    @Test
    void testGetHandoverByTeamAndDates_WhenDateRangeIsTooLarge_shouldReturnEmpty() {
        // Arrange
        String team = "DMC";
        LocalDateTime startDate = LocalDateTime.of(2025, 5, 1, 7, 30);
        LocalDateTime endDate = startDate.plusDays(2); // 2-day gap (invalid)

        // Act
        Optional<HandoverTracker> result = handoverService.getHandoverByTeamAndDates(team, startDate, endDate);

        // Assert
        assertTrue(result.isEmpty());

        // Make sure repository was never called
        verify(handoverRepo, never())
            .findByTeamAndStartDateAndEndDate(anyString(), any(), any());
    }
    
    @Test
    void testGetHandoverByTeamAndDates_WhenDateRangeIsValid_shouldReturnHandover() {
        // Arrange
        String team = "DMC";
        LocalDateTime startDate = LocalDateTime.of(2025, 5, 1, 7, 30);
        LocalDateTime endDate = startDate.plusHours(12); // Same-day (valid)

        HandoverTracker tracker = new HandoverTracker();
        tracker.setTeam(team);
        tracker.setHoItem("Test data");

        when(handoverRepo.findByTeamAndStartDateAndEndDate(team, startDate, endDate))
            .thenReturn(Optional.of(tracker));

        // Act
        Optional<HandoverTracker> result = handoverService.getHandoverByTeamAndDates(team, startDate, endDate);

        // Assert
        assertTrue(result.isPresent());
        assertEquals("Test data", result.get().getHoItem());

        verify(handoverRepo, times(1))
            .findByTeamAndStartDateAndEndDate(team, startDate, endDate);
    }
    
    
    @Test
    void testGetHandoverByTeamAndDates_WhenStartAfterEnd_shouldReturnEmpty() {
        String team = "DMC";
        LocalDateTime startDate = LocalDateTime.of(2025, 5, 2, 7, 30); // later date
        LocalDateTime endDate = LocalDateTime.of(2025, 5, 1, 7, 30);   // earlier date

        Optional<HandoverTracker> result = handoverService.getHandoverByTeamAndDates(team, startDate, endDate);

        assertTrue(result.isEmpty());
        verify(handoverRepo, never()).findByTeamAndStartDateAndEndDate(any(), any(), any());
    }
    
    @Test
    void testGetHandoverByTeamAndDates_WhenSameDay_shouldCallRepository() {
        String team = "DMC";
        LocalDateTime startDate = LocalDateTime.of(2025, 5, 1, 7, 30);
        LocalDateTime endDate = LocalDateTime.of(2025, 5, 1, 19, 30);

        HandoverTracker tracker = new HandoverTracker();
        tracker.setTeam(team);

        when(handoverRepo.findByTeamAndStartDateAndEndDate(team, startDate, endDate))
            .thenReturn(Optional.of(tracker));

        Optional<HandoverTracker> result = handoverService.getHandoverByTeamAndDates(team, startDate, endDate);

        assertTrue(result.isPresent());
        verify(handoverRepo).findByTeamAndStartDateAndEndDate(team, startDate, endDate);
    }
    
    @Test
    void testGetHandoverByTeamAndDates_WhenNextDay_shouldCallRepository() {
        String team = "DMC";
        LocalDateTime startDate = LocalDateTime.of(2025, 4, 30, 19, 30);
        LocalDateTime endDate = LocalDateTime.of(2025, 5, 1, 7, 30);

        HandoverTracker tracker = new HandoverTracker();
        tracker.setTeam(team);

        when(handoverRepo.findByTeamAndStartDateAndEndDate(team, startDate, endDate))
            .thenReturn(Optional.of(tracker));

        Optional<HandoverTracker> result = handoverService.getHandoverByTeamAndDates(team, startDate, endDate);

        assertTrue(result.isPresent());
        verify(handoverRepo).findByTeamAndStartDateAndEndDate(team, startDate, endDate);
    }



    
    


    
    


}
