package com.example.demo.controller;

import com.example.demo.model.ChatIncident;
import com.example.demo.service.ChatIncidentService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@WebMvcTest(ChatIncidentController.class)
@AutoConfigureMockMvc(addFilters = false)
public class ChatIncidentControllerOfficeTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ChatIncidentService chatIncidentService;

    @Test
    void testHandleChatQuery_Office() throws Exception {
        // Prepare request and mock data
        ChatIncidentController.ChatRequest chatRequest = new ChatIncidentController.ChatRequest();
        chatRequest.setQuery("network issue");

        ChatIncident incident = new ChatIncident();
        incident.setId(1L);
        incident.setCustomerExp("Test summary");
        incident.setAnalysis("Detailed explanation");

        when(chatIncidentService.searchIncidentsSqlFiltering("network issue", "DMC"))
                .thenReturn(Collections.singletonList(incident));

        ObjectMapper objectMapper = new ObjectMapper();
        String requestBody = objectMapper.writeValueAsString(chatRequest);

        MockHttpSession session = new MockHttpSession();
        session.setAttribute("team", "DMC");
        session.setAttribute("username", "testuser");
        session.setAttribute("role", "ADMIN");

        mockMvc.perform(post("/api/chat")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBody)
                .session(session))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.incidents[0].customerExp").value("Test summary"));
    }

    @Test
    void testHandleChatQuery_InternalServerError() throws Exception {
        ChatIncidentController.ChatRequest chatRequest = new ChatIncidentController.ChatRequest();
        chatRequest.setQuery("crash");

        ObjectMapper objectMapper = new ObjectMapper();
        String requestBody = objectMapper.writeValueAsString(chatRequest);

        MockHttpSession session = new MockHttpSession();
        session.setAttribute("team", "DMC");
        session.setAttribute("username", "testuser");
        session.setAttribute("role", "ADMIN");

        when(chatIncidentService.searchIncidentsSqlFiltering("crash", "DMC"))
                .thenThrow(new RuntimeException("Internal error"));

        mockMvc.perform(post("/api/chat")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBody)
                .session(session))
                .andExpect(status().isInternalServerError());
    }
}


====


@Test
    void testGetHandover_USUser() throws Exception {
    	Principal mockPrincipal = () -> "testuser";
        User mockUser = new User();
        mockUser.setLocation("US");
        mockUser.setTeam("DMC");

        when(userService.getUserByUsername("testuser")).thenReturn(mockUser);
        when(handoverService.getHandoverByShift(anyString(), any(), any())).thenReturn(Optional.empty());
        when(handoverService.getHandoverHeading("US")).thenReturn("US Shift");

        mockMvc.perform(get("/api/handover")
                .sessionAttr("team", "DMC")
                .sessionAttr("location", "US")
                .principal(mockPrincipal))
                .andExpect(status().isOk());
    }

    @Test
    void testGetHandover_SGUser() throws Exception {
    	Principal mockPrincipal = () -> "testuser";
        User mockUser = new User();
        mockUser.setLocation("SG");
        mockUser.setTeam("DMC");

        when(userService.getUserByUsername("testuser")).thenReturn(mockUser);
        when(handoverService.getHandoverByShift(anyString(), any(), any())).thenReturn(Optional.empty());
        when(handoverService.getHandoverHeading("SG")).thenReturn("SG Shift");

        mockMvc.perform(get("/api/handover")
                .sessionAttr("team", "DMC")
                .sessionAttr("location", "SG")
                .principal(mockPrincipal))
                .andExpect(status().isOk());
    }
    
    @Test
    void testGetHandover_USUser_MorningWindow() throws Exception {
    	Principal mockPrincipal = () -> "testuser";
        User mockUser = new User();
        mockUser.setLocation("US");
        mockUser.setTeam("DMC");

        when(userService.getUserByUsername("testuser")).thenReturn(mockUser);
        when(handoverService.getHandoverByShift(anyString(), any(), any())).thenReturn(Optional.empty());
        when(handoverService.getHandoverHeading("US")).thenReturn("US Shift");

        // Simulate 6 AM New York time
        LocalDateTime mockTime = LocalDateTime.of(2025, 4, 10, 6, 0);
        LocalDateTime now = LocalDateTime.now(ZoneId.of("America/New_York"));

        mockMvc.perform(get("/api/handover")
                .sessionAttr("team", "DMC")
                .sessionAttr("location", "US")
                .principal(mockPrincipal))
                .andExpect(status().isOk());
    }

    @Test
    void testGetHandover_SGUser_EarlyMorning() throws Exception {
    	Principal mockPrincipal = () -> "testuser";
        User mockUser = new User();
        mockUser.setLocation("SG");
        mockUser.setTeam("DMC");

        when(userService.getUserByUsername("testuser")).thenReturn(mockUser);
        when(handoverService.getHandoverByShift(anyString(), any(), any())).thenReturn(Optional.empty());
        when(handoverService.getHandoverHeading("SG")).thenReturn("SG Shift");

        // Simulate 5 AM SG time (edge of SG early morning logic)
        mockMvc.perform(get("/api/handover")
                .sessionAttr("team", "DMC")
                .sessionAttr("location", "SG")
                .principal(mockPrincipal))
                .andExpect(status().isOk());
    }
	
	
	
====

@Test
    void testOpenDashboard_Other() throws Exception {
        mockMvc.perform(get("/dashboard")
                .sessionAttr("team", "DMC")
                .sessionAttr("location", "SG")
                .sessionAttr("role", "OTHERS")
                .principal(mockPrincipal))
                .andExpect(status().isOk())
                .andExpect(view().name("search"));
    }	