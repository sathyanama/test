package com.example.demo.service;

import com.example.demo.model.IncidentTracker;
import com.example.demo.repository.IncidentTrackerRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.time.LocalDateTime;
import java.time.Year;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class IncidentTrackerServiceTest {

    @Mock
    private IncidentTrackerRepository incidentTrackerRepository;

    @InjectMocks
    private IncidentTrackerService incidentTrackerService;

    @Mock
    private HttpServletRequest request;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateIncident_successful() {
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INC1001");
        incident.setTeam("DMC");

        when(incidentTrackerRepository.findByIncidentNumberAndTeam("INC1001", "DMC"))
                .thenReturn(Optional.empty());
        when(incidentTrackerRepository.save(incident)).thenReturn(incident);

        IncidentTracker saved = incidentTrackerService.createIncident(incident);

        assertEquals("INC1001", saved.getIncidentNumber());
        verify(incidentTrackerRepository).save(incident);
    }

    @Test
    public void testCreateIncident_whenAlreadyExists_shouldThrowException() {
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INC1002");
        incident.setTeam("DMC");

        when(incidentTrackerRepository.findByIncidentNumberAndTeam("INC1002", "DMC"))
                .thenReturn(Optional.of(new IncidentTracker()));

        assertThrows(IllegalArgumentException.class, () -> {
            incidentTrackerService.createIncident(incident);
        });

        verify(incidentTrackerRepository, never()).save(any());
    }
    
    @Test
    public void testUpdateIncident_successful() {
 
        Authentication auth = mock(Authentication.class);
        when(auth.getName()).thenReturn("testuser");

        SecurityContext securityContext = mock(SecurityContext.class);
        when(securityContext.getAuthentication()).thenReturn(auth);
        SecurityContextHolder.setContext(securityContext);

        IncidentTracker existing = new IncidentTracker();
        existing.setId(1L);
        existing.setIncidentNumber("INC2001");
        existing.setAnalysis("Old analysis");

        IncidentTracker updated = new IncidentTracker();
        updated.setId(1L);
        updated.setIncidentNumber("INC2001");
        updated.setAnalysis("Updated analysis");

        when(incidentTrackerRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(incidentTrackerRepository.save(any())).thenReturn(updated);

        HttpServletRequest request = mock(HttpServletRequest.class);
        IncidentTracker result = incidentTrackerService.updateIncident(updated);
        //IncidentTracker result = incidentTrackerService.updateIncident(updated,request);

        assertEquals("Updated analysis", result.getAnalysis());
        verify(incidentTrackerRepository).save(existing);
    }
    
    @Test
    public void testFindById_whenFound_shouldReturnIncident() {
        IncidentTracker incident = new IncidentTracker();
        incident.setId(10L);
        incident.setIncidentNumber("INC1010");

        when(incidentTrackerRepository.findById(10L)).thenReturn(Optional.of(incident));

        Optional<IncidentTracker> result = incidentTrackerService.findById(10L);

        assertTrue(result.isPresent());
        assertEquals("INC1010", result.get().getIncidentNumber());
    }

    @Test
    public void testFindById_whenNotFound_shouldReturnEmpty() {
        when(incidentTrackerRepository.findById(999L)).thenReturn(Optional.empty());

        Optional<IncidentTracker> result = incidentTrackerService.findById(999L);

        assertFalse(result.isPresent());
    }

    @Test
    public void testGetIncidentByNumberAndTeam_whenFound() {
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INC3001");
        incident.setTeam("DMC");

        when(incidentTrackerRepository.findByIncidentNumberAndTeam("INC3001", "DMC"))
                .thenReturn(Optional.of(incident));

        Optional<IncidentTracker> result = incidentTrackerService.getIncidentByNumberAndTeam("INC3001", "DMC");

        assertTrue(result.isPresent());
        assertEquals("DMC", result.get().getTeam());
    }
    
    @Test
    public void testGetIncidentByNumberAndTeam_whenNotFound() {
        when(incidentTrackerRepository.findByIncidentNumberAndTeam("INC404", "DMC"))
                .thenReturn(Optional.empty());

        Optional<IncidentTracker> result = incidentTrackerService.getIncidentByNumberAndTeam("INC404", "DMC");

        assertFalse(result.isPresent());
    }
    
    @Test
    public void testSearchPaginatedWithoutTeam_withQuery() {
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INC7777");

        List<IncidentTracker> incidents = List.of(incident);
        Page<IncidentTracker> mockPage = new PageImpl<>(incidents);

        // ✅ Fix: match any Pageable, not exact one
        when(incidentTrackerRepository.searchByQueryWithoutTeam(eq("network"), any(Pageable.class)))
                .thenReturn(mockPage);

        Page<IncidentTracker> result = incidentTrackerService.searchPaginatedWithoutTeam("network", 1, 10);

        assertEquals(1, result.getTotalElements());
        assertEquals("INC7777", result.getContent().get(0).getIncidentNumber());
        verify(incidentTrackerRepository).searchByQueryWithoutTeam(eq("network"), any(Pageable.class));
    }


    @Test
    public void testFindLast50RecordsWithoutTeam() {
        IncidentTracker incident = new IncidentTracker();
        incident.setIncidentNumber("INC5050");

        List<IncidentTracker> incidents = List.of(incident);
        Page<IncidentTracker> mockPage = new PageImpl<>(incidents);

        when(incidentTrackerRepository.findByCreateDatetimeWithoutTeam(any(LocalDateTime.class), any(Pageable.class)))
                .thenReturn(mockPage);

        Page<IncidentTracker> result = incidentTrackerService.findLast50RecordsWithoutTeam(1, 10);

        assertEquals(1, result.getTotalElements());
        assertEquals("INC5050", result.getContent().get(0).getIncidentNumber());

        verify(incidentTrackerRepository).findByCreateDatetimeWithoutTeam(any(LocalDateTime.class), any(Pageable.class));
    }






    // More tests for updateIncident, findById, getIncidentByNumberAndTeam, searchPaginatedWithoutTeam etc. will be added
}
