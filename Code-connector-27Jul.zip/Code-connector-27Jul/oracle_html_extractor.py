import oracledb
import os
from datetime import datetime
import html

def setup_kerberos_connection():
    """
    Setup Kerberos authentication for Oracle database connection
    Make sure you have valid Kerberos ticket (kinit username@DOMAIN)
    """
    try:
        # Enable thick mode for advanced features like Kerberos
        oracledb.init_oracle_client()
        
        # Connection string for Kerberos authentication
        # Replace with your actual database details
        dsn = "your_oracle_host:1521/your_service_name"
        
        # Connect using Kerberos authentication
        connection = oracledb.connect(
            dsn=dsn,
            mode=oracledb.AUTH_MODE_KERBEROS
        )
        
        print("Successfully connected to Oracle database using Kerberos")
        return connection
        
    except Exception as e:
        print(f"Error connecting to database: {e}")
        return None

def fetch_incident_data(connection):
    """
    Fetch specified columns from incident_tracker table
    """
    try:
        cursor = connection.cursor()
        
        # SQL query to fetch required columns
        query = """
        SELECT 
            incident_number,
            customer_exp,
            analysis,
            flow,
            alert_name,
            splunk_queries
        FROM incident_tracker
        ORDER BY incident_number
        """
        
        cursor.execute(query)
        
        # Fetch all results
        results = cursor.fetchall()
        
        # Get column names
        columns = [desc[0] for desc in cursor.description]
        
        cursor.close()
        
        print(f"Retrieved {len(results)} records from incident_tracker")
        return results, columns
        
    except Exception as e:
        print(f"Error fetching data: {e}")
        return None, None

def create_individual_html_files(data, columns, output_dir="incident_html_files"):
    """
    Create individual HTML files for each incident record using template format
    """
    try:
        # Create output directory if it doesn't exist
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            print(f"Created directory: {output_dir}")
        
        # HTML template with placeholders
        html_template = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Incident {incident_number}</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }}
        .container {{
            max-width: 1000px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        h1 {{
            color: #333;
            text-align: center;
            border-bottom: 2px solid #007bff;
            padding-bottom: 10px;
        }}
        .metadata {{
            text-align: center;
            color: #666;
            margin-bottom: 20px;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }}
        th, td {{
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
            vertical-align: top;
        }}
        th {{
            background-color: #007bff;
            color: white;
            font-weight: bold;
        }}
        .incident-number {{
            font-weight: bold;
            color: #007bff;
        }}
        .splunk-queries {{
            font-family: 'Courier New', monospace;
            background-color: #f8f9fa;
            padding: 8px;
            border-radius: 3px;
            word-wrap: break-word;
            max-width: 400px;
        }}
        .field-content {{
            word-wrap: break-word;
            max-width: 300px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Incident Details</h1>
        <div class="metadata">
            Generated on: {generated_date}
        </div>
        
        <table border="1">
            <tr>
                <th>Incident Number</th>
                <th>Customer Experience</th>
                <th>Analysis</th>
                <th>Flow</th>
                <th>Alert Name</th>
                <th>Splunk Queries</th>
            </tr>
            <tr>
                <td class="incident-number">{incident_number}</td>
                <td class="field-content">{customer_exp}</td>
                <td class="field-content">{analysis}</td>
                <td class="field-content">{flow}</td>
                <td class="field-content">{alert_name}</td>
                <td class="splunk-queries">{splunk_queries}</td>
            </tr>
        </table>
    </div>
</body>
</html>"""
        
        created_files = []
        
        for i, row in enumerate(data):
            # Prepare data for template
            incident_number = str(row[0]) if row[0] is not None else f"N/A"
            customer_exp = html.escape(str(row[1]) if row[1] is not None else "No information available")
            analysis = html.escape(str(row[2]) if row[2] is not None else "No analysis provided")
            flow = html.escape(str(row[3]) if row[3] is not None else "No flow information")
            alert_name = html.escape(str(row[4]) if row[4] is not None else "No alert name")
            splunk_queries = html.escape(str(row[5]) if row[5] is not None else "No Splunk queries available")
            generated_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
            # Generate HTML using template.format()
            html_content = html_template.format(
                incident_number=incident_number,
                customer_exp=customer_exp,
                analysis=analysis,
                flow=flow,
                alert_name=alert_name,
                splunk_queries=splunk_queries,
                generated_date=generated_date
            )
            
            # Create safe filename
            safe_incident_num = "".join(c for c in incident_number if c.isalnum() or c in ('-', '_'))
            if safe_incident_num == "N_A" or not safe_incident_num:
                safe_incident_num = f"incident_{i+1}"
            
            filename = f"{output_dir}/incident_{safe_incident_num}.html"
            
            # Write individual HTML file
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(html_content)
            
            created_files.append(filename)
        
        print(f"Created {len(created_files)} individual HTML files in '{output_dir}' directory")
        return created_files
        
    except Exception as e:
        print(f"Error creating individual HTML files: {e}")
        return None

def upload_html_files_to_llm(html_files):
    """
    Function to upload multiple HTML files to LLM
    This is a placeholder - you'll need to implement based on your specific LLM API
    """
    try:
        uploaded_files = []
        
        for html_file in html_files:
            # Read the HTML file
            with open(html_file, 'r', encoding='utf-8') as f:
                html_content = f.read()
            
            print(f"Processing '{html_file}' for LLM upload")
            print(f"File size: {len(html_content)} characters")
            
            # TODO: Implement your specific LLM upload logic here
            # Examples:
            # - OpenAI API
            # - Anthropic Claude API
            # - Azure OpenAI
            # - Custom LLM endpoint
            
            """
            Example for OpenAI API:
            
            import openai
            
            client = openai.OpenAI(api_key="your-api-key")
            
            response = client.files.create(
                file=open(html_file, "rb"),
                purpose="assistants"
            )
            
            uploaded_files.append({
                'local_file': html_file,
                'uploaded_id': response.id
            })
            
            print(f"File uploaded with ID: {response.id}")
            """
            
            # Placeholder for successful upload
            uploaded_files.append({
                'local_file': html_file,
                'status': 'ready_for_upload'
            })
        
        print(f"Processed {len(uploaded_files)} files for LLM upload")
        print("Note: Implement your specific LLM upload logic in the upload_html_files_to_llm() function")
        return uploaded_files
        
    except Exception as e:
        print(f"Error uploading files to LLM: {e}")
        return None

def main():
    """
    Main function to orchestrate the entire process
    """
    print("Starting incident tracker data extraction...")
    
    # Step 1: Setup Kerberos connection
    connection = setup_kerberos_connection()
    if not connection:
        print("Failed to establish database connection")
        return
    
    try:
        # Step 2: Fetch data
        data, columns = fetch_incident_data(connection)
        if not data:
            print("No data retrieved")
            return
        
        # Step 3: Create individual HTML files
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_directory = f"incident_html_files_{timestamp}"
        
        created_files = create_individual_html_files(data, columns, output_directory)
        if not created_files:
            print("Failed to create HTML files")
            return
        
        # Step 4: Upload all HTML files to LLM
        upload_results = upload_html_files_to_llm(created_files)
        if upload_results:
            print("Process completed successfully!")
            print(f"Created {len(created_files)} individual HTML files")
            print(f"Files location: {output_directory}/")
        else:
            print("HTML files created but upload to LLM failed")
            
    finally:
        # Close database connection
        connection.close()
        print("Database connection closed")

if __name__ == "__main__":
    # Prerequisites check
    print("Prerequisites:")
    print("1. Ensure you have a valid Kerberos ticket (run: kinit username@DOMAIN)")
    print("2. Oracle Instant Client should be installed")
    print("3. Update database connection details in setup_kerberos_connection()")
    print("4. Implement LLM upload logic in upload_to_llm() function")
    print("-" * 60)
    
    main()
