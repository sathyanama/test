import oracledb
import os
import zipfile

# Step 1: Connect to OracleDB with Kerberos
dsn = "your_db_host:1521/your_service_name"  # Update with your DB details
connection = oracledb.connect(
    dsn=dsn,
    mode=oracledb.AUTH_MODE_KERBEROS
)

cursor = connection.cursor()
cursor.execute("""
    SELECT incident_number, customer_exp, analysis, flow, alert_name, splunk_queries
    FROM incident_tracker
""")
rows = cursor.fetchall()
cursor.close()
connection.close()

# Step 2: Generate HTML files
html_template = """
<html>
<head><title>Incident {incident_number}</title></head>
<body>
    <table border="1">
        <tr>
            <th>Incident Number</th>
            <th>Customer Exp</th>
            <th>Analysis</th>
            <th>Flow</th>
            <th>Alert Name</th>
            <th>Splunk Queries</th>
        </tr>
        <tr>
            <td>{incident_number}</td>
            <td>{customer_exp}</td>
            <td>{analysis}</td>
            <td>{flow}</td>
            <td>{alert_name}</td>
            <td>{splunk_queries}</td>
        </tr>
    </table>
</body>
</html>
"""

output_dir = "incident_htmls"
os.makedirs(output_dir, exist_ok=True)

html_files = []

for row in rows:
    incident_number, customer_exp, analysis, flow, alert_name, splunk_queries = row
    html_content = html_template.format(
        incident_number=incident_number,
        customer_exp=customer_exp,
        analysis=analysis,
        flow=flow,
        alert_name=alert_name,
        splunk_queries=splunk_queries
    )
    filename = f"incident_{incident_number}.html"
    filepath = os.path.join(output_dir, filename)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(html_content)
    html_files.append(filepath)

# Step 3: Zip all HTML files
zip_filename = "incident_htmls.zip"
with zipfile.ZipFile(zip_filename, "w", zipfile.ZIP_DEFLATED) as zipf:
    for file in html_files:
        zipf.write(file, arcname=os.path.basename(file))

print(f"All HTML files zipped into: {zip_filename}")
