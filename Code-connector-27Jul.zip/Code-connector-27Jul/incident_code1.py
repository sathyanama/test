import oracledb
import os
from datetime import datetime
import html

def setup_kerberos_connection():
    """
    Setup Kerberos authentication for Oracle database connection
    Make sure you have valid Kerberos ticket (kinit username@DOMAIN)
    """
    try:
        # Enable thick mode for advanced features like Kerberos
        oracledb.init_oracle_client()
        
        # Connection string for Kerberos authentication
        # Replace with your actual database details
        dsn = "your_oracle_host:1521/your_service_name"
        
        # Connect using Kerberos authentication
        connection = oracledb.connect(
            dsn=dsn,
            mode=oracledb.AUTH_MODE_KERBEROS
        )
        
        print("Successfully connected to Oracle database using Kerberos")
        return connection
        
    except Exception as e:
        print(f"Error connecting to database: {e}")
        return None

def fetch_incident_data(connection):
    """
    Fetch specified columns from incident_tracker table
    """
    try:
        cursor = connection.cursor()
        
        # SQL query to fetch required columns
        query = """
        SELECT 
            incident_number,
            customer_exp,
            analysis,
            flow,
            alert_name,
            splunk_queries
        FROM incident_tracker
        ORDER BY incident_number
        """
        
        cursor.execute(query)
        
        # Fetch all results
        results = cursor.fetchall()
        
        # Get column names
        columns = [desc[0] for desc in cursor.description]
        
        cursor.close()
        
        print(f"Retrieved {len(results)} records from incident_tracker")
        return results, columns
        
    except Exception as e:
        print(f"Error fetching data: {e}")
        return None, None

def create_individual_html_files(data, columns, output_dir="incident_html_files"):
    """
    Create individual HTML files for each incident record
    """
    try:
        # Create output directory if it doesn't exist
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            print(f"Created directory: {output_dir}")
        
        created_files = []
        
        for i, row in enumerate(data):
            # Get incident number for filename, fallback to index if None
            incident_num = str(row[0]) if row[0] is not None else f"incident_{i+1}"
            # Clean filename (remove special characters)
            safe_incident_num = "".join(c for c in incident_num if c.isalnum() or c in ('-', '_'))
            
            filename = f"{output_dir}/incident_{safe_incident_num}.html"
            
            # Create HTML content for individual incident
            html_content = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Incident {incident_num} Details</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
            line-height: 1.6;
        }}
        .container {{
            max-width: 800px;
            margin: 0 auto;
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .header {{
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 3px solid #007bff;
            padding-bottom: 15px;
        }}
        .incident-title {{
            color: #007bff;
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 5px;
        }}
        .generated-date {{
            color: #666;
            font-size: 14px;
        }}
        .field-container {{
            margin-bottom: 25px;
            padding: 15px;
            border-left: 4px solid #007bff;
            background-color: #f8f9fa;
            border-radius: 0 5px 5px 0;
        }}
        .field-label {{
            font-weight: bold;
            color: #333;
            font-size: 16px;
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}
        .field-value {{
            color: #555;
            font-size: 14px;
            word-wrap: break-word;
            white-space: pre-wrap;
        }}
        .splunk-queries {{
            font-family: 'Courier New', monospace;
            background-color: #2d3748;
            color: #e2e8f0;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
        }}
        .incident-number {{
            font-size: 18px;
            font-weight: bold;
            color: #007bff;
        }}
        .empty-field {{
            color: #999;
            font-style: italic;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="incident-title">Incident Details</div>
            <div class="generated-date">Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>
        </div>
        
        <div class="field-container">
            <div class="field-label">Incident Number</div>
            <div class="field-value incident-number">{html.escape(str(row[0]) if row[0] is not None else "N/A")}</div>
        </div>
        
        <div class="field-container">
            <div class="field-label">Customer Experience</div>
            <div class="field-value">{html.escape(str(row[1]) if row[1] is not None and str(row[1]).strip() else "No information available") if row[1] is not None else '<span class="empty-field">No information available</span>'}</div>
        </div>
        
        <div class="field-container">
            <div class="field-label">Analysis</div>
            <div class="field-value">{html.escape(str(row[2]) if row[2] is not None and str(row[2]).strip() else "No analysis provided") if row[2] is not None else '<span class="empty-field">No analysis provided</span>'}</div>
        </div>
        
        <div class="field-container">
            <div class="field-label">Flow</div>
            <div class="field-value">{html.escape(str(row[3]) if row[3] is not None and str(row[3]).strip() else "No flow information") if row[3] is not None else '<span class="empty-field">No flow information</span>'}</div>
        </div>
        
        <div class="field-container">
            <div class="field-label">Alert Name</div>
            <div class="field-value">{html.escape(str(row[4]) if row[4] is not None and str(row[4]).strip() else "No alert name") if row[4] is not None else '<span class="empty-field">No alert name</span>'}</div>
        </div>
        
        <div class="field-container">
            <div class="field-label">Splunk Queries</div>
            <div class="field-value">
                <div class="splunk-queries">{html.escape(str(row[5]) if row[5] is not None and str(row[5]).strip() else "No Splunk queries available") if row[5] is not None else "No Splunk queries available"}</div>
            </div>
        </div>
    </div>
</body>
</html>
"""

            # Write individual HTML file
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(html_content)
            
            created_files.append(filename)
        
        print(f"Created {len(created_files)} individual HTML files in '{output_dir}' directory")
        return created_files
        
    except Exception as e:
        print(f"Error creating individual HTML files: {e}")
        return None

def upload_html_files_to_llm(html_files):
    """
    Function to upload multiple HTML files to LLM
    This is a placeholder - you'll need to implement based on your specific LLM API
    """
    try:
        uploaded_files = []
        
        for html_file in html_files:
            # Read the HTML file
            with open(html_file, 'r', encoding='utf-8') as f:
                html_content = f.read()
            
            print(f"Processing '{html_file}' for LLM upload")
            print(f"File size: {len(html_content)} characters")
            
            # TODO: Implement your specific LLM upload logic here
            # Examples:
            # - OpenAI API
            # - Anthropic Claude API
            # - Azure OpenAI
            # - Custom LLM endpoint
            
            """
            Example for OpenAI API:
            
            import openai
            
            client = openai.OpenAI(api_key="your-api-key")
            
            response = client.files.create(
                file=open(html_file, "rb"),
                purpose="assistants"
            )
            
            uploaded_files.append({
                'local_file': html_file,
                'uploaded_id': response.id
            })
            
            print(f"File uploaded with ID: {response.id}")
            """
            
            # Placeholder for successful upload
            uploaded_files.append({
                'local_file': html_file,
                'status': 'ready_for_upload'
            })
        
        print(f"Processed {len(uploaded_files)} files for LLM upload")
        print("Note: Implement your specific LLM upload logic in the upload_html_files_to_llm() function")
        return uploaded_files
        
    except Exception as e:
        print(f"Error uploading files to LLM: {e}")
        return None

def main():
    """
    Main function to orchestrate the entire process
    """
    print("Starting incident tracker data extraction...")
    
    # Step 1: Setup Kerberos connection
    connection = setup_kerberos_connection()
    if not connection:
        print("Failed to establish database connection")
        return
    
    try:
        # Step 2: Fetch data
        data, columns = fetch_incident_data(connection)
        if not data:
            print("No data retrieved")
            return
        
        # Step 3: Create HTML file
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        html_filename = f"incident_report_{timestamp}.html"
        
        created_file = create_html_file(data, columns, html_filename)
        if not created_file:
            print("Failed to create HTML file")
            return
        
        # Step 4: Upload to LLM
        upload_success = upload_to_llm(created_file)
        if upload_success:
            print("Process completed successfully!")
        else:
            print("HTML file created but upload to LLM failed")
            
    finally:
        # Close database connection
        connection.close()
        print("Database connection closed")

if __name__ == "__main__":
    # Prerequisites check
    print("Prerequisites:")
    print("1. Ensure you have a valid Kerberos ticket (run: kinit username@DOMAIN)")
    print("2. Oracle Instant Client should be installed")
    print("3. Update database connection details in setup_kerberos_connection()")
    print("4. Implement LLM upload logic in upload_to_llm() function")
    print("-" * 60)
    
    main()