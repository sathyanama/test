import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from splunklib.client import Service
import json
import time
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import pandas as pd

# ========== SPLUNK CONFIG ==========
with open("splunk_config.json") as f:
    SPLUNK_CONFIG = json.load(f)

# ========== CONTEXT MEMORY ==========
context = {
    "last_intent": "",
    "time_range": "15m",
    "last_query": ""
}

# ========== SPLUNK QUERY RUNNER ==========
def run_splunk_query(query):
    service = Service(**SPLUNK_CONFIG)
    service.login()
    job = service.jobs.create(query)

    timeout = 60
    start_time = time.time()
    while not job.is_done():
        if time.time() - start_time > timeout:
            print("Timeout: Splunk job took too long.")
            return []
        time.sleep(1)

    results_stream = job.results(output_mode="json")
    results_json = json.load(results_stream)
    logs = results_json.get('results', [])
    return logs

# ========== MISTRAL LOADER ==========
print("Loading Mistral...")
model_path = "./models/mistral-7b-instruct"

tokenizer = AutoTokenizer.from_pretrained(
    model_path,
    use_fast=False,
    trust_remote_code=True
)

# Use float16 only if GPU is available; fallback to float32 for CPU
torch_dtype = torch.float16 if torch.cuda.is_available() else torch.float32

model = AutoModelForCausalLM.from_pretrained(
    model_path,
    torch_dtype=torch_dtype,
    trust_remote_code=True
).eval()

device = "cuda" if torch.cuda.is_available() else "cpu"
model.to(device)

# ========== TIME UTILS ==========
def is_time_update(user_input):
    import re
    return bool(re.match(r'^(now\s*)?(make it|try|do)\s*\d+\s*(m|mins|minutes|h|hrs|hours)$', user_input.lower()))

def extract_time_range(text):
    import re
    match = re.search(r'(\d+)\s*(m|mins|minutes|h|hrs|hours)', text.lower())
    if match:
        val, unit = match.groups()
        return f"{val}{'m' if 'm' in unit else 'h'}"
    return "15m"

# ========== MISTRAL CHAT ==========
def mistral_generate(prompt, max_tokens=400):
    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    print("Generating...")
    start_time = time.time()
    outputs = model.generate(
        **inputs,
        max_new_tokens=max_tokens,
        do_sample=False,
        pad_token_id=tokenizer.eos_token_id  # ✅ suppress pad_token warning
    )
    duration = time.time() - start_time
    print(f"Response generated in {duration:.2f} seconds.")
    return tokenizer.decode(outputs[0], skip_special_tokens=True).strip()


# ========== PROMPT GENERATORS ==========
def generate_query_prompt(user_input, query_id):
    index_default = SPLUNK_CONFIG.get("index", "index=cfs_digital_88082")
    sourcetype_default = SPLUNK_CONFIG.get("sourcetype", "sourcetype=*httpd*")

    url_mapping_instructions = """
    How to interpret user requests:
    - If the user mentions a service like \"payment\", \"bill pay\", \"user login\", or \"app data\",
      map it to: urlPath="*payment*", urlPath="*bill*pay*", urlPath="*user*login*", urlPath="*app*data*"
      and requestUrl="*payment*", etc. where applicable
    """

    prompts = {
        1: f'''
        You are a Splunk query expert.
        Create a query using:
        - {index_default}
        - {sourcetype_default}
        - Normalize urlPath using eval+replace:
          - replace urlPath: "/?!v|1[^/]*\\d[^/]*" with "/X"
          - replace urlPath: "::[a-zA-Z0-9]*" with "::*"
          - replace urlPath: "/\\d+" with "/*"
        - {url_mapping_instructions}
        - Use stats count, success/failure counts by urlPath and podId
        - Add fields like avg(responseTimeMs), percentiles, and error codes
        - Add evals to calculate FP, AR, P50, P95, P99
        - Use earliest=-{context['time_range']}
        - Final output: fields podId, urlPath, Volume, Success, Fail, FP, AR, P95, 4XX, 5XX, etc.
        Return query only.
        User: "{user_input}"
        ''',

        2: f'''
        Create a Splunk query for:
        - index=cfs_digital_88082
        - sourcetype=*svc*_st
        - Match requestUrl using:
          - If the user mentions a service like "payment", "bill pay", "user login", or "app data",
            map it to: requestUrl="*payment*", "*bill*pay*", "*user*login*", "*app*data*"
        - loglevel=ERROR
        - Show top messages (first 210 chars) grouped by count
        - Uses earliest=-{context['time_range']}
        Return query only.
        User: "{user_input}"
        ''',

        3: f'''
        Generate a Splunk timechart query:
        - index=cfs_digital_88082 sourcetype=*httpd*
        - {url_mapping_instructions}
        - earliest=-{context['time_range']}
        - Use: | timechart span=5m count by httpCode
        Return full query.
        User: "{user_input}"
        ''',

        4: f'''
        Generate a Splunk query:
        - index=cfs_digital_88082 sourcetype=*httpd*
        - {url_mapping_instructions}
        - earliest=-{context['time_range']}
        - Use: | stats count by channelId
        Return query only.
        User: "{user_input}"
        ''',

        5: f'''
        Generate a Splunk query:
        - index=cfs_digital_88082 sourcetype=*httpd*
        - {url_mapping_instructions}
        - earliest=-{context['time_range']}
        - Use: | stats count by Env
        User: "{user_input}"
        ''',

        6: f'''
        Create a Splunk query with lookups:
        - index=cfs_digital_88082 sourcetype=*httpd*
        - {url_mapping_instructions}
        - Fields: _time, Aggregator, httpCode, xForwardfor
        - Apply lookup IPtoASN and iplocation
        - Stats by Aggregator, ASN, ISP, Region, Country, httpCode
        - earliest=-{context['time_range']}
        User: "{user_input}"
        ''',

        7: f'''
        Generate a Splunk query:
        - index=cfs_digital_trace_88082
        - Match user keyword in raw log text using wildcard (e.g. *payment*, *bill*pay*, *app*data*)
        - Add condition: message.sc > 499
        - Use: | stats count by message.seg
        - earliest=-{context['time_range']}
        Return query only.
        User: "{user_input}"
        '''
    }
    return prompts[query_id]

# ========== FORMAT RESULTS ==========
def print_results_table(title, results):
    if not results:
        print(f"{title}: No results found.")
        return
    df = pd.DataFrame(results)
    print(f"\n{title} [{len(df)} rows]:")
    print(df.to_markdown(index=False))

# ========== PARALLEL QUERY EXECUTION ==========
def run_all_queries(user_input):
    print(f"\nRunning all Splunk queries for: {user_input} | Time range: {context['time_range']}\n")

    def process_query(qid):
        try:
            prompt = generate_query_prompt(user_input, qid)
            start_time = time.time()
            raw_response = mistral_generate(prompt, max_tokens=200)
            raw_response = raw_response.replace("[INST]", "").replace("[/INST]", "").strip()
            generation_time = time.time() - start_time

            splunk_query = ""
            for line in raw_response.splitlines():
                if line.strip().lower().startswith("search"):
                    splunk_query = line.strip()
                    break

            splunk_query = splunk_query \
                .replace('“', '"').replace('”', '"') \
                .replace('‘', '"').replace('’', '"') \
                .replace('–', '-') \
                .replace('`', '"')

            if not splunk_query.lower().startswith("search"):
                splunk_query = "search " + splunk_query

            context["last_query"] = splunk_query

            print(f"\n[Query {qid}] Splunk Query:\n{splunk_query}")
            print(f"[Query {qid}] Fetching logs...")
            splunk_start = time.time()
            logs = run_splunk_query(splunk_query)
            splunk_duration = time.time() - splunk_start
            print(f"[Query {qid}] Splunk query executed in {splunk_duration:.2f} seconds.")

            print(f"[Query {qid}] Retrieved {len(logs)} log records.")
            print_results_table(f"[Query {qid}] Results", logs)

            return (qid, logs)

        except Exception as e:
            print(f"[Query {qid}] Failed: {str(e)}")
            return (qid, [])

    with ThreadPoolExecutor(max_workers=7) as executor:
        futures = [executor.submit(process_query, qid) for qid in range(1, 8)]

    all_results = {qid: logs for qid, logs in (f.result() for f in futures)}

    print("\nSummary of Results:")
    for qid, logs in all_results.items():
        print(f"Query {qid}: {len(logs)} rows")
    return all_results

# ========== MAIN ==========
if __name__ == "__main__":
    while True:
        user_input = input("\nYour request (type 'quit' to exit): ").strip()
        if user_input.lower() == 'quit':
            break
        if is_time_update(user_input):
            context['time_range'] = extract_time_range(user_input)
            print(f"Time range updated to: {context['time_range']}")
        else:
            run_all_queries(user_input)
