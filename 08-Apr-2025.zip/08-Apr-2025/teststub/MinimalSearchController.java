package com.example.demo.teststub;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
public class MinimalSearchController {

    @GetMapping("/mock/search")
    public List<MinimalIncidentTracker> getMockResults() {
        MinimalIncidentTracker tracker = new MinimalIncidentTracker("INC001", "Mock Alert", "Sample Analysis");
        return List.of(tracker);
    }
}
