package com.example.demo.teststub;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.List;

@RestController
public class SearchSafeController_w {

    @GetMapping("/search/safe")
    public List<IncidentTrackerStub> getSafe() {
        IncidentTrackerStub tracker = new IncidentTrackerStub("INC001", "Test Alert", "Test Analysis");
        return List.of(tracker);
    }
    
    @GetMapping("/search/last50")
    public List<SafeIncidentTracker> getLast50(@RequestParam("page") int page,
                                               @RequestParam("size") int size) {
        return List.of(new SafeIncidentTracker("INC001", "Test Alert", "Analysis A"));
    }

    @GetMapping("/search/query")
    public List<SafeIncidentTracker> querySearch(@RequestParam("query") String query,
                                                 @RequestParam("page") int page,
                                                 @RequestParam("size") int size) {
        return List.of(new SafeIncidentTracker("INC002", "Query Alert", "Analysis B"));
    }

    @GetMapping("/search/empty")
    public List<SafeIncidentTracker> emptySearch() {
        return Collections.emptyList();
    }

    @GetMapping("/search/null")
    public List<SafeIncidentTracker> nullResponse() {
        return null;
    }
}
