package com.example.demo.teststub;

public class MinimalIncidentTracker {
    private String incidentNumber;
    private String alertName;
    private String analysis;

    // Constructors
    public MinimalIncidentTracker(String incidentNumber, String alertName, String analysis) {
        this.incidentNumber = incidentNumber;
        this.alertName = alertName;
        this.analysis = analysis;
    }

    // Getters and Setters
    public String getIncidentNumber() {
        return incidentNumber;
    }

    public void setIncidentNumber(String incidentNumber) {
        this.incidentNumber = incidentNumber;
    }

    public String getAlertName() {
        return alertName;
    }

    public void setAlertName(String alertName) {
        this.alertName = alertName;
    }

    public String getAnalysis() {
        return analysis;
    }

    public void setAnalysis(String analysis) {
        this.analysis = analysis;
    }
}
