package com.example.demo.teststub;

public class SafeIncidentTracker {
    public String incidentNumber;
    public String alertName;
    public String analysis;

    public SafeIncidentTracker(String incidentNumber, String alertName, String analysis) {
        this.incidentNumber = incidentNumber;
        this.alertName = alertName;
        this.analysis = analysis;
    }

    public String getIncidentNumber() { return incidentNumber; }
    public String getAlertName() { return alertName; }
    public String getAnalysis() { return analysis; }
}
