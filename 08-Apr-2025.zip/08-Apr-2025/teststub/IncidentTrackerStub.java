package com.example.demo.teststub;

public class IncidentTrackerStub {
    private String incidentNumber;
    private String alertName;
    private String analysis;

    public IncidentTrackerStub(String incidentNumber, String alertName, String analysis) {
        this.incidentNumber = incidentNumber;
        this.alertName = alertName;
        this.analysis = analysis;
    }

    public String getIncidentNumber() {
        return incidentNumber;
    }

    public String getAlertName() {
        return alertName;
    }

    public String getAnalysis() {
        return analysis;
    }
}

