package com.example.demo.teststub;

public class SafeIncidentTrackerDto {
    private String incidentNumber;
    private String alertName;
    private String analysis;

    public SafeIncidentTrackerDto(String incidentNumber, String alertName, String analysis) {
        this.incidentNumber = incidentNumber;
        this.alertName = alertName;
        this.analysis = analysis;
    }

    public String getIncidentNumber() {
        return incidentNumber;
    }

    public String getAlertName() {
        return alertName;
    }

    public String getAnalysis() {
        return analysis;
    }
}
