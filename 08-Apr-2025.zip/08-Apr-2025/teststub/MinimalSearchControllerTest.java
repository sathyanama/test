package com.example.demo.teststub;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class MinimalSearchControllerTest {

    private MockMvc mockMvc;

    @BeforeEach
    void setup() {
        ObjectMapper mapper = new ObjectMapper();
        mockMvc = MockMvcBuilders
                .standaloneSetup(new MinimalSearchController())
                .setMessageConverters(new MappingJackson2HttpMessageConverter(mapper))
                .build();
    }

    @Test
    void testMockSearch() throws Exception {
        mockMvc.perform(get("/mock/search"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].incidentNumber").value("INC001"))
                .andExpect(jsonPath("$[0].alertName").value("Mock Alert"))
                .andExpect(jsonPath("$[0].analysis").value("Sample Analysis"));
    }
}
