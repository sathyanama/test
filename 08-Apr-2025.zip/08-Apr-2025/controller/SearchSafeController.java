package com.example.demo.controller;

import com.example.demo.teststub.MinimalIncidentTracker;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.ResponseEntity;

import java.util.List;

@RestController
public class SearchSafeController {

    // This method would typically use your service to fetch the data.
    // Here we are mocking the behavior
    @GetMapping("/search/query")
    public ResponseEntity<List<MinimalIncidentTracker>> searchPaginated(@RequestParam String query, @RequestParam int page, @RequestParam int size) {
        // Mocked data for testing
        MinimalIncidentTracker mockData = new MinimalIncidentTracker("INC123", "Test Alert", "Test analysis");
        return ResponseEntity.ok(List.of(mockData));
    }
    
    @GetMapping("/search/last50")
    public ResponseEntity<List<MinimalIncidentTracker>> getLast50Records(@RequestParam int page, @RequestParam int size) {
        // Mocked data for testing
        MinimalIncidentTracker mockData = new MinimalIncidentTracker("INC123", "Test Alert", "Test analysis");
        return ResponseEntity.ok(List.of(mockData));
    }
}
