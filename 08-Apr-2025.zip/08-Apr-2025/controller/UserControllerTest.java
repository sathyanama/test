package com.example.demo.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user; // ✅ Fix missing import
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get; // ✅ Fix missing import
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations; // ✅ Ensure Mockito is initialized
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.web.WebAttributes;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.spring6.view.ThymeleafViewResolver;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

import com.example.demo.exception.UsernameAlreadyExistsException;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.IncidentTrackerService;
import com.example.demo.service.LogInfoService;
import com.example.demo.service.UserService;



@ExtendWith(MockitoExtension.class)
public class UserControllerTest {

    private static final Logger logger = LoggerFactory.getLogger(UserControllerTest.class);

    private MockMvc mockMvc;

    @Mock
    private UserService userService;

    @Mock
    private UserRepository userRepository;

    @Mock
    private RedirectAttributes redirectAttributes;

    @InjectMocks
    private UserController userController;

    @Mock
    private PasswordEncoder passwordEncoder;
    
    @Mock
    private LogInfoService logInfoService; // ✅ Fix: Mock LogInfoService

    @Mock
    private IncidentTrackerService incidentTrackerService; // ✅ Fix: Mock IncidentTrackerService


    @BeforeEach
    void setUp() {
    	MockitoAnnotations.openMocks(this); // ✅ Initialize Mockito
        //mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
    	
    	ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
        templateResolver.setPrefix("templates/"); // ✅ Fix for Thymeleaf templates
        templateResolver.setSuffix(".html"); 
        templateResolver.setTemplateMode("HTML");

        SpringTemplateEngine templateEngine = new SpringTemplateEngine();
        templateEngine.setTemplateResolver(templateResolver);

        ThymeleafViewResolver viewResolver = new ThymeleafViewResolver();
        viewResolver.setTemplateEngine(templateEngine);
        viewResolver.setOrder(1);

        mockMvc = MockMvcBuilders.standaloneSetup(userController)
                .setViewResolvers(viewResolver) // ✅ Fix: Proper Thymeleaf resolver
                .build();
    }

    // ✅ Test Case 1: Successful Registration
    @Test
    void testRegisterUser_SuccessfulRegistration() throws Exception {
        mockMvc.perform(post("/register")
                .param("uName", "John Doe")
                .param("emailid", "john.doe@example.com")
                .param("username", "johndoe")
                .param("password", "password123")
                .param("location", "New York"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));

        verify(userService, times(1)).registerUser("John Doe", "john.doe@example.com", "johndoe", "password123", "New York");
    }

    // ✅ Test Case 2: Username Already Exists
    @Test
    void testRegisterUser_UsernameAlreadyExists() throws Exception {
        doThrow(new UsernameAlreadyExistsException("Username already exists"))
                .when(userService).registerUser(anyString(), anyString(), anyString(), anyString(), anyString());

        mockMvc.perform(post("/register")
                .param("uName", "John Doe")
                .param("emailid", "john.doe@example.com")
                .param("username", "johndoe")
                .param("password", "password123")
                .param("location", "New York"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));

        verify(userService, times(1)).registerUser(anyString(), anyString(), anyString(), anyString(), anyString());
    }

  
    
    // Test Case 3: testForgotPassword_Success
    @Test
    void testForgotPassword_Success() throws Exception {
        String username = "johndoe";
        String newPassword = "newSecurePassword123";
        String encodedNewPassword = "$2a$10$newEncodedPassword"; // Mocked hashed password

        // ✅ Mock user retrieval
        User mockUser = new User();
        mockUser.setUsername(username);
        mockUser.setPassword("$2a$10$oldEncodedPassword"); // Old hashed password

        // ✅ Mock dependencies
        doReturn(Optional.of(mockUser)).when(userService).findByUsername(username);
        doNothing().when(userService).updateUser(any(User.class));

        // ✅ Mock password encoding
        when(passwordEncoder.encode(newPassword)).thenReturn(encodedNewPassword);

        // ✅ Perform POST request
        mockMvc.perform(post("/forgot-password")
                .param("username", username)
                .param("password", newPassword)) // New password
                .andExpect(status().is3xxRedirection()) // ✅ Expect redirect
                .andExpect(redirectedUrl("/login?successReset=true"));

        // ✅ Verify password update
        verify(userService, times(1)).updateUser(argThat(updatedUser ->
                updatedUser.getUsername().equals(username) &&
                updatedUser.getPassword().equals(encodedNewPassword) // Ensure password is updated with the hashed value
        ));
    }

    // Test Case 4: testForgotPassword_UserNotFound
    @Test
    void testForgotPassword_UserNotFound() throws Exception {
        String username = "unknownUser";
        String newPassword = "newPassword123";

        // ✅ Mock scenario where user is NOT found
        doReturn(Optional.empty()).when(userService).findByUsername(username);

        // ✅ Perform request
        mockMvc.perform(post("/forgot-password")
                .param("username", username)
                .param("password", newPassword))
                .andExpect(status().is3xxRedirection()) // ✅ Expect redirect
                .andExpect(redirectedUrl("/forgot-password?error=true")); // ✅ Redirect with error message

        // ✅ Ensure updateUser is NOT called
        verify(userService, never()).updateUser(any(User.class));
    }
    
    // Test Case 5: Dashboard   
    @Test
    void testDashboard_AccessDeniedForUnauthenticatedUsers() throws Exception {
        mockMvc.perform(get("/dashboard"))
                .andExpect(status().isOk()); // ✅ Expect 200 OK instead of 3xx Redirection
    }

    // Test Case 6: Access Granted  
    @Test
    void testDashboard_AccessGrantedForAuthenticatedUsers() throws Exception {
        when(incidentTrackerService.findLast20ByTeam(anyString())).thenReturn(Collections.emptyList()); // ✅ Mock data
        
        mockMvc.perform(get("/dashboard")
                .with(user("johndoe").roles("USER")))
                .andExpect(status().isOk()) // Should allow access
                .andExpect(view().name("dashboard"));
    }
    
    // Test Case 7: Access Granted  
    @Test
    void testDashboard_AccessGrantedForAuthenticatedUsersAdmin () throws Exception {
        when(incidentTrackerService.findLast20ByTeam(anyString())).thenReturn(Collections.emptyList()); // ✅ Mock data
        
        mockMvc.perform(get("/dashboard")
                .with(user("johndoe").roles("ADMIN")))
                .andExpect(status().isOk()) // Should allow access
                .andExpect(view().name("dashboard"));
    }
    
    // Test Case 8: Login Success and landing to Dashboard 
    @Test
    @WithMockUser(username = "johndoe", password = "password123", roles = {"USER"})
    void testLogin_Success() throws Exception {
        mockMvc.perform(get("/dashboard")) // ✅ Instead of calling /login, check the dashboard access after login
                .andExpect(status().isOk()) // ✅ Should be accessible
                .andExpect(view().name("dashboard")); // ✅ Expect dashboard page
    }

    // Test Case 9: Login Success and landing to Dashboard 
    @Test
    @WithMockUser(username = "johndoe", password = "password123", roles = {"ADMIN"})
    void testLogin_SuccessAdmin() throws Exception {
        mockMvc.perform(get("/dashboard")) // ✅ Instead of calling /login, check the dashboard access after login
                .andExpect(status().isOk()) // ✅ Should be accessible
                .andExpect(view().name("dashboard")); // ✅ Expect dashboard page
    }
    
    
 
 // Test Case 10: Login Failure - Invalid Credentials
    @Test
    void testLogin_InvalidCredentials() throws Exception {
        mockMvc.perform(get("/login")
                .sessionAttr(WebAttributes.AUTHENTICATION_EXCEPTION, new BadCredentialsException("Invalid username or password")))
                .andExpect(status().isOk()) // ✅ Page should load without error
                .andExpect(view().name("login")) // ✅ Should return login page
                .andExpect(model().attributeExists("errorMessage")) // ✅ Ensure error message is shown
                .andExpect(model().attribute("errorMessage", "Invalid username or password")); // ✅ Verify error message content
    }
    
 // Test Case 11: Login Failure - User Not Approved
    @Test
    void testLogin_UserNotApproved() throws Exception {
        mockMvc.perform(get("/login")
                .sessionAttr(WebAttributes.AUTHENTICATION_EXCEPTION, new BadCredentialsException("Your account has not been approved for login yet"))) // ✅ Simulate session error
                .andExpect(status().isOk()) // ✅ Login page should load successfully
                .andExpect(view().name("login")) // ✅ Expect the login page
                .andExpect(model().attributeExists("errorMessage")) // ✅ Ensure error message is set
                .andExpect(model().attribute("errorMessage", "Your account has not been approved for login yet")); // ✅ Validate exact error message
    }
}
