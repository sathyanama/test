package com.example.demo.controller;

import com.example.demo.model.IncidentTracker;
import com.example.demo.service.IncidentTrackerService;
import com.example.demo.service.LogInfoService;
import com.example.demo.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@WebMvcTest(SearchController.class)
@AutoConfigureMockMvc(addFilters = false) // ✅ Disable Spring Security for testing
public class SearchControllerSafeTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private IncidentTrackerService incidentTrackerService;

    @MockBean
    private UserService userService;

    @MockBean
    private LogInfoService logInfoService;

    @Test
    void testSearchPaginated() throws Exception {
        // Create safe mock data
        IncidentTracker tracker = new IncidentTracker();
        tracker.setIncidentNumber("INC123");
        tracker.setAlertName("Test Alert");
        tracker.setAnalysis("Test analysis");

        List<IncidentTracker> dataList = List.of(tracker);
        Page<IncidentTracker> safePage = new PageImpl<>(dataList);

        // Mock service call
        when(incidentTrackerService.searchPaginatedWithoutTeam(eq("Test"), eq(0), eq(10)))
                .thenReturn(safePage);

        // Perform GET /search/query
        mockMvc.perform(get("/search/query")
                        .param("query", "Test")
                        .param("page", "0")
                        .param("size", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[0].incidentNumber").value("INC123"))
                .andExpect(jsonPath("$.content[0].alertName").value("Test Alert"))
                .andExpect(jsonPath("$.content[0].analysis").value("Test analysis"));

        
    }

    @Test
    void testGetLast50Records() throws Exception {
        // Create safe mock data
        IncidentTracker tracker = new IncidentTracker();
        tracker.setIncidentNumber("INC123");
        tracker.setAlertName("Test Alert");
        tracker.setAnalysis("Test analysis");

        List<IncidentTracker> dataList = List.of(tracker);
        Page<IncidentTracker> safePage = new PageImpl<>(dataList);

        // Mock service call
        when(incidentTrackerService.findLast50RecordsWithoutTeam(eq(0), eq(50)))
                .thenReturn(safePage);

        // Perform GET /search/last50
        mockMvc.perform(get("/search/last50")
                        .param("page", "0")
                        .param("size", "50"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[0].incidentNumber").value("INC123"))
                .andExpect(jsonPath("$.content[0].alertName").value("Test Alert"))
                .andExpect(jsonPath("$.content[0].analysis").value("Test analysis"));

    }
}
