package com.example.demo;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordVerificationUtil {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

        String rawPassword = "password"; // The plain text password
        String encodedPassword = "$2a$10$cGCaJ845A5e2BbeX6CLjeePwuM65OvY1HeT4lvwjFFoJ73Bkx5p4y"; // Hash from the database

        boolean matches = encoder.matches(rawPassword, encodedPassword);
        System.out.println("Password matches: " + matches);
    }
}

