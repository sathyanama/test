package com.example.demo;

import java.util.Base64;

public class Base64EncoderUtil {
    public static void main(String[] args) {
        String rawPassword = "Babasairam@786"; // Replace with your actual password
        String encodedPassword = Base64.getEncoder().encodeToString(rawPassword.getBytes());
        System.out.println("Encoded Password: " + encodedPassword);
    }
}

