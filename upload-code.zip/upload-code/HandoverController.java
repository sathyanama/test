package com.example.demo.controller;

import com.example.demo.model.HandoverTracker;
import com.example.demo.model.User;
import com.example.demo.service.HandoverService;
import com.example.demo.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/handover")
@CrossOrigin(origins = "*")
public class HandoverController {

    @Autowired
    private HandoverService handoverService;
    
    @Autowired
    private UserService userService;

    // Fetch handover details
    /*@GetMapping
    public Map<String, Object> getHandover(Principal principal) {
        String username = principal.getName();
        Optional<HandoverTracker> handover = handoverService.getHandoverByUser(username);
        String heading = handoverService.getHandoverHeading(handover.map(HandoverTracker::getLocation).orElse(""));

        return Map.of(
                "heading", heading,
                "handover", handover.orElse(null)
        );
    }*/
    
    
    @GetMapping
    public Map<String, Object> getHandover(Principal principal) {
        String username = principal.getName();
        Optional<HandoverTracker> handoverOptional = handoverService.getLatestHandoverByUser(username);

        //  If no handover is found, create a default handover with preset values
        HandoverTracker handover = handoverOptional.orElseGet(() -> {
            HandoverTracker newHandover = new HandoverTracker();
            
            //  Set default Start & End Dates based on user’s location
            LocalDateTime now = LocalDateTime.now(ZoneId.of("America/New_York"));
            User user = userService.getUserByUsername(username);

            if ("US".equalsIgnoreCase(user.getLocation())) {
                newHandover.setStartDate(now.withHour(7).withMinute(30).withSecond(0).withNano(0));
                newHandover.setEndDate(now.withHour(19).withMinute(30).withSecond(0).withNano(0));
            } else {
                newHandover.setStartDate(now.withHour(19).withMinute(30).withSecond(0).withNano(0));
                newHandover.setEndDate(now.plusDays(1).withHour(7).withMinute(30).withSecond(0).withNano(0));
            }

            return newHandover;
        });

        //  Set heading based on user's location
        String location = userService.getUserByUsername(username).getLocation();
        String heading = handoverService.getHandoverHeading(location);

        return Map.of(
                "heading", heading,
                "handover", handover
        );
    }
    
    

    // Save or update handover
    @PostMapping
    public HandoverTracker saveHandover(
            @RequestBody Map<String, String> request,
            Principal principal) {
        String username = principal.getName();
        LocalDateTime startDate = LocalDateTime.parse(request.get("startDate"));
        LocalDateTime endDate = LocalDateTime.parse(request.get("endDate"));
        String hoItem = request.get("hoItem");

        return handoverService.saveOrUpdateHandover(username, startDate, endDate, hoItem);
    }
    
    @GetMapping("/retrieve")
    public Map<String, Object> retrieveHandover(
            @RequestParam String team,
            @RequestParam LocalDateTime startDate,
            @RequestParam LocalDateTime endDate) {

        Optional<HandoverTracker> handover = handoverService.getHandoverByTeamAndDates(team, startDate, endDate);

        // Handle empty response by returning null safely
        if (handover.isEmpty()) {
            return Collections.emptyMap(); // Prevents NullPointerException
        }

        return Map.of("handover", handover.get());
    }
}
