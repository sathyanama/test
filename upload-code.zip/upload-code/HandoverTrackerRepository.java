package com.example.demo.repository;

import com.example.demo.model.HandoverTracker;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.time.LocalDateTime;

public interface HandoverTrackerRepository extends JpaRepository<HandoverTracker, Long> {
    Optional<HandoverTracker> findByTeam(String team);
    
 //  Find handover by team, startDate, and endDate (single-day validation is handled in service)
    Optional<HandoverTracker> findByTeamAndStartDateAndEndDate(String team, LocalDateTime startDate, LocalDateTime endDate);
    
    
    @Query("SELECT h FROM HandoverTracker h WHERE h.team = :team ORDER BY h.startDate DESC LIMIT 1")
    Optional<HandoverTracker> findLatestHandoverByTeam(@Param("team") String team);

}
